import { readFile } from 'node:fs/promises';
import postgres from 'postgres';

const file = process.argv[2] || 'migration-data/d1-snapshot.json';
const url = process.env.SUPABASE_DB_URL;
if (!url) throw new Error('Set SUPABASE_DB_URL in the environment before importing.');
const snapshot = JSON.parse(await readFile(file, 'utf8')) as { format: string; tables: Record<string, Array<Record<string, unknown>>> };
if (snapshot.format !== 'yj-studio-d1-snapshot-v1') throw new Error('Unrecognized snapshot format.');
const order = ['roles','admins','projects','services','campaigns','bookings','settings','audit_logs','sessions','login_attempts','admin_roles'];
const keys: Record<string, string[]> = {
  roles:['id'], admins:['id'], sessions:['token_hash'], login_attempts:['ip_hash'], projects:['id'], services:['id'],
  campaigns:['id'], bookings:['id'], settings:['key'], audit_logs:['id'], admin_roles:['admin_id','role_id'],
};
const sql = postgres(url, { ssl: 'require', max: 1, prepare: false });
try {
  await sql.begin(async tx => {
    for (const table of order) {
      const rows = snapshot.tables[table] || [];
      for (const row of rows) {
        const columns = Object.keys(row);
        if (!columns.length) continue;
        const quote = (s: string) => `"${s.replace(/"/g, '""')}"`;
        const names = columns.map(quote).join(',');
        const values = columns.map(c => row[c]);
        const slots = columns.map((_, i) => `$${i + 1}`).join(',');
        const keyColumns = keys[table] || [];
        const updates = columns.filter(c => !keyColumns.includes(c)).map(c => `${quote(c)} = EXCLUDED.${quote(c)}`);
        const conflict = updates.length
          ? `ON CONFLICT (${keyColumns.map(quote).join(',')}) DO UPDATE SET ${updates.join(',')}`
          : 'ON CONFLICT DO NOTHING';
        await tx.unsafe(`INSERT INTO public.${quote(table)} (${names}) VALUES (${slots}) ${conflict}`, values as never[]);
      }
      console.log(`${table}: upserted ${rows.length} rows`);
    }
  });
} finally { await sql.end({ timeout: 5 }); }
console.log('Snapshot import complete. Verify row counts and sample records before switching production traffic.');
