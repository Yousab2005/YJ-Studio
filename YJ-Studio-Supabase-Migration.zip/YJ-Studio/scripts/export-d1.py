#!/usr/bin/env python3
"""Export a local Cloudflare D1 SQLite snapshot to a portable JSON file."""
import json, sqlite3, sys
from pathlib import Path
if len(sys.argv) != 3:
    raise SystemExit('Usage: python scripts/export-d1.py <sqlite-file> <output-json>')
src, dest = Path(sys.argv[1]), Path(sys.argv[2])
if not src.exists(): raise SystemExit(f'SQLite database not found: {src}')
conn = sqlite3.connect(f'file:{src}?mode=ro', uri=True)
conn.row_factory = sqlite3.Row
skip = {'d1_migrations', 'sqlite_sequence', '_cf_METADATA'}
tables = [r['name'] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name") if r['name'] not in skip]
data = {'format': 'yj-studio-d1-snapshot-v1', 'source': str(src), 'tables': {}}
for table in tables:
    rows = [dict(row) for row in conn.execute(f'SELECT * FROM "{table.replace(chr(34), chr(34)*2)}"')]
    data['tables'][table] = rows
    print(f'{table}: {len(rows)} rows')
dest.parent.mkdir(parents=True, exist_ok=True)
dest.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
print(f'Exported {len(tables)} tables to {dest}')
