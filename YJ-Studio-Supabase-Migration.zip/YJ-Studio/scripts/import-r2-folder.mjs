import { readdir, readFile, stat } from 'node:fs/promises';
import { join, relative, extname, sep } from 'node:path';

const root = process.argv[2];
const url = process.env.SUPABASE_URL?.replace(/\/$/, '');
const key = process.env.SUPABASE_SECRET_KEY;
const bucket = process.env.SUPABASE_STORAGE_BUCKET || 'yj-studio-media';
if (!root || !url || !key) throw new Error('Usage: SUPABASE_URL=... SUPABASE_SECRET_KEY=... node scripts/import-r2-folder.mjs <downloaded-r2-folder>');
const mime = { '.jpg':'image/jpeg','.jpeg':'image/jpeg','.png':'image/png','.webp':'image/webp','.mp3':'audio/mpeg','.wav':'audio/wav','.ogg':'audio/ogg','.m4a':'audio/mp4','.mp4':'video/mp4','.webm':'video/webm' };
const auth = key.startsWith('sb_secret_') ? { apikey: key } : { apikey: key, Authorization: `Bearer ${key}` };
async function walk(dir) {
  for (const entry of await readdir(dir, { withFileTypes: true })) {
    const full = join(dir, entry.name);
    if (entry.isDirectory()) { await walk(full); continue; }
    const keyPath = relative(root, full).split(sep).join('/');
    const body = await readFile(full);
    const objectPath = keyPath.split('/').map(encodeURIComponent).join('/');
    const response = await fetch(`${url}/storage/v1/object/${encodeURIComponent(bucket)}/${objectPath}?upsert=true`, {
      method: 'POST', headers: { ...auth, 'Content-Type': mime[extname(full).toLowerCase()] || 'application/octet-stream', 'Cache-Control': 'private, no-store', 'x-upsert': 'true' }, body,
    });
    if (!response.ok) throw new Error(`Upload failed for ${keyPath}: HTTP ${response.status} ${await response.text()}`);
    console.log(`Uploaded ${keyPath} (${body.length} bytes)`);
  }
}
if (!(await stat(root)).isDirectory()) throw new Error('Input path must be a directory.');
await walk(root);
console.log('Media import complete. Verify object counts and sample files before cutover.');
