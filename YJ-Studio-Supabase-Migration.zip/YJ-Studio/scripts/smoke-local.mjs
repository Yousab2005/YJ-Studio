import assert from 'node:assert/strict';
import { randomBytes, randomUUID } from 'node:crypto';
import { spawn, spawnSync } from 'node:child_process';
import { setTimeout as delay } from 'node:timers/promises';
import { fileURLToPath } from 'node:url';
import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const persistence = '.wrangler-smoke';
const persistencePath = path.resolve(root, persistence);
if (persistencePath !== path.join(root, persistence)) throw new Error('Refusing to use an unexpected smoke-test database path.');
const wrangler = path.join(root, 'node_modules', 'wrangler', 'bin', 'wrangler.js');
const username = `smoke-${randomBytes(5).toString('hex')}`;
const password = `Smoke-${randomUUID()}-${randomUUID()}`;
const origin = 'http://127.0.0.1:8788';
let server;
let cookie = '';

function command(args, env = process.env) {
  const result = spawnSync(process.execPath, args, { cwd: root, env, encoding: 'utf8', stdio: 'inherit' });
  if (result.error) throw result.error;
  if (result.status !== 0) throw new Error(`Command exited with status ${result.status}.`);
}

async function waitForServer() {
  for (let attempt = 0; attempt < 50; attempt += 1) {
    try {
      const response = await fetch(`${origin}/api/health`);
      if (response.ok) return;
    } catch { /* Worker is still starting. */ }
    if (server?.exitCode !== null && server?.exitCode !== undefined) throw new Error(`Wrangler exited with ${server.exitCode} before the API became ready.`);
    await delay(250);
  }
  throw new Error('Local Worker did not become ready on port 8788.');
}

async function request(pathname, options = {}, authenticated = true) {
  const headers = new Headers(options.headers);
  headers.set('Origin', origin);
  if (authenticated && cookie) headers.set('Cookie', cookie);
  if (!['GET', 'HEAD', 'OPTIONS'].includes((options.method ?? 'GET').toUpperCase())) headers.set('X-YJ-Request', '1');
  if (options.body && !(options.body instanceof FormData) && !headers.has('Content-Type')) headers.set('Content-Type', 'application/json');
  return fetch(`${origin}${pathname}`, { ...options, headers });
}

async function json(response) {
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body.error || `Request returned ${response.status}.`);
  return body;
}

function makeSilentWave() {
  const sampleRate = 8_000;
  const sampleCount = sampleRate / 2;
  const bytes = Buffer.alloc(44 + sampleCount * 2);
  bytes.write('RIFF', 0);
  bytes.writeUInt32LE(bytes.length - 8, 4);
  bytes.write('WAVEfmt ', 8);
  bytes.writeUInt32LE(16, 16);
  bytes.writeUInt16LE(1, 20);
  bytes.writeUInt16LE(1, 22);
  bytes.writeUInt32LE(sampleRate, 24);
  bytes.writeUInt32LE(sampleRate * 2, 28);
  bytes.writeUInt16LE(2, 32);
  bytes.writeUInt16LE(16, 34);
  bytes.write('data', 36);
  bytes.writeUInt32LE(sampleCount * 2, 40);
  return bytes;
}

function makePngPixel() {
  return Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/NnQAAAAASUVORK5CYII=', 'base64');
}

async function run() {
  command([wrangler, 'd1', 'migrations', 'apply', 'yj-studio', '--local', '--persist-to', persistence]);
  command([path.join(root, 'scripts', 'create-admin.mjs'), '--persist-to', persistence], {
    ...process.env,
    ADMIN_USERNAME: username,
    ADMIN_PASSWORD: password,
  });
  server = spawn(process.execPath, [wrangler, 'dev', '--local', '--port', '8788', '--persist-to', persistence, '--show-interactive-dev-session', 'false'], {
    cwd: root,
    stdio: 'ignore',
    windowsHide: true,
  });
  await waitForServer();

  const rootPage = await fetch(origin);
  assert.equal(rootPage.status, 200, 'Worker should serve the public SPA shell.');
  const manifest = await fetch(`${origin}/manifest.webmanifest`);
  assert.equal(manifest.status, 200, 'PWA manifest should be served.');
  const manifestText = await manifest.text();
  assert.match(manifestText, /yj-icon-192\.jpg/);
  assert.match(manifestText, /yj-icon-512-maskable\.jpg/);
  const initial = await json(await fetch(`${origin}/api/public`));
  assert.equal((await fetch(`${origin}/api/public`)).headers.get('cache-control'), 'no-store');
  assert.equal(initial.services.length, 3, 'Seeded pricing should come from D1.');
  assert.equal('bookings' in initial, false, 'Public API must not expose customer bookings.');
  assert.equal('upload_limit_mb' in initial.settings, false, 'Administrative upload settings should stay private.');
  assert.equal('upload_formats' in initial.settings, false, 'Administrative upload format settings should stay private.');
  assert.equal('dashboard_booking_alerts' in initial.settings, false, 'Notification preferences should stay private.');

  const unauthorized = await request('/api/admin/projects', { method: 'POST', body: JSON.stringify({}) }, false);
  assert.equal(unauthorized.status, 401, 'Unauthenticated writes must be denied.');

  const login = await request('/api/admin/login', { method: 'POST', body: JSON.stringify({ username, password }) }, false);
  assert.equal(login.status, 200, 'Admin should be able to sign in.');
  const setCookie = login.headers.get('set-cookie') ?? '';
  assert.match(setCookie, /HttpOnly/i);
  assert.match(setCookie, /SameSite=Strict/i);
  cookie = setCookie.split(';')[0];
  assert.ok(cookie.startsWith('yj_admin='), 'Login should set an opaque admin session cookie.');
  assert.match((await request('/api/admin/overview')).headers.get('cache-control') ?? '', /private, no-store/);

  const forbiddenOrigin = await fetch(`${origin}/api/admin/settings`, {
    method: 'PUT',
    headers: { Origin: 'https://attacker.invalid', Cookie: cookie, 'X-YJ-Request': '1', 'Content-Type': 'application/json' },
    body: JSON.stringify({ settings: { hero_title: 'Cross-origin change' } }),
  });
  assert.equal(forbiddenOrigin.status, 403, 'Cross-origin writes must be denied.');

  const service = initial.services.find((item) => item.id === 'service-recording');
  assert.ok(service);
  await json(await request(`/api/admin/services/${service.id}`, {
    method: 'PUT',
    body: JSON.stringify({ ...service, price: 712, is_active: true }),
  }));
  const afterPrice = await json(await fetch(`${origin}/api/public`));
  assert.equal(afterPrice.services.find((item) => item.id === service.id)?.price, 712, 'Price edits should publish through the public API.');

  const form = new FormData();
  form.set('file', new Blob([makePngPixel()], { type: 'image/png' }), 'cover.png');
  const uploaded = await json(await request('/api/admin/media', { method: 'POST', body: form }));
  assert.match(uploaded.url, /^\/api\/media\//);
  const mediaKey = uploaded.url.split('/').at(-1);
  const uploadSettings = await json(await request('/api/admin/settings'));
  const originalFormats = uploadSettings.upload_formats;
  const withoutWav = originalFormats.split(',').filter((format) => format !== 'audio/wav').join(',');
  await json(await request('/api/admin/settings', { method: 'PUT', body: JSON.stringify({ settings: { upload_formats: withoutWav } }) }));
  const audioForm = new FormData();
  audioForm.set('file', new Blob([makeSilentWave()], { type: 'audio/wav' }), 'preview.wav');
  assert.equal((await request('/api/admin/media', { method: 'POST', body: audioForm })).status, 415, 'Upload format settings must be enforced server-side.');
  await json(await request('/api/admin/settings', { method: 'PUT', body: JSON.stringify({ settings: { upload_formats: originalFormats } }) }));
  const uploadedAudio = await json(await request('/api/admin/media', { method: 'POST', body: audioForm }));
  const project = await json(await request('/api/admin/projects', {
    method: 'POST',
    body: JSON.stringify({
      title: 'Smoke Project', category: 'Music production', description: 'Temporary local acceptance record.', tags: ['smoke'],
      cover_image: uploaded.url,
      media: [
        { ...uploaded, title: 'Cover', id: uploaded.id },
        { ...uploadedAudio, title: 'Short audio sample', id: uploadedAudio.id },
        { id: randomUUID(), title: 'Video release', kind: 'youtube', url: 'https://youtu.be/dQw4w9WgXcQ' },
      ],
      credits: 'Local smoke run',
      is_published: false, is_featured: false, sort_order: 1,
    }),
  }));
  assert.equal((await fetch(`${origin}${uploaded.url}`)).status, 404, 'Draft project media should not be public.');
  await json(await request(`/api/admin/projects/${project.id}`, {
    method: 'PUT',
    body: JSON.stringify({ ...project, title: 'Smoke Project Edited', is_published: true }),
  }));
  let publicData = await json(await fetch(`${origin}/api/public`));
  assert.equal(publicData.projects[0]?.title, 'Smoke Project Edited', 'Project edits should persist in D1.');
  assert.deepEqual(publicData.projects[0]?.media.map((item) => item.kind), ['image', 'audio', 'youtube']);
  assert.equal((await fetch(`${origin}${uploaded.url}`)).status, 200, 'Published project media should be served.');
  assert.equal((await fetch(`${origin}${uploadedAudio.url}`)).headers.get('content-type'), 'audio/wav');

  const logoForm = new FormData();
  logoForm.set('file', new Blob([makePngPixel()], { type: 'image/png' }), 'studio-logo.png');
  const logo = await json(await request('/api/admin/media', { method: 'POST', body: logoForm }));
  await json(await request('/api/admin/settings', {
    method: 'PUT',
    body: JSON.stringify({ settings: { hero_title: 'Smoke test hero copy', nav_portfolio: 'Releases', maintenance_message: 'Local maintenance notice', visible_sections: 'portfolio,services,offers,about,booking,contact', logo_path: logo.url, social_image: logo.url } }),
  }));
  publicData = await json(await fetch(`${origin}/api/public`));
  assert.equal(publicData.settings.hero_title, 'Smoke test hero copy', 'Public homepage copy should read from saved settings.');
  assert.equal(publicData.settings.nav_portfolio, 'Releases', 'Navigation labels should be manageable from the dashboard.');
  assert.equal((await fetch(`${origin}${logo.url}`)).status, 200, 'A configured public studio logo should be available to visitors.');
  await json(await request('/api/admin/settings', { method: 'PUT', body: JSON.stringify({ settings: { visible_sections: '' } }) }));
  assert.equal((await json(await fetch(`${origin}/api/public`))).settings.visible_sections, '', 'All homepage sections can be hidden through settings.');
  await json(await request('/api/admin/settings', { method: 'PUT', body: JSON.stringify({ settings: { visible_sections: 'portfolio,services,offers,about,booking,contact' } }) }));

  const campaign = await json(await request('/api/admin/campaigns', {
    method: 'POST',
    body: JSON.stringify({ title: 'Smoke Offer', description: 'Local schedule and click check.', kind: 'studio', placement: 'homepage banner', media_url: '', cta_label: 'Book now', destination_url: '/services', start_at: null, end_at: null, status: 'active', sort_order: 0 }),
  }));
  publicData = await json(await fetch(`${origin}/api/public`));
  assert.ok(publicData.campaigns.some((item) => item.id === campaign.id), 'Active campaigns should appear publicly.');
  await json(await request(`/api/campaigns/${campaign.id}/click`, { method: 'POST', body: '{}' }, false));
  const campaignRow = (await json(await request('/api/admin/campaigns'))).find((item) => item.id === campaign.id);
  assert.equal(campaignRow.clicks, 1, 'Campaign clicks should be stored in D1.');

  const startsAt = new Date(Date.now() + 3 * 60 * 60 * 1000);
  const bookingPayload = {
    customer_name: 'Smoke Client', phone: '+201000000000', email: '', service_id: service.id,
    preferred_at: startsAt.toISOString(), duration_minutes: 60, project_details: 'Local conflict test.',
  };
  const booking = await json(await request('/api/bookings', { method: 'POST', body: JSON.stringify(bookingPayload) }, false));
  assert.equal(booking.quoted_price, 712, 'Booking quote should use current service pricing.');
  const conflict = await request('/api/bookings', { method: 'POST', body: JSON.stringify({ ...bookingPayload, customer_name: 'Overlap Client', preferred_at: new Date(startsAt.getTime() + 30 * 60 * 1000).toISOString() }) }, false);
  assert.equal(conflict.status, 409, 'Overlapping appointments must be rejected server-side.');
  const privateBookings = await json(await request('/api/admin/bookings'));
  const storedBooking = privateBookings.find((item) => item.reference === booking.reference);
  assert.equal(storedBooking?.customer_name, 'Smoke Client', 'Admin can review private booking details.');
  await json(await request(`/api/admin/bookings/${storedBooking.id}`, {
    method: 'PUT',
    body: JSON.stringify({ status: 'confirmed', preferred_at: new Date(startsAt.getTime() + 24 * 60 * 60 * 1000).toISOString(), duration_minutes: 60, admin_note: 'Confirmed during local smoke test.' }),
  }));

  await json(await request(`/api/admin/projects/${project.id}`, { method: 'PUT', body: JSON.stringify({ ...project, title: 'Smoke Project Edited', is_published: false }) }));
  publicData = await json(await fetch(`${origin}/api/public`));
  assert.equal(publicData.projects.some((item) => item.id === project.id), false, 'Unpublished projects should leave public responses.');
  assert.equal((await fetch(`${origin}/api/media/${mediaKey}`)).status, 404, 'Unpublished project media should become private again.');

  const logout = await request('/api/admin/logout', { method: 'POST', body: '{}' });
  assert.equal(logout.status, 200);
  cookie = '';
  assert.equal((await request('/api/admin/projects', {}, false)).status, 401, 'Logout should invalidate the server-side session.');
  const rotatedPassword = `Rotated-${randomUUID()}-${randomUUID()}`;
  const relogin = await request('/api/admin/login', { method: 'POST', body: JSON.stringify({ username, password }) }, false);
  assert.equal(relogin.status, 200);
  cookie = (relogin.headers.get('set-cookie') ?? '').split(';')[0];
  await json(await request('/api/admin/account/password', { method: 'POST', body: JSON.stringify({ current_password: password, new_password: rotatedPassword }) }));
  assert.equal((await request('/api/admin/me')).status, 200, 'Password rotation should keep the current session active.');
  await request('/api/admin/logout', { method: 'POST', body: '{}' });
  cookie = '';
  assert.equal((await request('/api/admin/login', { method: 'POST', body: JSON.stringify({ username, password }) }, false)).status, 401, 'Password rotation should reject the old password.');
  const rotatedLogin = await request('/api/admin/login', { method: 'POST', body: JSON.stringify({ username, password: rotatedPassword }) }, false);
  assert.equal(rotatedLogin.status, 200, 'Password rotation should accept the new password.');
  console.log('Local smoke checks passed: role-gated auth, origin checks, configurable upload enforcement, D1 content and price persistence, image/WAV/YouTube project media, campaign tracking, private bookings and conflict rejection, password rotation, logout, and PWA assets.');
}

try {
  await run();
} finally {
  process.env.ADMIN_USERNAME = '';
  process.env.ADMIN_PASSWORD = '';
  if (server && server.exitCode === null) {
    if (process.platform === 'win32' && server.pid) {
      spawnSync('taskkill', ['/PID', String(server.pid), '/T', '/F'], { stdio: 'ignore', windowsHide: true });
    } else {
      server.kill('SIGTERM');
    }
  }
  await delay(300);
  fs.rmSync(persistencePath, { recursive: true, force: true });
}
