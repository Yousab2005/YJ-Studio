import { pbkdf2Sync, randomBytes, randomUUID } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const username = (process.env.ADMIN_USERNAME ?? '').trim().toLowerCase();
const password = process.env.ADMIN_PASSWORD ?? '';
const remote = process.argv.includes('--remote');
const persistenceIndex = process.argv.indexOf('--persist-to');
const persistence = persistenceIndex >= 0 ? process.argv[persistenceIndex + 1] : undefined;

if (!/^[a-z0-9._@+-]{3,120}$/.test(username)) {
  console.error('Set ADMIN_USERNAME to a 3–120 character username or email.');
  process.exit(1);
}
if (password.length < 12 || password.length > 300) {
  console.error('Set ADMIN_PASSWORD to a password with at least 12 characters.');
  process.exit(1);
}

const salt = randomBytes(16);
const iterations = 310_000;
const hash = pbkdf2Sync(password, salt, iterations, 32, 'sha256');
const storedHash = `pbkdf2$${iterations}$${salt.toString('base64url')}$${hash.toString('base64url')}`;
const adminId = randomUUID();
const quote = (value) => `'${value.replaceAll("'", "''")}'`;
const sql = `INSERT INTO admins(id, username, password_hash) VALUES(${quote(adminId)}, ${quote(username)}, ${quote(storedHash)}) ON CONFLICT(username) DO NOTHING;`;
const wrangler = path.join(root, 'node_modules', 'wrangler', 'bin', 'wrangler.js');
const args = [wrangler, 'd1', 'execute', 'yj-studio', ...(remote ? ['--remote'] : ['--local']), ...(persistence ? ['--persist-to', persistence] : []), '--command', sql];
const result = spawnSync(process.execPath, args, { cwd: root, stdio: 'inherit', env: process.env });

process.env.ADMIN_PASSWORD = '';
process.env.ADMIN_USERNAME = '';
if (result.error) {
  console.error('Could not run Wrangler. Install dependencies and apply the database migration first.');
  process.exit(1);
}
if (result.status !== 0) process.exit(result.status ?? 1);
console.log(`Administrator provisioning command completed for ${username}. If the username already existed, no account was changed.`);
