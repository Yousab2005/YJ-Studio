import { describe, expect, it } from 'vitest';
import { bookingSchema, campaignSchema, projectSchema, serviceSchema } from '../src/shared';

describe('public request schemas', () => {
  it('accepts a complete project with uploaded media metadata', () => {
    const result = projectSchema.safeParse({
      title: 'Night Drive', category: 'Music production', description: 'A late night single.', tags: ['R&B'], credits: 'Engineer Yousab',
      cover_image: '/api/media/cover.jpg', media: [{ id: 'track-1', title: 'Final mix', kind: 'audio', url: '/api/media/mix.mp3', mime: 'audio/mpeg' }],
      is_published: true, is_featured: false, sort_order: 4,
    });
    expect(result.success).toBe(true);
  });

  it('rejects malformed project categories and oversized uploads metadata lists', () => {
    expect(projectSchema.safeParse({ title: 'ok', category: 'anything else' }).success).toBe(false);
    expect(projectSchema.safeParse({ title: 'ok', category: 'Music videos', media: Array.from({ length: 41 }, (_, id) => ({ id: String(id), title: 'x', kind: 'image', url: '/api/media/x.jpg' })) }).success).toBe(false);
  });

  it('validates and normalizes service price settings', () => {
    const result = serviceSchema.safeParse({ name: 'Recording', price: 500, currency: 'EGP', billing_unit: 'per hour', is_active: true });
    expect(result.success).toBe(true);
    expect(serviceSchema.safeParse({ name: 'Recording', price: -1, currency: 'EGP' }).success).toBe(false);
  });

  it('requires useful booking details and a valid optional email', () => {
    expect(bookingSchema.safeParse({ customer_name: 'Mina', phone: '+201234567890', service_id: 'service-recording', preferred_at: '2026-11-05T14:00', duration_minutes: 120 }).success).toBe(true);
    expect(bookingSchema.safeParse({ customer_name: 'M', phone: '12', service_id: 's', preferred_at: 'bad', email: 'not-an-email' }).success).toBe(false);
  });

  it('defaults campaign status while limiting placements', () => {
    const valid = campaignSchema.parse({ title: 'November offer' });
    expect(valid.status).toBe('draft');
    expect(campaignSchema.safeParse({ title: 'Offer', placement: 'footer popover' }).success).toBe(false);
  });
});
