-- Source migration 0001_initial.sql; SQLite syntax adapted for PostgreSQL.
CREATE TABLE IF NOT EXISTS admins (
  id TEXT PRIMARY KEY,
  username TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (now()::text)
);

CREATE TABLE IF NOT EXISTS sessions (
  token_hash TEXT PRIMARY KEY,
  admin_id TEXT NOT NULL REFERENCES admins(id) ON DELETE CASCADE,
  expires_at TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (now()::text)
);

CREATE TABLE IF NOT EXISTS login_attempts (
  ip_hash TEXT PRIMARY KEY,
  failed_count INTEGER NOT NULL DEFAULT 0,
  window_start TEXT NOT NULL,
  blocked_until TEXT
);

CREATE TABLE IF NOT EXISTS projects (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  category TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  tags_json TEXT NOT NULL DEFAULT '[]',
  credits TEXT NOT NULL DEFAULT '',
  release_date TEXT,
  cover_image TEXT NOT NULL DEFAULT '',
  media_json TEXT NOT NULL DEFAULT '[]',
  is_published INTEGER NOT NULL DEFAULT 0,
  is_featured INTEGER NOT NULL DEFAULT 0,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (now()::text),
  updated_at TEXT NOT NULL DEFAULT (now()::text)
);

CREATE INDEX IF NOT EXISTS projects_public_order ON projects(is_published, is_featured, sort_order, release_date);

CREATE TABLE IF NOT EXISTS services (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  price REAL NOT NULL DEFAULT 0,
  currency TEXT NOT NULL DEFAULT 'EGP',
  billing_unit TEXT NOT NULL DEFAULT 'per project',
  duration_minutes INTEGER,
  discount_price REAL,
  discount_start TEXT,
  discount_end TEXT,
  is_active INTEGER NOT NULL DEFAULT 1,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (now()::text),
  updated_at TEXT NOT NULL DEFAULT (now()::text)
);

CREATE INDEX IF NOT EXISTS services_public_order ON services(is_active, sort_order);

CREATE TABLE IF NOT EXISTS campaigns (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  kind TEXT NOT NULL DEFAULT 'studio',
  placement TEXT NOT NULL DEFAULT 'announcements',
  media_url TEXT NOT NULL DEFAULT '',
  cta_label TEXT NOT NULL DEFAULT '',
  destination_url TEXT NOT NULL DEFAULT '',
  start_at TEXT,
  end_at TEXT,
  status TEXT NOT NULL DEFAULT 'draft',
  sort_order INTEGER NOT NULL DEFAULT 0,
  impressions INTEGER NOT NULL DEFAULT 0,
  clicks INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (now()::text),
  updated_at TEXT NOT NULL DEFAULT (now()::text)
);

CREATE INDEX IF NOT EXISTS campaigns_public_schedule ON campaigns(status, placement, start_at, end_at, sort_order);

CREATE TABLE IF NOT EXISTS bookings (
  id TEXT PRIMARY KEY,
  reference TEXT NOT NULL UNIQUE,
  customer_name TEXT NOT NULL,
  phone TEXT NOT NULL,
  email TEXT,
  service_id TEXT NOT NULL REFERENCES services(id),
  service_name TEXT NOT NULL,
  quoted_price REAL NOT NULL,
  currency TEXT NOT NULL,
  preferred_at TEXT NOT NULL,
  duration_minutes INTEGER NOT NULL DEFAULT 60,
  project_details TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'pending',
  admin_note TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT (now()::text),
  updated_at TEXT NOT NULL DEFAULT (now()::text)
);

CREATE INDEX IF NOT EXISTS bookings_schedule ON bookings(status, preferred_at);
CREATE INDEX IF NOT EXISTS bookings_reference ON bookings(reference);

CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  updated_at TEXT NOT NULL DEFAULT (now()::text)
);

CREATE TABLE IF NOT EXISTS audit_logs (
  id TEXT PRIMARY KEY,
  admin_id TEXT REFERENCES admins(id) ON DELETE SET NULL,
  action TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  entity_id TEXT,
  details TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT (now()::text)
);

CREATE INDEX IF NOT EXISTS audit_recent ON audit_logs(created_at DESC);

INSERT INTO settings(key, value) VALUES
  ('studio_name', 'YJ Studio'),
  ('hero_title', 'Sound that stays with you.'),
  ('hero_subtitle', 'Audio engineering, music production and visual storytelling shaped with precision.'),
  ('about_text', 'YJ Studio is a creative recording space for artists who care about the details. From the first take to the final master, every project receives focused engineering and a sound of its own.'),
  ('contact_phone', ''),
  ('whatsapp_number', ''),
  ('contact_email', ''),
  ('youtube_url', ''),
  ('instagram_url', ''),
  ('footer_note', 'Created & Engineered by Engineer Yousab'),
  ('seo_title', 'YJ Studio | Sound Engineering & Recording'),
  ('seo_description', 'Recording, music production, mixing, mastering and music-video production at YJ Studio.'),
  ('logo_path', '/yj-studio-logo.jpg'),
  ('upload_limit_mb', '80')
ON CONFLICT DO NOTHING;

INSERT INTO services(id, name, description, price, currency, billing_unit, duration_minutes, is_active, sort_order)
VALUES
  ('service-recording', 'Recording', 'Professional vocal and instrument recording with an experienced engineer.', 500, 'EGP', 'per hour', 60, 1, 10),
  ('service-mix-master', 'Mixing & Mastering', 'A balanced, release-ready mix and master shaped around your sound.', 1000, 'EGP', 'per track', NULL, 1, 20),
  ('service-complete', 'Mix + Master + Video', 'Mixing, mastering and a studio video shoot for your release.', 2000, 'EGP', 'per package', NULL, 1, 30)
ON CONFLICT DO NOTHING;

-- Source migration 0002_public_content_controls.sql; SQLite syntax adapted for PostgreSQL.
INSERT INTO settings(key, value) VALUES
  ('social_image', '/yj-studio-logo.jpg'),
  ('maintenance_message', ''),
  ('visible_sections', 'portfolio,services,offers,about,booking,contact'),
  ('nav_home', ''),
  ('nav_portfolio', ''),
  ('nav_services', ''),
  ('nav_offers', ''),
  ('nav_about', ''),
  ('nav_contact', ''),
  ('dashboard_booking_alerts', 'on')
ON CONFLICT DO NOTHING;

-- Source migration 0003_admin_roles.sql; SQLite syntax adapted for PostgreSQL.
CREATE TABLE IF NOT EXISTS roles (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  description TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS admin_roles (
  admin_id TEXT NOT NULL REFERENCES admins(id) ON DELETE CASCADE,
  role_id TEXT NOT NULL REFERENCES roles(id) ON DELETE RESTRICT,
  granted_at TEXT NOT NULL DEFAULT (now()::text),
  PRIMARY KEY (admin_id, role_id)
);

INSERT INTO roles(id, name, description) VALUES
  ('role-admin', 'admin', 'Full studio content and account administration.')
ON CONFLICT DO NOTHING;

INSERT INTO admin_roles(admin_id, role_id)
SELECT admins.id, roles.id FROM admins JOIN roles ON roles.name = 'admin'
ON CONFLICT DO NOTHING;


-- Source migration 0004_upload_format_settings.sql; SQLite syntax adapted for PostgreSQL.
INSERT INTO settings(key, value) VALUES
  ('upload_formats', 'image/jpeg,image/png,image/webp,audio/mpeg,audio/mp3,audio/wav,audio/x-wav,audio/ogg,audio/mp4,video/mp4,video/webm')
ON CONFLICT DO NOTHING;

-- Source migration 0005_bilingual_content.sql; SQLite syntax adapted for PostgreSQL.
ALTER TABLE projects ADD COLUMN title_ar TEXT NOT NULL DEFAULT '';
ALTER TABLE projects ADD COLUMN description_ar TEXT NOT NULL DEFAULT '';
ALTER TABLE projects ADD COLUMN credits_ar TEXT NOT NULL DEFAULT '';

ALTER TABLE services ADD COLUMN name_ar TEXT NOT NULL DEFAULT '';
ALTER TABLE services ADD COLUMN description_ar TEXT NOT NULL DEFAULT '';

ALTER TABLE campaigns ADD COLUMN title_ar TEXT NOT NULL DEFAULT '';
ALTER TABLE campaigns ADD COLUMN description_ar TEXT NOT NULL DEFAULT '';
ALTER TABLE campaigns ADD COLUMN cta_label_ar TEXT NOT NULL DEFAULT '';

ALTER TABLE bookings ADD COLUMN service_name_ar TEXT NOT NULL DEFAULT '';

UPDATE services
SET name_ar = 'التسجيل', description_ar = 'تسجيل احترافي للصوت والغناء مع مهندس صوت ذي خبرة.'
WHERE id = 'service-recording' AND name_ar = '';
UPDATE services
SET name_ar = 'المكس والماستر', description_ar = 'مكس وماستر متوازن وجاهز للإصدار، مصمم بما يناسب صوتك.'
WHERE id = 'service-mix-master' AND name_ar = '';
UPDATE services
SET name_ar = 'مكس وماستر وفيديو', description_ar = 'مكس وماستر وتصوير فيديو في الاستوديو لإصدارك.'
WHERE id = 'service-complete' AND name_ar = '';

INSERT INTO settings(key, value) VALUES
  ('studio_name_ar', 'استوديو YJ'),
  ('hero_title_ar', 'صوت يبقى معك.'),
  ('hero_subtitle_ar', 'هندسة صوتية وإنتاج موسيقي وسرد بصري متقن.'),
  ('about_text_ar', 'YJ Studio مساحة تسجيل إبداعية للفنانين الذين يهتمون بالتفاصيل. من التسجيل الأول حتى الماستر النهائي، يحظى كل مشروع بهندسة دقيقة وصوت يميّزه.'),
  ('footer_note_ar', 'إبداع وهندسة صوتية: المهندس يوساب'),
  ('seo_title_ar', 'YJ Studio | هندسة صوتية وتسجيل'),
  ('seo_description_ar', 'تسجيل وإنتاج موسيقي ومكس وماستر وإنتاج فيديوهات موسيقية في YJ Studio.'),
  ('maintenance_message_ar', ''),
  ('nav_home_ar', ''),
  ('nav_portfolio_ar', ''),
  ('nav_services_ar', ''),
  ('nav_offers_ar', ''),
  ('nav_about_ar', ''),
  ('nav_contact_ar', '')
ON CONFLICT DO NOTHING;


-- PostgreSQL equivalent of the SQLite default-role trigger.
CREATE OR REPLACE FUNCTION public.yj_assign_default_admin_role() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
BEGIN
 INSERT INTO public.admin_roles(admin_id, role_id) SELECT NEW.id, roles.id FROM public.roles WHERE roles.name='admin' ON CONFLICT DO NOTHING;
 RETURN NEW;
END; $$;
DROP TRIGGER IF EXISTS assign_default_admin_role ON public.admins;
CREATE TRIGGER assign_default_admin_role AFTER INSERT ON public.admins FOR EACH ROW EXECUTE FUNCTION public.yj_assign_default_admin_role();

-- App tables are server-only; browser roles receive no direct table privileges.
DO $$ DECLARE t text; BEGIN
 FOREACH t IN ARRAY ARRAY['admins','sessions','login_attempts','projects','services','campaigns','bookings','settings','audit_logs','roles','admin_roles'] LOOP
  EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY', t);
  EXECUTE format('REVOKE ALL ON TABLE public.%I FROM anon, authenticated', t);
 END LOOP;
END $$;

-- Private media bucket. Server-side secret key performs upload/download; browser clients cannot read/write objects directly.
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES ('yj-studio-media', 'yj-studio-media', false, 83886080,
  ARRAY['image/jpeg','image/png','image/webp','audio/mpeg','audio/mp3','audio/wav','audio/x-wav','audio/ogg','audio/mp4','video/mp4','video/webm'])
ON CONFLICT (id) DO UPDATE SET public = false, file_size_limit = 83886080;
REVOKE ALL ON TABLE storage.objects FROM anon, authenticated;
REVOKE ALL ON TABLE storage.buckets FROM anon, authenticated;
