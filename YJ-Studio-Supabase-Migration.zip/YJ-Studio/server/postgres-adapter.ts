import postgres, { type Sql } from 'postgres';
import type { D1Database, D1Result, D1Statement } from '../src/worker/types.js';

type QueryResult<T> = { rows: T[]; count: number };
type QueryFn = <T extends Record<string, unknown> = Record<string, unknown>>(query: string, params?: unknown[]) => Promise<QueryResult<T>>;

function pgSql(sql: string): string {
  // The existing worker uses SQLite/D1 positional '?' parameters. Translate only
  // placeholders and CURRENT_TIMESTAMP; the application query strings contain no '?' literals.
  let index = 0;
  return sql.replace(/\?/g, () => `$${++index}`).replace(/\bCURRENT_TIMESTAMP\b/g, '(now()::text)');
}

class PostgresStatement implements D1Statement {
  private params: unknown[] = [];
  private readonly query: QueryFn;
  private readonly sourceSql: string;
  constructor(query: QueryFn, sourceSql: string) { this.query = query; this.sourceSql = sourceSql; }
  bind(...values: unknown[]): D1Statement { this.params = values; return this; }
  async first<T = Record<string, unknown>>(): Promise<T | null> {
    const source = this.sourceSql.trim().replace(/;\s*$/, '');
    const sql = /\bLIMIT\s+\d+\s*$/i.test(source) ? source : `${source} LIMIT 1`;
    const result = await this.query<T & Record<string, unknown>>(pgSql(sql), this.params);
    return result.rows[0] ?? null;
  }
  async all<T = Record<string, unknown>>(): Promise<D1Result<T>> {
    const result = await this.query<T & Record<string, unknown>>(pgSql(this.sourceSql), this.params);
    return { results: result.rows, success: true, meta: { changes: result.count, last_row_id: 0 } };
  }
  async run(): Promise<D1Result> {
    const result = await this.query(pgSql(this.sourceSql), this.params);
    return { results: [], success: true, meta: { changes: result.count, last_row_id: 0 } };
  }
  snapshot(): { sql: string; params: unknown[] } { return { sql: pgSql(this.sourceSql), params: this.params }; }
}

export class PostgresD1Adapter implements D1Database {
  private readonly client: Sql;
  constructor(client: Sql) { this.client = client; }
  private async query<T extends Record<string, unknown> = Record<string, unknown>>(query: string, params: unknown[] = []): Promise<QueryResult<T>> {
    const rows = await this.client.unsafe(query, params as never[]);
    return { rows: rows as unknown as T[], count: rows.count };
  }
  prepare(sql: string): D1Statement { return new PostgresStatement(this.query.bind(this), sql); }
  async batch(statements: D1Statement[]): Promise<D1Result[]> {
    const snapshots = statements.map((statement) => {
      if (!(statement instanceof PostgresStatement)) throw new Error('Unsupported statement in database batch.');
      return statement.snapshot();
    });
    return this.client.begin(async (tx) => {
      const output: D1Result[] = [];
      for (const statement of snapshots) {
        const rows = await tx.unsafe(statement.sql, statement.params as never[]);
        output.push({ results: [], success: true, meta: { changes: rows.count, last_row_id: 0 } });
      }
      return output;
    });
  }
}

export function createPostgresAdapter(connectionString: string): { db: PostgresD1Adapter; close: () => Promise<void> } {
  const client = postgres(connectionString, {
    max: Number(process.env.DB_POOL_MAX ?? 5),
    idle_timeout: 20,
    connect_timeout: 15,
    prepare: false,
    ssl: 'require',
  });
  return { db: new PostgresD1Adapter(client), close: () => client.end({ timeout: 5 }) };
}
