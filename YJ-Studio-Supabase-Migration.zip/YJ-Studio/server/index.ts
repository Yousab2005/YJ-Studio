import { serve } from '@hono/node-server';
import { stat } from 'node:fs/promises';
import { resolve, extname, sep } from 'node:path';
import { Readable } from 'node:stream';
import worker from '../src/worker/index.js';
import type { Env, R2Bucket, R2ObjectBody } from '../src/worker/types.js';
import { createPostgresAdapter } from './postgres-adapter.js';

const required = ['SUPABASE_DB_URL', 'SUPABASE_URL', 'SUPABASE_SECRET_KEY'] as const;
for (const key of required) if (!process.env[key]) throw new Error(`Missing required environment variable: ${key}`);
const storageUrl = process.env.SUPABASE_URL!.replace(/\/$/, '');
const storageKey = process.env.SUPABASE_SECRET_KEY!;
const storageHeaders = (): Record<string, string> => storageKey.startsWith('sb_secret_')
  ? { apikey: storageKey }
  : { apikey: storageKey, Authorization: `Bearer ${storageKey}` };
const bucket = process.env.SUPABASE_STORAGE_BUCKET || 'yj-studio-media';
const { db, close } = createPostgresAdapter(process.env.SUPABASE_DB_URL!);

function objectPath(key: string): string { return key.split('/').map(encodeURIComponent).join('/'); }
const media: R2Bucket = {
  async put(key, value, options) {
    const body = typeof value === 'string' ? value : value instanceof ArrayBuffer ? value : ArrayBuffer.isView(value) ? value : value;
    const response = await fetch(`${storageUrl}/storage/v1/object/${encodeURIComponent(bucket)}/${objectPath(key)}?upsert=true`, {
      method: 'POST', headers: { ...storageHeaders(), 'Content-Type': options?.httpMetadata?.contentType || 'application/octet-stream', 'Cache-Control': options?.httpMetadata?.cacheControl || 'private, no-store', 'x-upsert': 'true' }, body: body as never,
    });
    if (!response.ok) throw new Error(`Supabase Storage upload failed (${response.status}).`);
    return { key };
  },
  async get(key) {
    const response = await fetch(`${storageUrl}/storage/v1/object/${encodeURIComponent(bucket)}/${objectPath(key)}`, {
      headers: storageHeaders(),
    });
    if (response.status === 404) return null;
    if (!response.ok || !response.body) throw new Error(`Supabase Storage download failed (${response.status}).`);
    const headers = response.headers;
    const contentType = headers.get('content-type') || 'application/octet-stream';
    const cacheControl = headers.get('cache-control') || 'private, no-store';
    const size = Number(headers.get('content-length') || 0);
    const body = response.body;
    return {
      body, size, etag: headers.get('etag') || '', httpMetadata: { contentType, cacheControl },
      writeHttpMetadata(out: Headers) { out.set('Content-Type', contentType); out.set('Cache-Control', cacheControl); },
    } satisfies R2ObjectBody;
  },
};

const root = resolve(process.cwd(), 'dist');
const mime: Record<string, string> = { '.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json','.webmanifest':'application/manifest+json','.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.webp':'image/webp','.ico':'image/x-icon','.woff2':'font/woff2' };
const assets = {
  async fetch(request: Request): Promise<Response> {
    const url = new URL(request.url);
    let path: string;
    try { path = resolve(root, `.${decodeURIComponent(url.pathname)}`); } catch { return new Response('Bad request', { status: 400 }); }
    if (path !== root && !path.startsWith(root + sep)) return new Response('Forbidden', { status: 403 });
    try {
      let info = await stat(path);
      if (info.isDirectory()) { path = resolve(path, 'index.html'); info = await stat(path); }
      if (!info.isFile()) throw new Error('not a file');
    } catch {
      path = resolve(root, 'index.html');
      try { await stat(path); } catch { return new Response('Build assets not found. Run npm run build.', { status: 503 }); }
    }
    const body = request.method === 'HEAD' ? null : Readable.toWeb((await import('node:fs')).createReadStream(path)) as ReadableStream;
    return new Response(body, { headers: { 'Content-Type': mime[extname(path)] || 'application/octet-stream', 'Content-Length': String((await stat(path)).size), 'Cache-Control': /(?:index\.html|sw\.js|manifest(?:-light)?\.webmanifest)$/.test(path) ? 'no-cache' : 'public, max-age=31536000, immutable' } });
  },
};

const env: Env = { DB: db, MEDIA: media, ASSETS: assets, NODE_ENV: process.env.NODE_ENV || 'production', ALLOWED_ORIGINS: process.env.ALLOWED_ORIGINS || '' };
const port = Number(process.env.PORT || 8787);
const server = serve({ port, fetch: (request) => worker.fetch(request, env) }, (info) => console.log(`YJ Studio server listening on ${info.port}`));
for (const signal of ['SIGINT', 'SIGTERM'] as const) process.on(signal, () => { server.close(); void close(); });
