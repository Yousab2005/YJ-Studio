ALTER TABLE projects ADD COLUMN title_ar TEXT NOT NULL DEFAULT '';
ALTER TABLE projects ADD COLUMN description_ar TEXT NOT NULL DEFAULT '';
ALTER TABLE projects ADD COLUMN credits_ar TEXT NOT NULL DEFAULT '';

ALTER TABLE services ADD COLUMN name_ar TEXT NOT NULL DEFAULT '';
ALTER TABLE services ADD COLUMN description_ar TEXT NOT NULL DEFAULT '';

ALTER TABLE campaigns ADD COLUMN title_ar TEXT NOT NULL DEFAULT '';
ALTER TABLE campaigns ADD COLUMN description_ar TEXT NOT NULL DEFAULT '';
ALTER TABLE campaigns ADD COLUMN cta_label_ar TEXT NOT NULL DEFAULT '';

ALTER TABLE bookings ADD COLUMN service_name_ar TEXT NOT NULL DEFAULT '';

UPDATE services
SET name_ar = 'التسجيل', description_ar = 'تسجيل احترافي للصوت والغناء مع مهندس صوت ذي خبرة.'
WHERE id = 'service-recording' AND name_ar = '';
UPDATE services
SET name_ar = 'المكس والماستر', description_ar = 'مكس وماستر متوازن وجاهز للإصدار، مصمم بما يناسب صوتك.'
WHERE id = 'service-mix-master' AND name_ar = '';
UPDATE services
SET name_ar = 'مكس وماستر وفيديو', description_ar = 'مكس وماستر وتصوير فيديو في الاستوديو لإصدارك.'
WHERE id = 'service-complete' AND name_ar = '';

INSERT OR IGNORE INTO settings(key, value) VALUES
  ('studio_name_ar', 'استوديو YJ'),
  ('hero_title_ar', 'صوت يبقى معك.'),
  ('hero_subtitle_ar', 'هندسة صوتية وإنتاج موسيقي وسرد بصري متقن.'),
  ('about_text_ar', 'YJ Studio مساحة تسجيل إبداعية للفنانين الذين يهتمون بالتفاصيل. من التسجيل الأول حتى الماستر النهائي، يحظى كل مشروع بهندسة دقيقة وصوت يميّزه.'),
  ('footer_note_ar', 'إبداع وهندسة صوتية: المهندس يوساب'),
  ('seo_title_ar', 'YJ Studio | هندسة صوتية وتسجيل'),
  ('seo_description_ar', 'تسجيل وإنتاج موسيقي ومكس وماستر وإنتاج فيديوهات موسيقية في YJ Studio.'),
  ('maintenance_message_ar', ''),
  ('nav_home_ar', ''),
  ('nav_portfolio_ar', ''),
  ('nav_services_ar', ''),
  ('nav_offers_ar', ''),
  ('nav_about_ar', ''),
  ('nav_contact_ar', '');
