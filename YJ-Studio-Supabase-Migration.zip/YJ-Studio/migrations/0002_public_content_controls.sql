INSERT OR IGNORE INTO settings(key, value) VALUES
  ('social_image', '/yj-studio-logo.jpg'),
  ('maintenance_message', ''),
  ('visible_sections', 'portfolio,services,offers,about,booking,contact'),
  ('nav_home', ''),
  ('nav_portfolio', ''),
  ('nav_services', ''),
  ('nav_offers', ''),
  ('nav_about', ''),
  ('nav_contact', ''),
  ('dashboard_booking_alerts', 'on');
