INSERT OR IGNORE INTO settings(key, value) VALUES
  ('upload_formats', 'image/jpeg,image/png,image/webp,audio/mpeg,audio/mp3,audio/wav,audio/x-wav,audio/ogg,audio/mp4,video/mp4,video/webm');
