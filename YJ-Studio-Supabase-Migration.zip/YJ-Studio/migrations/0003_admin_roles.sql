CREATE TABLE IF NOT EXISTS roles (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  description TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS admin_roles (
  admin_id TEXT NOT NULL REFERENCES admins(id) ON DELETE CASCADE,
  role_id TEXT NOT NULL REFERENCES roles(id) ON DELETE RESTRICT,
  granted_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (admin_id, role_id)
);

INSERT OR IGNORE INTO roles(id, name, description) VALUES
  ('role-admin', 'admin', 'Full studio content and account administration.');

INSERT OR IGNORE INTO admin_roles(admin_id, role_id)
SELECT admins.id, roles.id FROM admins JOIN roles ON roles.name = 'admin';

CREATE TRIGGER IF NOT EXISTS assign_default_admin_role
AFTER INSERT ON admins
BEGIN
  INSERT OR IGNORE INTO admin_roles(admin_id, role_id)
  SELECT NEW.id, roles.id FROM roles WHERE roles.name = 'admin';
END;
