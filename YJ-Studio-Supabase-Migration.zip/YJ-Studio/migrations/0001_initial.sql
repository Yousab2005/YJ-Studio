CREATE TABLE IF NOT EXISTS admins (
  id TEXT PRIMARY KEY,
  username TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS sessions (
  token_hash TEXT PRIMARY KEY,
  admin_id TEXT NOT NULL REFERENCES admins(id) ON DELETE CASCADE,
  expires_at TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS login_attempts (
  ip_hash TEXT PRIMARY KEY,
  failed_count INTEGER NOT NULL DEFAULT 0,
  window_start TEXT NOT NULL,
  blocked_until TEXT
);

CREATE TABLE IF NOT EXISTS projects (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  category TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  tags_json TEXT NOT NULL DEFAULT '[]',
  credits TEXT NOT NULL DEFAULT '',
  release_date TEXT,
  cover_image TEXT NOT NULL DEFAULT '',
  media_json TEXT NOT NULL DEFAULT '[]',
  is_published INTEGER NOT NULL DEFAULT 0,
  is_featured INTEGER NOT NULL DEFAULT 0,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS projects_public_order ON projects(is_published, is_featured, sort_order, release_date);

CREATE TABLE IF NOT EXISTS services (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  price REAL NOT NULL DEFAULT 0,
  currency TEXT NOT NULL DEFAULT 'EGP',
  billing_unit TEXT NOT NULL DEFAULT 'per project',
  duration_minutes INTEGER,
  discount_price REAL,
  discount_start TEXT,
  discount_end TEXT,
  is_active INTEGER NOT NULL DEFAULT 1,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS services_public_order ON services(is_active, sort_order);

CREATE TABLE IF NOT EXISTS campaigns (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  kind TEXT NOT NULL DEFAULT 'studio',
  placement TEXT NOT NULL DEFAULT 'announcements',
  media_url TEXT NOT NULL DEFAULT '',
  cta_label TEXT NOT NULL DEFAULT '',
  destination_url TEXT NOT NULL DEFAULT '',
  start_at TEXT,
  end_at TEXT,
  status TEXT NOT NULL DEFAULT 'draft',
  sort_order INTEGER NOT NULL DEFAULT 0,
  impressions INTEGER NOT NULL DEFAULT 0,
  clicks INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS campaigns_public_schedule ON campaigns(status, placement, start_at, end_at, sort_order);

CREATE TABLE IF NOT EXISTS bookings (
  id TEXT PRIMARY KEY,
  reference TEXT NOT NULL UNIQUE,
  customer_name TEXT NOT NULL,
  phone TEXT NOT NULL,
  email TEXT,
  service_id TEXT NOT NULL REFERENCES services(id),
  service_name TEXT NOT NULL,
  quoted_price REAL NOT NULL,
  currency TEXT NOT NULL,
  preferred_at TEXT NOT NULL,
  duration_minutes INTEGER NOT NULL DEFAULT 60,
  project_details TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'pending',
  admin_note TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS bookings_schedule ON bookings(status, preferred_at);
CREATE INDEX IF NOT EXISTS bookings_reference ON bookings(reference);

CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS audit_logs (
  id TEXT PRIMARY KEY,
  admin_id TEXT REFERENCES admins(id) ON DELETE SET NULL,
  action TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  entity_id TEXT,
  details TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS audit_recent ON audit_logs(created_at DESC);

INSERT OR IGNORE INTO settings(key, value) VALUES
  ('studio_name', 'YJ Studio'),
  ('hero_title', 'Sound that stays with you.'),
  ('hero_subtitle', 'Audio engineering, music production and visual storytelling shaped with precision.'),
  ('about_text', 'YJ Studio is a creative recording space for artists who care about the details. From the first take to the final master, every project receives focused engineering and a sound of its own.'),
  ('contact_phone', ''),
  ('whatsapp_number', ''),
  ('contact_email', ''),
  ('youtube_url', ''),
  ('instagram_url', ''),
  ('footer_note', 'Created & Engineered by Engineer Yousab'),
  ('seo_title', 'YJ Studio | Sound Engineering & Recording'),
  ('seo_description', 'Recording, music production, mixing, mastering and music-video production at YJ Studio.'),
  ('logo_path', '/yj-studio-logo.jpg'),
  ('upload_limit_mb', '80');

INSERT OR IGNORE INTO services(id, name, description, price, currency, billing_unit, duration_minutes, is_active, sort_order)
VALUES
  ('service-recording', 'Recording', 'Professional vocal and instrument recording with an experienced engineer.', 500, 'EGP', 'per hour', 60, 1, 10),
  ('service-mix-master', 'Mixing & Mastering', 'A balanced, release-ready mix and master shaped around your sound.', 1000, 'EGP', 'per track', NULL, 1, 20),
  ('service-complete', 'Mix + Master + Video', 'Mixing, mastering and a studio video shoot for your release.', 2000, 'EGP', 'per package', NULL, 1, 30);
