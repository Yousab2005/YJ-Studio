import { createContext, useContext, useEffect, useMemo, useState, type FormEvent, type ReactNode } from 'react';
import {
  Activity, AlertCircle, ArrowDownUp, AudioLines, BadgePercent, CalendarClock, Check, ChevronRight, CircleHelp,
  Clock3, FileAudio2, Film, ImagePlus, LayoutDashboard, LogOut, Menu, Music2, Plus, Save, Settings2,
  ShieldCheck, Trash2, Upload, UserRound, UsersRound, Video, X,
} from 'lucide-react';
import { api, uploadMedia } from './api';
import type { Booking, Campaign, Project, Service, StudioSettings } from './shared';
import { defaultSettings, projectCategories, uploadFormatOptions } from './shared';
import { bookingReviewCount, localize, t, tx, txf, type Language, type ThemeMode } from './i18n';
import PreferenceControls from './PreferenceControls';

type Props = { language: Language; onLanguageChange: (language: Language) => void; themeMode: ThemeMode; onThemeChange: (mode: ThemeMode) => void };
type AdminUser = { id: string; username: string };
type ActivityItem = { id: string; username?: string; action: string; entity_type: string; entity_id: string | null; details: string; created_at: string };
type Overview = { projects: number; published: number; audio_tracks: number; videos: number; bookings: number; pending_bookings: number; confirmed_bookings: number; active_promotions: number; recent_activities: ActivityItem[] };
type Tab = 'overview' | 'projects' | 'services' | 'campaigns' | 'bookings' | 'settings';
type NoticeValues = Record<string, string | number>;
type ShowNotice = (type: 'success' | 'error', text: string, values?: NoticeValues) => void;
const LanguageContext = createContext<Language>('en');
const openedAt = new Date().toISOString();
const publicSections = [
  { id: 'portfolio', label: 'Portfolio' }, { id: 'services', label: 'Services' },
  { id: 'offers', label: 'Offers & announcements' }, { id: 'about', label: 'About' },
  { id: 'booking', label: 'Booking form' }, { id: 'contact', label: 'Contact' },
] as const;

const blankProject = (): Project => ({ title: '', title_ar: '', category: 'Music production', description: '', description_ar: '', tags: [], credits: '', credits_ar: '', release_date: '', cover_image: '', media: [], is_published: false, is_featured: false, sort_order: 0 });
const blankService = (): Service => ({ name: '', name_ar: '', description: '', description_ar: '', price: 0, currency: 'EGP', billing_unit: 'per project', duration_minutes: null, discount_price: null, discount_start: null, discount_end: null, is_active: true, sort_order: 0 });
const blankCampaign = (): Campaign => ({ title: '', title_ar: '', description: '', description_ar: '', kind: 'studio', placement: 'announcements', media_url: '', cta_label: '', cta_label_ar: '', destination_url: '', start_at: null, end_at: null, status: 'draft', sort_order: 0, impressions: 0, clicks: 0 });

function dateTimeLocal(value: string | null | undefined): string {
  if (!value) return '';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '';
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}T${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`;
}

function isoOrNull(value: string): string | null {
  if (!value) return null;
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? null : date.toISOString();
}

function dateLabel(value: string, language: Language, withTime = true): string {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat(language === 'ar' ? 'ar-EG' : 'en-EG', { dateStyle: 'medium', ...(withTime ? { timeStyle: 'short' as const } : {}) }).format(date);
}

function localDateKey(value: string): string {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '';
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
}

function humanBytes(file: File): string {
  return file.size > 1024 * 1024 ? `${(file.size / 1024 / 1024).toFixed(1)} MB` : `${Math.max(1, Math.round(file.size / 1024))} KB`;
}

function Field({ label, children, hint }: { label: string; children: ReactNode; hint?: string }) {
  const language = useContext(LanguageContext);
  return <label className="admin-field"><span>{tx(language, label)}</span>{children}{hint && <small>{tx(language, hint)}</small>}</label>;
}

function SectionHead({ eyebrow, title, description, action }: { eyebrow: string; title: string; description?: string; action?: ReactNode }) {
  const language = useContext(LanguageContext);
  return <div className="admin-section-head"><div><span className="eyebrow">{tx(language, eyebrow)}</span><h2>{tx(language, title)}</h2>{description && <p>{tx(language, description)}</p>}</div>{action}</div>;
}

export default function AdminSite({ language, onLanguageChange, themeMode, onThemeChange }: Props) {
  const [admin, setAdmin] = useState<AdminUser | null>(null);
  const [checking, setChecking] = useState(true);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState('');
  const [loginBusy, setLoginBusy] = useState(false);
  const [tab, setTab] = useState<Tab>('overview');
  const [mobileMenu, setMobileMenu] = useState(false);
  const [notice, setNotice] = useState<{ id: string; type: 'success' | 'error'; text: string; values?: NoticeValues } | null>(null);
  const [loadingData, setLoadingData] = useState(false);
  const [overview, setOverview] = useState<Overview | null>(null);
  const [projects, setProjects] = useState<Project[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [settings, setSettings] = useState<StudioSettings | null>(null);
  const [audit, setAudit] = useState<ActivityItem[]>([]);

  useEffect(() => {
    document.title = tx(language, 'YJ Studio administration');
    const description = document.querySelector('meta[name="description"]');
    const descriptionText = tx(language, 'Private dashboard for managing YJ Studio projects, services and bookings.');
    description?.setAttribute('content', descriptionText);
    document.querySelector('meta[property="og:title"]')?.setAttribute('content', document.title);
    document.querySelector('meta[property="og:description"]')?.setAttribute('content', descriptionText);
    const locale = document.querySelector('meta[property="og:locale"]');
    locale?.setAttribute('content', language === 'ar' ? 'ar_EG' : 'en_US');
  }, [language]);

  const navItems: { key: Tab; label: string; icon: typeof LayoutDashboard }[] = [
    { key: 'overview', label: t(language, 'overview'), icon: LayoutDashboard },
    { key: 'projects', label: t(language, 'projects'), icon: Music2 },
    { key: 'services', label: t(language, 'services'), icon: AudioLines },
    { key: 'campaigns', label: t(language, 'campaigns'), icon: BadgePercent },
    { key: 'bookings', label: t(language, 'bookings'), icon: CalendarClock },
    { key: 'settings', label: t(language, 'settings'), icon: Settings2 },
  ];
  const uploadFormats = settings?.upload_formats || defaultSettings.upload_formats;
  const uploadLimitMb = Math.max(1, Math.min(80, Number(settings?.upload_limit_mb) || 80));

  async function loadData() {
    setLoadingData(true);
    try {
      const [nextOverview, nextProjects, nextServices, nextCampaigns, nextBookings, nextSettings, nextAudit] = await Promise.all([
        api<Overview>('/api/admin/overview'), api<Project[]>('/api/admin/projects'), api<Service[]>('/api/admin/services'),
        api<Campaign[]>('/api/admin/campaigns'), api<Booking[]>('/api/admin/bookings'), api<StudioSettings>('/api/admin/settings'),
        api<ActivityItem[]>('/api/admin/audit'),
      ]);
      setOverview(nextOverview); setProjects(nextProjects); setServices(nextServices); setCampaigns(nextCampaigns);
      setBookings(nextBookings); setSettings(nextSettings); setAudit(nextAudit);
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Could not load dashboard data.';
      if (message.includes('sign in')) setAdmin(null);
      setNotice({ id: crypto.randomUUID(), type: 'error', text: message });
    } finally { setLoadingData(false); }
  }

  useEffect(() => {
    api<AdminUser & { authenticated: boolean }>('/api/admin/me').then((result) => {
      if (result.authenticated) { setAdmin({ id: result.id, username: result.username }); }
    }).catch(() => undefined).finally(() => setChecking(false));
  }, []);

  useEffect(() => {
    if (!admin) return;
    const timer = window.setTimeout(() => { void loadData(); }, 0);
    return () => window.clearTimeout(timer);
  }, [admin]);

  async function submitLogin(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setLoginError('');
    if (!username.trim() || !password) { setLoginError('Enter your username and password.'); return; }
    setLoginBusy(true);
    try {
      const result = await api<AdminUser>('/api/admin/login', { method: 'POST', body: JSON.stringify({ username: username.trim(), password }) });
      setAdmin(result); setPassword(''); setLoginError('');
    } catch (error) { setLoginError(error instanceof Error ? error.message : 'Could not sign in.'); }
    finally { setLoginBusy(false); }
  }

  async function signOut() {
    try { await api('/api/admin/logout', { method: 'POST', body: '{}' }); } finally { setAdmin(null); setTab('overview'); }
  }

  const showNotice: ShowNotice = (type, text, values) => {
    const id = crypto.randomUUID();
    setNotice({ id, type, text, values });
    window.setTimeout(() => setNotice((current) => current?.id === id ? null : current), 5500);
  };

  if (checking) return <LanguageContext.Provider value={language}><div className="admin-loading"><span className="spinner" /> {tx(language, 'Checking secure session…')}</div></LanguageContext.Provider>;

  if (!admin) return <LanguageContext.Provider value={language}><div className="admin-login-shell">
    <a href="/" className="login-back">{tx(language, 'Back to website')} <ChevronRight size={14} /></a>
    <div className="admin-login-card">
      <div className="login-mark"><img src="/yj-studio-logo.jpg" alt="YJ Studio" /></div>
      <div className="eyebrow"><ShieldCheck size={13} /> {tx(language, 'PRIVATE STUDIO ACCESS')}</div>
      <h1>{tx(language, 'Studio control room.')}</h1>
      <p>{tx(language, 'Sign in to manage projects, services, campaigns and bookings.')}</p>
      <form className="login-form" noValidate onSubmit={submitLogin}>
        {loginError && <div className="form-error" role="alert"><AlertCircle size={16} /> {tx(language, loginError)}</div>}
        <Field label={t(language, 'username')}><input autoFocus required autoComplete="username" value={username} onChange={(event) => setUsername(event.target.value)} /></Field>
        <Field label={t(language, 'password')}><input required type="password" autoComplete="current-password" value={password} onChange={(event) => setPassword(event.target.value)} /></Field>
        <button className="button button-primary login-submit" type="submit" disabled={loginBusy}>{loginBusy ? tx(language, 'Verifying…') : t(language, 'signIn')} <ChevronRight size={16} /></button>
      </form>
      <div className="setup-note"><CircleHelp size={15} /><p>{tx(language, 'Admin accounts are provisioned from the command line. See README for the secure first-admin setup.')}</p></div>
      <PreferenceControls language={language} onLanguageChange={onLanguageChange} themeMode={themeMode} onThemeChange={onThemeChange} className="login-preferences" />
    </div>
    <div className="login-footer">YJ STUDIO · ENGINEER YOUSAB</div>
  </div></LanguageContext.Provider>;

  return <LanguageContext.Provider value={language}><div className={`admin-shell ${language === 'ar' ? 'rtl' : ''}`}>
    <aside className={`admin-sidebar ${mobileMenu ? 'sidebar-open' : ''}`}>
      <a href="/" className="admin-brand"><img src={settings?.logo_path || '/yj-studio-logo.jpg'} alt="YJ Studio" /><span><b>YJ STUDIO</b><small>{tx(language, 'CONTROL ROOM')}</small></span></a>
      <div className="sidebar-label">{tx(language, 'WORKSPACE')}</div>
      <nav className="admin-nav" aria-label={tx(language, 'Dashboard sections')}>{navItems.map(({ key, label, icon: Icon }) => <button type="button" className={tab === key ? 'admin-nav-link selected' : 'admin-nav-link'} key={key} onClick={() => { setTab(key); setMobileMenu(false); }}><Icon size={17} /><span>{label}</span>{tab === key && <span className="nav-active-dot" />}</button>)}</nav>
      <div className="sidebar-spacer" />
      <div className="sidebar-preferences"><PreferenceControls language={language} onLanguageChange={onLanguageChange} themeMode={themeMode} onThemeChange={onThemeChange} /></div>
      <div className="sidebar-profile"><div className="profile-avatar"><UserRound size={17} /></div><div><b dir="ltr">{admin.username}</b><small>{tx(language, 'Studio administrator')}</small></div><span className="online-status" title={tx(language, 'Signed in')} /></div>
      <button type="button" className="signout-link" onClick={signOut}><LogOut size={16} /> {t(language, 'signOut')}</button>
      <div className="sidebar-foot">{tx(language, 'SECURE SESSION · 8 HOUR EXPIRY')}</div>
    </aside>

    <div className="admin-main-wrap">
      <header className="admin-topbar"><button type="button" className="mobile-menu-button" aria-label={tx(language, 'Open dashboard menu')} onClick={() => setMobileMenu((open) => !open)}>{mobileMenu ? <X /> : <Menu />}</button><div className="breadcrumbs"><span>YJ STUDIO</span><ChevronRight size={13} /><b>{navItems.find((item) => item.key === tab)?.label}</b></div><div className="topbar-actions"><span className="admin-live"><i /> {tx(language, 'SYSTEM LIVE')}</span><a href="/" className="view-site-link">{tx(language, 'View website')} <ChevronRight size={14} /></a></div></header>
      <main className="admin-content">
        {notice && <div className={`admin-notice ${notice.type}`} role="status"><span>{notice.type === 'success' ? <Check size={16} /> : <AlertCircle size={16} />}</span><p>{txf(language, notice.text, notice.values ?? {})}</p><button type="button" onClick={() => setNotice(null)} aria-label={tx(language, 'Dismiss')}><X size={15} /></button></div>}
        {loadingData && <div className="data-loading"><span className="spinner" /> {tx(language, 'Refreshing dashboard data…')}</div>}
        {tab === 'overview' && <OverviewPanel overview={overview} audit={audit} language={language} notificationEnabled={settings?.dashboard_booking_alerts !== 'off'} onNavigate={setTab} />}
        {tab === 'projects' && <ProjectsPanel projects={projects} uploadFormats={uploadFormats} uploadLimitMb={uploadLimitMb} language={language} showNotice={showNotice} onSaved={loadData} />}
        {tab === 'services' && <ServicesPanel services={services} language={language} showNotice={showNotice} onSaved={loadData} />}
        {tab === 'campaigns' && <CampaignsPanel campaigns={campaigns} uploadFormats={uploadFormats} uploadLimitMb={uploadLimitMb} language={language} showNotice={showNotice} onSaved={loadData} />}
        {tab === 'bookings' && <BookingsPanel bookings={bookings} language={language} showNotice={showNotice} onSaved={loadData} />}
        {tab === 'settings' && (settings ? <SettingsPanel settings={settings} audit={audit} language={language} showNotice={showNotice} onSaved={loadData} /> : <div className="dashboard-empty"><span className="spinner" /><p>{tx(language, 'Loading studio settings…')}</p></div>)}
      </main>
      <footer className="admin-footer"><span>YJ STUDIO ADMIN</span><span>{tx(language, 'YOUR CHANGES ARE SAVED TO THE STUDIO DATABASE')}</span><span>v1.0</span></footer>
    </div>
  </div></LanguageContext.Provider>;
}

function OverviewPanel({ overview, audit, language, notificationEnabled, onNavigate }: { overview: Overview | null; audit: ActivityItem[]; language: Language; notificationEnabled: boolean; onNavigate: (tab: Tab) => void }) {
  const stats = [
    { label: tx(language, 'Projects'), value: overview?.projects ?? 0, note: `${overview?.published ?? 0} ${tx(language, 'published')}`, icon: Music2 },
    { label: tx(language, 'Audio tracks'), value: overview?.audio_tracks ?? 0, note: tx(language, 'Across all projects'), icon: FileAudio2 },
    { label: tx(language, 'Video assets'), value: overview?.videos ?? 0, note: tx(language, 'Videos & YouTube links'), icon: Video },
    { label: tx(language, 'Pending bookings'), value: overview?.pending_bookings ?? 0, note: `${overview?.confirmed_bookings ?? 0} ${tx(language, 'confirmed')}`, icon: CalendarClock },
    { label: tx(language, 'Active promotions'), value: overview?.active_promotions ?? 0, note: tx(language, 'Live or in schedule'), icon: BadgePercent },
  ];
  return <>
    <SectionHead eyebrow="YOUR STUDIO, AT A GLANCE" title="Good to have you back." description="Here is what is happening across YJ Studio." action={<span className="today-label"><Activity size={15} /> {dateLabel(openedAt, language, false)}</span>} />
    {notificationEnabled && (overview?.pending_bookings ?? 0) > 0 && <button type="button" className="booking-alert" onClick={() => onNavigate('bookings')}><span className="booking-alert-icon"><CalendarClock size={17} /></span><span><b>{bookingReviewCount(language, overview?.pending_bookings ?? 0)}</b><small>{tx(language, 'Open the schedule to confirm, reschedule or reply.')}</small></span><ChevronRight size={16} /></button>}
    <div className="stat-grid">{stats.map(({ label, value, note, icon: Icon }) => <div className="stat-card" key={label}><div className="stat-card-top"><span>{label}</span><Icon size={17} /></div><strong>{value}</strong><small>{note}</small></div>)}</div>
    <div className="overview-lower-grid">
      <section className="dashboard-card quick-actions-card"><div className="card-head"><div><span className="eyebrow">{tx(language, 'GET MOVING')}</span><h3>{tx(language, 'Quick actions')}</h3></div><ArrowDownUp size={17} /></div><div className="quick-actions">
        <button type="button" onClick={() => onNavigate('projects')}><span><Plus size={16} /></span><b>{tx(language, 'Add a project')}</b><small>{tx(language, 'Publish new work to the portfolio')}</small><ChevronRight size={15} /></button>
        <button type="button" onClick={() => onNavigate('services')}><span><AudioLines size={16} /></span><b>{tx(language, 'Update pricing')}</b><small>{tx(language, 'Change a service or package')}</small><ChevronRight size={15} /></button>
        <button type="button" onClick={() => onNavigate('campaigns')}><span><BadgePercent size={16} /></span><b>{tx(language, 'New campaign')}</b><small>{tx(language, 'Plan an offer or announcement')}</small><ChevronRight size={15} /></button>
        <button type="button" onClick={() => onNavigate('bookings')}><span><UsersRound size={16} /></span><b>{tx(language, 'Review bookings')}</b><small>{tx(language, 'Confirm times and follow up')}</small><ChevronRight size={15} /></button>
      </div></section>
      <section className="dashboard-card activity-card"><div className="card-head"><div><span className="eyebrow">{tx(language, 'THE LATEST')}</span><h3>{tx(language, 'Recent activity')}</h3></div><Activity size={17} /></div>{audit.length ? <ul className="activity-list">{audit.slice(0, 7).map((item) => <li key={item.id}><span className="activity-dot" /><div><b>{tx(language, item.action)} {tx(language, item.entity_type)}</b><small>{item.details || item.entity_id || tx(language, 'Studio update')} · {dateLabel(item.created_at, language)}</small></div></li>)}</ul> : <div className="dashboard-empty"><Clock3 size={21} /><p>{tx(language, 'Admin changes will appear here.')}</p></div>}</section>
    </div>
  </>;
}

function ProjectsPanel({ projects, uploadFormats, uploadLimitMb, language, showNotice, onSaved }: { projects: Project[]; uploadFormats: string; uploadLimitMb: number; language: Language; showNotice: ShowNotice; onSaved: () => Promise<void> }) {
  const [project, setProject] = useState<Project>(blankProject());
  const [editing, setEditing] = useState(false);
  const [busy, setBusy] = useState(false);
  const [uploadPercent, setUploadPercent] = useState<number | null>(null);
  const [filter, setFilter] = useState('all');
  const [linkTitle, setLinkTitle] = useState('');
  const [linkTitleAr, setLinkTitleAr] = useState('');
  const [linkUrl, setLinkUrl] = useState('');
  const [linkKind, setLinkKind] = useState<'youtube' | 'external'>('youtube');
  const [preview, setPreview] = useState(false);
  const enabledFormats = new Set(uploadFormats.split(',').filter(Boolean));
  const imageAccept = uploadFormatOptions.filter((format) => format.category === 'image' && enabledFormats.has(format.mime)).map((format) => format.mime).join(',');
  const visible = projects.filter((item) => filter === 'all' || (filter === 'published' ? item.is_published : !item.is_published));
  const set = <K extends keyof Project>(key: K, value: Project[K]) => setProject((current) => ({ ...current, [key]: value }));
  const reset = () => { setProject(blankProject()); setEditing(false); setUploadPercent(null); setPreview(false); };
  const editProject = (item: Project) => { setProject({ ...item, tags: [...item.tags], media: [...item.media] }); setEditing(true); setPreview(false); window.scrollTo({ top: 0, behavior: 'smooth' }); };

  async function handleUpload(file: File, target: 'cover' | 'media') {
    if (!enabledFormats.has(file.type) || (target === 'cover' && !file.type.startsWith('image/'))) { showNotice('error', 'This file format is disabled in studio upload settings.'); return; }
    if (file.size > uploadLimitMb * 1024 * 1024) { showNotice('error', 'This file is larger than the {limit} MB upload limit.', { limit: uploadLimitMb }); return; }
    setUploadPercent(0);
    try {
      const result = await uploadMedia(file, setUploadPercent);
      if (target === 'cover') set('cover_image', result.url);
      else set('media', [...project.media, { ...result, id: result.id, title_ar: '' }]);
      showNotice('success', '{filename} ({size}) uploaded to studio media storage.', { filename: file.name, size: humanBytes(file) });
    } catch (error) { showNotice('error', error instanceof Error ? error.message : 'Upload failed.'); }
    finally { window.setTimeout(() => setUploadPercent(null), 900); }
  }

  async function save(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true);
    const payload = { ...project, tags: (Array.isArray(project.tags) ? project.tags : []).filter(Boolean) };
    try {
      await api(editing && project.id ? `/api/admin/projects/${project.id}` : '/api/admin/projects', { method: editing ? 'PUT' : 'POST', body: JSON.stringify(payload) });
      showNotice('success', editing ? 'Project changes saved.' : 'Project created.'); reset(); await onSaved();
    } catch (error) { showNotice('error', error instanceof Error ? error.message : 'Could not save this project.'); }
    finally { setBusy(false); }
  }

  async function remove(projectId: string) {
    if (!window.confirm('Delete this project? This removes the portfolio record and cannot be undone. Uploaded files stay in storage until reviewed.')) return;
    try { await api(`/api/admin/projects/${projectId}`, { method: 'DELETE' }); showNotice('success', 'Project deleted.'); await onSaved(); }
    catch (error) { showNotice('error', error instanceof Error ? error.message : 'Could not delete project.'); }
  }

  function addExternalMedia(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!linkUrl || !linkTitle) return;
    const url = linkUrl.trim();
    try {
      if (new URL(url).protocol !== 'https:') { showNotice('error', 'External media links must use HTTPS.'); return; }
    } catch { showNotice('error', 'Enter a valid HTTPS media link.'); return; }
    set('media', [...project.media, { id: crypto.randomUUID(), title: linkTitle.trim(), title_ar: linkTitleAr.trim(), kind: linkKind, url }]);
    setLinkTitle(''); setLinkTitleAr(''); setLinkUrl('');
  }

  return <>
    <SectionHead eyebrow="PORTFOLIO MANAGEMENT" title="Projects & releases" description="Create drafts, publish finished work, and keep the portfolio current." action={<span className="section-total"><Music2 size={15} /> {projects.length} RECORDS</span>} />
    <div className="editor-layout">
      <form className="dashboard-card editor-card" onSubmit={save}>
        <div className="card-head editor-card-head"><div><span className="eyebrow">{tx(language, editing ? 'EDIT EXISTING' : 'NEW PORTFOLIO ENTRY')}</span><h3>{editing ? localize(project.title, project.title_ar, language, tx(language, 'Edit project')) : tx(language, 'Project details')}</h3></div>{editing && <button type="button" className="icon-button" onClick={reset} aria-label={tx(language, 'Close project editor')}><X size={16} /></button>}</div>
        <div className="form-grid-admin"><Field label="Project title (English)"><input required minLength={2} maxLength={120} value={project.title} onChange={(event) => set('title', event.target.value)} placeholder={tx(language, 'e.g. Night Drive — Single')} dir="ltr" /></Field><Field label="Project title (Arabic)"><input maxLength={120} value={project.title_ar} onChange={(event) => set('title_ar', event.target.value)} placeholder={tx(language, 'Arabic title')} /></Field></div>
        <Field label="Category"><select value={project.category} onChange={(event) => set('category', event.target.value as Project['category'])}>{projectCategories.map((category) => <option key={category} value={category}>{tx(language, category)}</option>)}</select></Field>
        <div className="form-grid-admin"><Field label="Description (English)"><textarea rows={3} maxLength={4000} value={project.description} onChange={(event) => set('description', event.target.value)} placeholder={tx(language, 'Give visitors a sense of the project.')} dir="ltr" /></Field><Field label="Description (Arabic)"><textarea rows={3} maxLength={4000} value={project.description_ar} onChange={(event) => set('description_ar', event.target.value)} placeholder={tx(language, 'Arabic description')} /></Field></div>
        <div className="form-grid-admin"><Field label="Credits (English)"><input maxLength={500} value={project.credits} onChange={(event) => set('credits', event.target.value)} placeholder={tx(language, 'Artist · Engineer · Label')} dir="ltr" /></Field><Field label="Credits (Arabic)"><input maxLength={500} value={project.credits_ar} onChange={(event) => set('credits_ar', event.target.value)} placeholder={tx(language, 'Arabic credits')} /></Field></div>
        <div className="form-grid-admin"><Field label="Release date"><input type="date" value={(project.release_date || '').slice(0, 10)} onChange={(event) => set('release_date', event.target.value || null)} /></Field><Field label="Tags" hint="Comma separated · up to 20 tags"><input value={project.tags.join(', ')} onChange={(event) => set('tags', event.target.value.split(',').map((tag) => tag.trim()).filter(Boolean).slice(0, 20))} placeholder={tx(language, 'R&B, vocals, single')} /></Field></div>
        <div className="media-upload-block"><div className="upload-heading"><div><b>{tx(language, 'Cover image')}</b><small>{imageAccept || tx(language, 'No image formats enabled')} · {tx(language, 'up to')} {uploadLimitMb} MB</small></div>{project.cover_image && <span className="file-ready"><Check size={13} /> {tx(language, 'Selected')}</span>}</div><div className="cover-upload-row">{project.cover_image && <img src={project.cover_image} alt={tx(language, 'Project cover preview')} />}{!project.cover_image && <span className="upload-placeholder"><ImagePlus size={20} /></span>}<label className="file-picker"><Upload size={14} /> {project.cover_image ? tx(language, 'Replace cover') : tx(language, 'Upload cover')}<input type="file" accept={imageAccept} onChange={(event) => { const file = event.currentTarget.files?.[0]; if (file) void handleUpload(file, 'cover'); event.currentTarget.value = ''; }} /></label><span className="file-url-note">{project.cover_image ? tx(language, 'Uploaded to Supabase Storage') : tx(language, 'Choose a local file')}</span></div></div>
        <div className="media-upload-block"><div className="upload-heading"><div><b>{tx(language, 'Project media')}</b><small>{tx(language, 'Images, audio tracks, video files and YouTube links')}</small></div><span>{project.media.length} {tx(language, 'ITEMS')}</span></div>
          <label className="file-picker media-picker"><Upload size={15} /> {tx(language, 'Upload media files')}<input type="file" accept={uploadFormats} multiple onChange={(event) => { const files = Array.from(event.currentTarget.files ?? []); void files.reduce((chain, file) => chain.then(() => handleUpload(file, 'media')), Promise.resolve()); event.currentTarget.value = ''; }} /></label>
          {uploadPercent !== null && <div className="upload-progress-wrap"><div className="upload-progress-label"><span>{uploadPercent === 100 ? 'Finishing upload…' : 'Uploading media…'}</span><b>{uploadPercent}%</b></div><div className="upload-progress"><i style={{ width: `${uploadPercent}%` }} /></div></div>}
          {project.media.length > 0 && <ul className="uploaded-media-list">{project.media.map((item) => <li key={item.id}><span className={`media-kind ${item.kind}`}>{item.kind === 'image' ? <ImagePlus size={14} /> : item.kind === 'audio' ? <FileAudio2 size={14} /> : item.kind === 'video' ? <Film size={14} /> : <ArrowUpDownIcon />}</span><span><b>{localize(item.title, item.title_ar, language)}</b><small>{tx(language, item.kind)} · {item.url.startsWith('/api/media') ? tx(language, 'Supabase Storage media') : tx(language, 'External link')}</small></span><button type="button" className="icon-button danger-icon" onClick={() => set('media', project.media.filter((media) => media.id !== item.id))} aria-label={`${tx(language, 'Remove')} ${localize(item.title, item.title_ar, language)}`}><Trash2 size={14} /></button></li>)}</ul>}
          <form className="external-media-form" onSubmit={addExternalMedia}><select aria-label={tx(language, 'Media link type')} value={linkKind} onChange={(event) => setLinkKind(event.target.value as 'youtube' | 'external')}><option value="youtube">YouTube</option><option value="external">{tx(language, 'Other HTTPS')}</option></select><input aria-label={tx(language, 'Media title (English)')} value={linkTitle} onChange={(event) => setLinkTitle(event.target.value)} placeholder={tx(language, 'Link title (English)')} maxLength={140} dir="ltr" /><input aria-label={tx(language, 'Media title (Arabic)')} value={linkTitleAr} onChange={(event) => setLinkTitleAr(event.target.value)} placeholder={tx(language, 'Link title (Arabic)')} maxLength={140} /><input aria-label={tx(language, 'Media URL')} type="url" value={linkUrl} onChange={(event) => setLinkUrl(event.target.value)} placeholder="https://…" dir="ltr" /><button className="button button-outline button-compact" type="submit"><Plus size={14} /> {tx(language, 'Add')}</button></form>
        </div>
        <div className="project-flags"><label className="check-row"><input type="checkbox" checked={project.is_published} onChange={(event) => set('is_published', event.target.checked)} /><span><b>{tx(language, 'Publish project')}</b><small>{tx(language, 'Visible on the public website')}</small></span></label><label className="check-row"><input type="checkbox" checked={project.is_featured} onChange={(event) => set('is_featured', event.target.checked)} /><span><b>{tx(language, 'Feature project')}</b><small>{tx(language, 'Show in the featured work area')}</small></span></label></div>
        <div className="form-grid-admin"><Field label="Display order"><input type="number" min="0" max="100000" value={project.sort_order} onChange={(event) => set('sort_order', Number(event.target.value))} /></Field><Field label="Preview"><button type="button" className="button button-outline button-full" onClick={() => setPreview((current) => !current)}>{preview ? 'Hide preview' : 'Preview project'}</button></Field></div>
        {preview && <div className="project-live-preview"><span className="eyebrow">{tx(language, 'PREVIEW · NOT PUBLIC')}</span>{project.cover_image && <img src={project.cover_image} alt="" />}<h4>{localize(project.title, project.title_ar, language, tx(language, 'Untitled project'))}</h4><p>{localize(project.description, project.description_ar, language, tx(language, 'Your project description will appear here.'))}</p><small>{tx(language, project.category)} · {project.media.length} {tx(language, 'media items')}</small></div>}
        <div className="form-actions"><button type="button" className="button button-ghost" onClick={reset}>{t(language, 'cancel')}</button><button type="submit" className="button button-primary" disabled={busy}>{busy ? tx(language, 'Saving…') : editing ? t(language, 'saveChanges') : tx(language, 'Save project')} <Save size={15} /></button></div>
      </form>
      <section className="dashboard-card records-card"><div className="card-head"><div><span className="eyebrow">{tx(language, 'PORTFOLIO CONTENT')}</span><h3>{tx(language, 'All projects')}</h3></div><span className="record-count">{projects.length}</span></div><div className="record-filters"><button type="button" className={filter === 'all' ? 'active' : ''} onClick={() => setFilter('all')}>{tx(language, 'All')} <span>{projects.length}</span></button><button type="button" className={filter === 'published' ? 'active' : ''} onClick={() => setFilter('published')}>{t(language, 'published')} <span>{projects.filter((item) => item.is_published).length}</span></button><button type="button" className={filter === 'draft' ? 'active' : ''} onClick={() => setFilter('draft')}>{tx(language, 'Drafts')} <span>{projects.filter((item) => !item.is_published).length}</span></button></div>{visible.length ? <div className="project-record-list">{visible.map((item) => <article className="project-record" key={item.id}><div className="record-cover">{item.cover_image ? <img src={item.cover_image} alt="" loading="lazy" /> : <DiscIcon />}</div><div className="record-main"><div className="record-title-row"><h4>{localize(item.title, item.title_ar, language)}</h4><span className={`status-pill ${item.is_published ? 'status-live' : 'status-draft'}`}>{item.is_published ? t(language, 'published') : t(language, 'draft')}</span></div><p>{tx(language, item.category)} · {item.media.length} {tx(language, 'media')} · {item.is_featured ? tx(language, 'Featured') : tx(language, 'Standard')}</p><small>{tx(language, 'Updated')} {item.updated_at ? dateLabel(item.updated_at, language) : dateLabel(openedAt, language)}</small></div><div className="record-actions"><button type="button" onClick={() => editProject(item)}>{t(language, 'edit')}</button><button type="button" className="danger-text" onClick={() => void remove(item.id!)}>{t(language, 'delete')}</button></div></article>)}</div> : <div className="dashboard-empty"><Music2 size={22} /><p>{tx(language, 'No project records in this view yet.')}</p><small>{tx(language, 'Use the form to build the first portfolio entry.')}</small></div>}</section>
    </div>
  </>;
}

function ServicesPanel({ services, language, showNotice, onSaved }: { services: Service[]; language: Language; showNotice: ShowNotice; onSaved: () => Promise<void> }) {
  const [service, setService] = useState<Service>(blankService());
  const [editing, setEditing] = useState(false);
  const [busy, setBusy] = useState(false);
  const [showInactive, setShowInactive] = useState(true);
  const set = <K extends keyof Service>(key: K, value: Service[K]) => setService((current) => ({ ...current, [key]: value }));
  const reset = () => { setService(blankService()); setEditing(false); };
  const visible = services.filter((item) => showInactive || item.is_active);

  async function save(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true);
    const payload = { ...service, currency: service.currency.toUpperCase(), discount_start: isoOrNull(dateTimeLocal(service.discount_start)), discount_end: isoOrNull(dateTimeLocal(service.discount_end)) };
    try {
      await api(editing && service.id ? `/api/admin/services/${service.id}` : '/api/admin/services', { method: editing ? 'PUT' : 'POST', body: JSON.stringify(payload) });
      showNotice('success', editing ? 'Service pricing saved and is live.' : 'Service added to the price list.'); reset(); await onSaved();
    } catch (error) { showNotice('error', error instanceof Error ? error.message : 'Could not save the service.'); }
    finally { setBusy(false); }
  }

  async function remove(id?: string) {
    if (!id || !window.confirm('Delete this service? Services with booking history must be disabled instead.')) return;
    try { await api(`/api/admin/services/${id}`, { method: 'DELETE' }); showNotice('success', 'Service deleted.'); await onSaved(); }
    catch (error) { showNotice('error', error instanceof Error ? error.message : 'Could not delete service.'); }
  }

  return <>
    <SectionHead eyebrow="SERVICES & PRICING" title="Price list" description="Prices are loaded from the studio database and update publicly as soon as you save." action={<span className="section-total"><AudioLines size={15} /> {services.filter((item) => item.is_active).length} {tx(language, 'LIVE SERVICES')}</span>} />
    <div className="editor-layout service-editor-layout">
      <form className="dashboard-card editor-card" onSubmit={save}><div className="card-head editor-card-head"><div><span className="eyebrow">{tx(language, editing ? 'EDIT PRICING' : 'SERVICE SETUP')}</span><h3>{editing ? localize(service.name, service.name_ar, language, tx(language, 'Service details')) : tx(language, 'Service details')}</h3></div>{editing && <button type="button" className="icon-button" onClick={reset} aria-label={tx(language, 'Close service editor')}><X size={16} /></button>}</div>
        <div className="form-grid-admin"><Field label="Service name (English)"><input required minLength={2} maxLength={100} value={service.name} onChange={(event) => set('name', event.target.value)} placeholder={tx(language, 'e.g. Vocal recording')} dir="ltr" /></Field><Field label="Service name (Arabic)"><input maxLength={100} value={service.name_ar} onChange={(event) => set('name_ar', event.target.value)} placeholder={tx(language, 'Arabic service name')} /></Field></div>
        <div className="form-grid-admin"><Field label="Description (English)"><textarea rows={3} maxLength={2000} value={service.description} onChange={(event) => set('description', event.target.value)} placeholder={tx(language, 'Describe what this service includes.')} dir="ltr" /></Field><Field label="Description (Arabic)"><textarea rows={3} maxLength={2000} value={service.description_ar} onChange={(event) => set('description_ar', event.target.value)} placeholder={tx(language, 'Arabic description')} /></Field></div>
        <div className="form-grid-admin three-cols"><Field label="Base price"><input required type="number" min="0" step="0.01" value={service.price} onChange={(event) => set('price', Number(event.target.value))} /></Field><Field label="Currency"><input required minLength={3} maxLength={6} value={service.currency} onChange={(event) => set('currency', event.target.value.toUpperCase())} dir="ltr" /></Field><Field label="Billing unit"><select value={service.billing_unit} onChange={(event) => set('billing_unit', event.target.value)}>{['per hour', 'per track', 'per project', 'per package', 'per session'].map((unit) => <option key={unit} value={unit}>{tx(language, unit)}</option>)}</select></Field></div>
        <Field label="Default session length (minutes)" hint="Leave blank for services priced per track, project or package."><input type="number" min="15" max="1440" value={service.duration_minutes ?? ''} onChange={(event) => set('duration_minutes', event.target.value ? Number(event.target.value) : null)} /></Field>
        <div className="discount-editor"><div className="upload-heading"><div><b>{tx(language, 'Promotional price')}</b><small>{tx(language, 'Optional · automatically applies in the chosen dates')}</small></div><BadgePercent size={17} /></div><div className="form-grid-admin three-cols"><Field label="Discount price"><input type="number" min="0" step="0.01" value={service.discount_price ?? ''} onChange={(event) => set('discount_price', event.target.value ? Number(event.target.value) : null)} dir="ltr" /></Field><Field label="Starts"><input type="datetime-local" value={dateTimeLocal(service.discount_start)} onChange={(event) => set('discount_start', isoOrNull(event.target.value))} dir="ltr" /></Field><Field label="Ends"><input type="datetime-local" value={dateTimeLocal(service.discount_end)} onChange={(event) => set('discount_end', isoOrNull(event.target.value))} dir="ltr" /></Field></div></div>
        <div className="service-preview-shell"><span className="eyebrow">{tx(language, 'PUBLIC SERVICE CARD PREVIEW')}</span><article className="service-public-preview"><span className="preview-service-mark"><AudioLines size={16} /></span><span className="preview-billing">{tx(language, service.billing_unit || 'billing unit')}</span><h4>{localize(service.name, service.name_ar, language, tx(language, 'Service name'))}</h4><p>{localize(service.description, service.description_ar, language, tx(language, 'Your service description will appear here.'))}</p><b dir="ltr">{service.currency || 'EGP'} {service.discount_price ?? service.price}</b></article></div>
        <div className="form-grid-admin"><Field label="Display order"><input type="number" min="0" max="100000" value={service.sort_order} onChange={(event) => set('sort_order', Number(event.target.value))} /></Field><label className="check-row active-check"><input type="checkbox" checked={service.is_active} onChange={(event) => set('is_active', event.target.checked)} /><span><b>{tx(language, 'Available to book')}</b><small>{tx(language, 'Visible to public visitors')}</small></span></label></div>
        <div className="form-actions"><button type="button" className="button button-ghost" onClick={reset}>{t(language, 'cancel')}</button><button type="submit" className="button button-primary" disabled={busy}>{busy ? 'Saving…' : editing ? t(language, 'saveChanges') : 'Add service'} <Save size={15} /></button></div>
      </form>
      <section className="dashboard-card records-card"><div className="card-head"><div><span className="eyebrow">{tx(language, 'PUBLIC PRICE LIST')}</span><h3>{tx(language, 'Current services')}</h3></div><button type="button" className="switch-pill" onClick={() => setShowInactive((value) => !value)}>{tx(language, showInactive ? 'Showing all' : 'Active only')}</button></div><div className="service-record-list">{visible.map((item, index) => <article className={`service-record ${!item.is_active ? 'muted-record' : ''}`} key={item.id}><div className="service-record-icon">{index === 0 ? <AudioLines size={18} /> : <HeadphoneIcon />}</div><div className="service-record-main"><div className="record-title-row"><h4>{localize(item.name, item.name_ar, language)}</h4><span className={`status-pill ${item.is_active ? 'status-live' : 'status-draft'}`}>{item.is_active ? t(language, 'active') : tx(language, 'Hidden')}</span></div><p>{localize(item.description, item.description_ar, language, tx(language, item.billing_unit))}</p><div className="service-record-price">{item.discount_price !== null && item.discount_price !== undefined && <s><bdi dir="ltr">{item.currency} {item.price}</bdi></s>}<b><bdi dir="ltr">{item.currency} {item.discount_price ?? item.price}</bdi></b><small>{tx(language, item.billing_unit)}</small></div></div><div className="record-actions"><button type="button" onClick={() => { setService({ ...item }); setEditing(true); window.scrollTo({ top: 0, behavior: 'smooth' }); }}>{t(language, 'edit')}</button><button type="button" className="danger-text" onClick={() => void remove(item.id)}>{t(language, 'delete')}</button></div></article>)}{visible.length === 0 && <div className="dashboard-empty"><AudioLines size={22} /><p>{tx(language, 'No services yet.')}</p></div>}</div></section>
    </div>
  </>;
}

function CampaignsPanel({ campaigns, uploadFormats, uploadLimitMb, language, showNotice, onSaved }: { campaigns: Campaign[]; uploadFormats: string; uploadLimitMb: number; language: Language; showNotice: ShowNotice; onSaved: () => Promise<void> }) {
  const [campaign, setCampaign] = useState<Campaign>(blankCampaign());
  const [editing, setEditing] = useState(false);
  const [busy, setBusy] = useState(false);
  const [uploadPercent, setUploadPercent] = useState<number | null>(null);
  const [filter, setFilter] = useState('all');
  const [previewSize, setPreviewSize] = useState<'desktop' | 'mobile'>('desktop');
  const enabledFormats = new Set(uploadFormats.split(',').filter(Boolean));
  const bannerAccept = uploadFormatOptions.filter((format) => ['image', 'video'].includes(format.category) && enabledFormats.has(format.mime)).map((format) => format.mime).join(',');
  const set = <K extends keyof Campaign>(key: K, value: Campaign[K]) => setCampaign((current) => ({ ...current, [key]: value }));
  const reset = () => { setCampaign(blankCampaign()); setEditing(false); setUploadPercent(null); };
  const visible = campaigns.filter((item) => filter === 'all' || item.status === filter);

  async function save(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true);
    const payload = { ...campaign, start_at: isoOrNull(dateTimeLocal(campaign.start_at)), end_at: isoOrNull(dateTimeLocal(campaign.end_at)) };
    try {
      await api(editing && campaign.id ? `/api/admin/campaigns/${campaign.id}` : '/api/admin/campaigns', { method: editing ? 'PUT' : 'POST', body: JSON.stringify(payload) });
      showNotice('success', editing ? 'Campaign changes saved.' : 'Campaign created.'); reset(); await onSaved();
    } catch (error) { showNotice('error', error instanceof Error ? error.message : 'Could not save campaign.'); }
    finally { setBusy(false); }
  }

  async function uploadBanner(file: File) {
    if (!enabledFormats.has(file.type) || (!file.type.startsWith('image/') && !file.type.startsWith('video/'))) { showNotice('error', 'This campaign format is disabled in studio upload settings.'); return; }
    if (file.size > uploadLimitMb * 1024 * 1024) { showNotice('error', 'The file is larger than the {limit} MB upload limit.', { limit: uploadLimitMb }); return; }
    setUploadPercent(0);
    try { const result = await uploadMedia(file, setUploadPercent); set('media_url', result.url); showNotice('success', '{filename} uploaded.', { filename: file.name }); }
    catch (error) { showNotice('error', error instanceof Error ? error.message : 'Upload failed.'); }
    finally { window.setTimeout(() => setUploadPercent(null), 900); }
  }

  async function remove(id?: string) {
    if (!id || !window.confirm('Delete this campaign? This action cannot be undone.')) return;
    try { await api(`/api/admin/campaigns/${id}`, { method: 'DELETE' }); showNotice('success', 'Campaign deleted.'); await onSaved(); }
    catch (error) { showNotice('error', error instanceof Error ? error.message : 'Could not delete campaign.'); }
  }

  return <>
    <SectionHead eyebrow="PROMOTIONS & ANNOUNCEMENTS" title="Campaign manager" description="Create studio offers or partner announcements, then set placement and schedule." action={<span className="section-total"><BadgePercent size={15} /> {campaigns.length} {tx(language, 'CAMPAIGNS')}</span>} />
    <div className="editor-layout">
      <form className="dashboard-card editor-card" onSubmit={save}><div className="card-head editor-card-head"><div><span className="eyebrow">{tx(language, editing ? 'UPDATE CAMPAIGN' : 'CAMPAIGN SETUP')}</span><h3>{editing ? localize(campaign.title, campaign.title_ar, language) : tx(language, 'Campaign details')}</h3></div>{editing && <button type="button" className="icon-button" onClick={reset} aria-label={tx(language, 'Close campaign editor')}><X size={16} /></button>}</div>
        <div className="form-grid-admin"><Field label="Campaign title (English)"><input required minLength={2} maxLength={120} value={campaign.title} onChange={(event) => set('title', event.target.value)} placeholder={tx(language, 'Summer recording offer')} dir="ltr" /></Field><Field label="Campaign title (Arabic)"><input maxLength={120} value={campaign.title_ar} onChange={(event) => set('title_ar', event.target.value)} placeholder={tx(language, 'Arabic campaign title')} /></Field></div>
        <div className="form-grid-admin"><Field label="Description (English)"><textarea rows={3} maxLength={3000} value={campaign.description} onChange={(event) => set('description', event.target.value)} placeholder={tx(language, 'What should visitors know?')} dir="ltr" /></Field><Field label="Description (Arabic)"><textarea rows={3} maxLength={3000} value={campaign.description_ar} onChange={(event) => set('description_ar', event.target.value)} placeholder={tx(language, 'Arabic description')} /></Field></div>
        <div className="form-grid-admin"><Field label="Campaign type"><select value={campaign.kind} onChange={(event) => set('kind', event.target.value as Campaign['kind'])}><option value="studio">{tx(language, 'Studio promotion')}</option><option value="third-party">{tx(language, 'Third-party partner announcement')}</option></select></Field><Field label="Placement"><select value={campaign.placement} onChange={(event) => set('placement', event.target.value as Campaign['placement'])}>{['homepage hero', 'homepage banner', 'portfolio', 'services', 'announcements'].map((placement) => <option key={placement} value={placement}>{tx(language, placement)}</option>)}</select></Field></div>
        <div className="banner-upload"><div className="upload-heading"><div><b>{tx(language, 'Campaign artwork')}</b><small>{tx(language, 'Enabled image or video formats')} · {tx(language, 'up to')} {uploadLimitMb} MB</small></div><ImagePlus size={17} /></div>{campaign.media_url && (campaign.media_url.endsWith('.mp4') || campaign.media_url.endsWith('.webm') ? <video controls src={campaign.media_url} /> : <img src={campaign.media_url} alt={tx(language, 'Campaign preview')} />)}<label className="file-picker"><Upload size={14} /> {campaign.media_url ? tx(language, 'Replace artwork') : tx(language, 'Upload artwork')}<input type="file" accept={bannerAccept} onChange={(event) => { const file = event.currentTarget.files?.[0]; if (file) void uploadBanner(file); event.currentTarget.value = ''; }} /></label>{uploadPercent !== null && <div className="upload-progress"><i style={{ width: `${uploadPercent}%` }} /></div>}<Field label="Or use an existing HTTPS URL"><input type="url" value={campaign.media_url.startsWith('/api/media/') ? '' : campaign.media_url} onChange={(event) => set('media_url', event.target.value)} placeholder="https://…" dir="ltr" /></Field></div>
        <div className="form-grid-admin three-cols"><Field label="CTA label (English)"><input maxLength={50} value={campaign.cta_label} onChange={(event) => set('cta_label', event.target.value)} placeholder={tx(language, 'Book now')} dir="ltr" /></Field><Field label="CTA label (Arabic)"><input maxLength={50} value={campaign.cta_label_ar} onChange={(event) => set('cta_label_ar', event.target.value)} placeholder={tx(language, 'Book now')} dir="rtl" /></Field><Field label="Destination URL"><input type="text" maxLength={2048} value={campaign.destination_url} onChange={(event) => set('destination_url', event.target.value)} placeholder="https://… or /#booking" dir="ltr" /></Field></div>
        <div className="form-grid-admin"><Field label="Start date"><input type="datetime-local" value={dateTimeLocal(campaign.start_at)} onChange={(event) => set('start_at', isoOrNull(event.target.value))} dir="ltr" /></Field><Field label="End date"><input type="datetime-local" value={dateTimeLocal(campaign.end_at)} onChange={(event) => set('end_at', isoOrNull(event.target.value))} dir="ltr" /></Field></div>
        <div className="form-grid-admin"><Field label="Campaign status"><select value={campaign.status} onChange={(event) => set('status', event.target.value as Campaign['status'])}>{['draft', 'scheduled', 'active', 'paused', 'archived'].map((status) => <option key={status} value={status}>{t(language, status as Parameters<typeof t>[1]) || status}</option>)}</select></Field><Field label="Display order"><input type="number" min="0" max="100000" value={campaign.sort_order} onChange={(event) => set('sort_order', Number(event.target.value))} /></Field></div>
        <div className="campaign-preview-shell"><div className="campaign-preview-toolbar"><div><span className="eyebrow">{tx(language, 'PLACEMENT PREVIEW')}</span><small>{tx(language, campaign.placement)} · {tx(language, campaign.kind === 'studio' ? 'Studio promotion' : 'Partner announcement')}</small></div><div className="preview-size-toggle"><button type="button" className={previewSize === 'desktop' ? 'selected' : ''} onClick={() => setPreviewSize('desktop')}>{tx(language, 'Desktop')}</button><button type="button" className={previewSize === 'mobile' ? 'selected' : ''} onClick={() => setPreviewSize('mobile')}>{tx(language, 'Mobile')}</button></div></div><div className={`campaign-live-preview ${previewSize === 'mobile' ? 'mobile-preview' : ''}`} style={campaign.media_url && !/\.(mp4|webm)(\?|$)/i.test(campaign.media_url) ? { backgroundImage: `linear-gradient(90deg, rgba(5, 9, 13, .92), rgba(5, 9, 13, .58)), url("${campaign.media_url}")` } : undefined}><span>{tx(language, campaign.placement)}</span><h4>{localize(campaign.title, campaign.title_ar, language, tx(language, 'Campaign headline'))}</h4><p>{localize(campaign.description, campaign.description_ar, language, tx(language, 'Your campaign message will appear in this placement.'))}</p>{localize(campaign.cta_label, campaign.cta_label_ar, language) && <b>{localize(campaign.cta_label, campaign.cta_label_ar, language)} <ChevronRight size={13} /></b>}</div></div>
        <div className="form-actions"><button type="button" className="button button-ghost" onClick={reset}>{t(language, 'cancel')}</button><button type="submit" className="button button-primary" disabled={busy}>{busy ? tx(language, 'Saving…') : editing ? t(language, 'saveChanges') : tx(language, 'Create campaign')} <Save size={15} /></button></div>
      </form>
      <section className="dashboard-card records-card"><div className="card-head"><div><span className="eyebrow">{tx(language, 'CAMPAIGN LIBRARY')}</span><h3>{tx(language, 'Promotions & news')}</h3></div><span className="record-count">{campaigns.length}</span></div><div className="record-filters campaign-filter">{['all', 'active', 'scheduled', 'paused', 'draft', 'archived'].map((status) => <button type="button" className={filter === status ? 'active' : ''} key={status} onClick={() => setFilter(status)}>{status === 'all' ? tx(language, 'All') : t(language, status as Parameters<typeof t>[1]) || status}<span>{status === 'all' ? campaigns.length : campaigns.filter((item) => item.status === status).length}</span></button>)}</div><div className="campaign-record-list">{visible.map((item) => <article className="campaign-record" key={item.id}>{item.media_url && <div className="campaign-thumb">{item.media_url.endsWith('.mp4') || item.media_url.endsWith('.webm') ? <Video size={21} /> : <img src={item.media_url} alt="" loading="lazy" />}</div>}<div className="campaign-record-copy"><div className="record-title-row"><h4>{localize(item.title, item.title_ar, language)}</h4><span className={`status-pill status-${item.status}`}>{t(language, item.status as Parameters<typeof t>[1]) || item.status}</span></div><p>{localize(item.description, item.description_ar, language, tx(language, item.placement))}</p><small>{tx(language, item.kind === 'studio' ? 'Studio promotion' : 'Third-party announcement')} · {tx(language, item.placement)}</small>{(item.start_at || item.end_at) && <small className="campaign-dates">{item.start_at ? dateLabel(item.start_at, language) : tx(language, 'Any time')} → {item.end_at ? dateLabel(item.end_at, language) : tx(language, 'No end date')}</small>}<div className="campaign-metrics"><span><Activity size={13} /> {item.impressions ?? 0} {tx(language, 'views')}</span><span><ArrowUpDownIcon /> {item.clicks ?? 0} {tx(language, 'clicks')}</span></div></div><div className="record-actions"><button type="button" onClick={() => { setCampaign({ ...item }); setEditing(true); window.scrollTo({ top: 0, behavior: 'smooth' }); }}>{t(language, 'edit')}</button><button type="button" className="danger-text" onClick={() => void remove(item.id)}>{t(language, 'delete')}</button></div></article>)}{visible.length === 0 && <div className="dashboard-empty"><BadgePercent size={22} /><p>{tx(language, 'No campaigns in this view.')}</p><small>{tx(language, 'Create a studio offer or release announcement.')}</small></div>}</div></section>
    </div>
  </>;
}

function BookingsPanel({ bookings, language, showNotice, onSaved }: { bookings: Booking[]; language: Language; showNotice: ShowNotice; onSaved: () => Promise<void> }) {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [dayFilter, setDayFilter] = useState('');
  const [savingId, setSavingId] = useState('');
  const filtered = useMemo(() => bookings.filter((booking) => (statusFilter === 'all' || booking.status === statusFilter)
    && (!dayFilter || localDateKey(booking.preferred_at) === dayFilter)
    && (!search || `${booking.customer_name} ${booking.phone} ${booking.reference}`.toLowerCase().includes(search.toLowerCase()))), [bookings, dayFilter, search, statusFilter]);

  async function updateBooking(event: FormEvent<HTMLFormElement>, booking: Booking) {
    event.preventDefault(); setSavingId(booking.id);
    const form = new FormData(event.currentTarget);
    const preferred = String(form.get('preferred_at') || '');
    const payload = { status: String(form.get('status') || booking.status), preferred_at: isoOrNull(preferred), duration_minutes: Number(form.get('duration_minutes') || booking.duration_minutes), admin_note: String(form.get('admin_note') || '') };
    try { await api(`/api/admin/bookings/${booking.id}`, { method: 'PUT', body: JSON.stringify(payload) }); showNotice('success', 'Booking {reference} updated.', { reference: booking.reference }); await onSaved(); }
    catch (error) { showNotice('error', error instanceof Error ? error.message : 'Could not update booking.'); }
    finally { setSavingId(''); }
  }

  return <>
    <SectionHead eyebrow="APPOINTMENTS & CLIENTS" title="Booking schedule" description="Customer details stay private to the admin area. Review requests, avoid overlaps and keep the studio calendar current." action={<span className="section-total"><CalendarClock size={15} /> {bookings.length} BOOKINGS</span>} />
    <div className="booking-stats-row"><div><span>{t(language, 'pending')}</span><b>{bookings.filter((item) => item.status === 'pending').length}</b></div><div><span>{t(language, 'confirmed')}</span><b>{bookings.filter((item) => item.status === 'confirmed').length}</b></div><div><span>{t(language, 'completed')}</span><b>{bookings.filter((item) => item.status === 'completed').length}</b></div><div><span>{tx(language, 'All requests')}</span><b>{bookings.length}</b></div></div>
    <section className="dashboard-card bookings-card"><div className="booking-toolbar"><label className="booking-search"><span>⌕</span><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder={tx(language, 'Search name, phone or booking ref')} /></label><select value={statusFilter} onChange={(event) => setStatusFilter(event.target.value)} aria-label={tx(language, 'Filter booking status')}><option value="all">{tx(language, 'All statuses')}</option>{['pending', 'confirmed', 'completed', 'cancelled', 'rejected'].map((status) => <option key={status} value={status}>{t(language, status as Parameters<typeof t>[1])}</option>)}</select><label className="date-filter"><CalendarClock size={14} /><input type="date" value={dayFilter} onChange={(event) => setDayFilter(event.target.value)} aria-label={tx(language, 'Filter appointment date')} /></label><span className="filtered-count">{filtered.length} {tx(language, 'shown')}</span></div>
      {filtered.length ? <div className="booking-record-list">{filtered.map((booking) => <form className="booking-record" key={booking.id} onSubmit={(event) => void updateBooking(event, booking)}><div className="booking-record-head"><div className="customer-avatar"><UserRound size={18} /></div><div className="customer-main"><div className="record-title-row"><h3>{booking.customer_name}</h3><span className="booking-ref" dir="ltr">{booking.reference}</span></div><div className="customer-contact"><a href={`tel:${booking.phone}`} dir="ltr">{booking.phone}</a>{booking.email && <a href={`mailto:${booking.email}`} dir="ltr">{booking.email}</a>}</div></div><span className={`status-pill status-${booking.status}`}>{t(language, booking.status as Parameters<typeof t>[1])}</span></div>
        <div className="booking-summary"><span><AudioLines size={14} /> {localize(booking.service_name, booking.service_name_ar, language)}</span><span><Clock3 size={14} /> {booking.duration_minutes} {tx(language, 'min')}</span><span><CalendarClock size={14} /> {dateLabel(booking.preferred_at, language)}</span><b dir="ltr">{new Intl.NumberFormat(language === 'ar' ? 'ar-EG' : 'en-EG', { maximumFractionDigits: 0 }).format(booking.quoted_price)} {booking.currency}</b></div>
        {booking.project_details && <p className="booking-details">{booking.project_details}</p>}
        <div className="booking-admin-controls"><Field label="Status"><select name="status" defaultValue={booking.status}>{['pending', 'confirmed', 'completed', 'cancelled', 'rejected'].map((status) => <option key={status} value={status}>{t(language, status as Parameters<typeof t>[1])}</option>)}</select></Field><Field label="Reschedule"><input name="preferred_at" type="datetime-local" defaultValue={dateTimeLocal(booking.preferred_at)} dir="ltr" /></Field><Field label="Duration (minutes)"><input type="number" name="duration_minutes" min="30" max="600" defaultValue={booking.duration_minutes} dir="ltr" /></Field><Field label="Admin note"><input type="text" name="admin_note" maxLength={2000} defaultValue={booking.admin_note} placeholder={tx(language, 'Private note for the studio')} /></Field><button className="button button-outline booking-save" type="submit" disabled={savingId === booking.id}>{savingId === booking.id ? tx(language, 'Saving…') : tx(language, 'Save booking')} <Save size={14} /></button></div>
        <small className="booking-created">{tx(language, 'Requested')} {dateLabel(booking.created_at, language)}</small>
      </form>)}</div> : <div className="dashboard-empty booking-empty"><CalendarClock size={24} /><p>{tx(language, bookings.length ? 'No bookings match these filters.' : 'No booking requests yet.')}</p><small>{tx(language, 'New requests from the public site will appear here.')}</small></div>}
    </section>
  </>;
}

function SettingsPanel({ settings, audit, language, showNotice, onSaved }: { settings: StudioSettings | null; audit: ActivityItem[]; language: Language; showNotice: ShowNotice; onSaved: () => Promise<void> }) {
  const [draft, setDraft] = useState<StudioSettings | null>(settings);
  const [busy, setBusy] = useState(false);
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [passwordBusy, setPasswordBusy] = useState(false);
  const [uploadPercent, setUploadPercent] = useState<number | null>(null);
  const update = (key: keyof StudioSettings, value: string) => setDraft((current) => current ? { ...current, [key]: value } : current);
  const enabledFormats = new Set((draft?.upload_formats || defaultSettings.upload_formats).split(',').filter(Boolean));
  const enabledImageFormats = uploadFormatOptions.filter((format) => format.category === 'image' && enabledFormats.has(format.mime)).map((format) => format.mime).join(',');

  async function saveSettings(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); if (!draft) return; setBusy(true);
    try { await api('/api/admin/settings', { method: 'PUT', body: JSON.stringify({ settings: draft }) }); showNotice('success', 'Studio settings saved. Public pages now use the updated copy.'); await onSaved(); }
    catch (error) { showNotice('error', error instanceof Error ? error.message : 'Could not save settings.'); }
    finally { setBusy(false); }
  }

  async function updatePassword(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setPasswordBusy(true);
    try { await api('/api/admin/account/password', { method: 'POST', body: JSON.stringify({ current_password: currentPassword, new_password: newPassword }) }); setCurrentPassword(''); setNewPassword(''); showNotice('success', 'Administrator password updated. Other active sessions have not been signed out.'); }
    catch (error) { showNotice('error', error instanceof Error ? error.message : 'Could not update password.'); }
    finally { setPasswordBusy(false); }
  }

  async function uploadLogo(file: File) {
    if (!enabledImageFormats.split(',').includes(file.type)) { showNotice('error', 'This image format is disabled in studio upload settings.'); return; }
    if (file.size > 10 * 1024 * 1024) { showNotice('error', 'The logo file must be 10 MB or smaller.'); return; }
    setUploadPercent(0);
    try { const result = await uploadMedia(file, setUploadPercent); update('logo_path', result.url); showNotice('success', 'New studio logo uploaded. Save settings to publish it.'); }
    catch (error) { showNotice('error', error instanceof Error ? error.message : 'Logo upload failed.'); }
    finally { window.setTimeout(() => setUploadPercent(null), 900); }
  }

  if (!draft) return <div className="dashboard-empty"><Settings2 size={24} /><p>{tx(language, 'Settings could not be loaded.')}</p></div>;
  return <>
    <SectionHead eyebrow="STUDIO IDENTITY & CONTROL" title="Settings" description="Edit public studio information, metadata, contact links, upload limits and your administrator password." action={<span className="section-total"><ShieldCheck size={15} /> {tx(language, 'PRIVATE SETTINGS')}</span>} />
    <div className="settings-layout">
      <form className="dashboard-card editor-card settings-card" onSubmit={saveSettings}><div className="card-head"><div><span className="eyebrow">{tx(language, 'PUBLIC WEBSITE CONTENT')}</span><h3>{tx(language, 'Studio identity & copy')}</h3></div></div>
        <div className="settings-logo-row"><img src={draft.logo_path || '/yj-studio-logo.jpg'} alt={tx(language, 'Current studio logo')} /><div><b>{tx(language, 'Studio logo')}</b><small>{tx(language, 'Used in the site header, footer and app identity.')}</small><label className="file-picker"><Upload size={14} /> {tx(language, 'Upload new logo')}<input type="file" accept={enabledImageFormats} onChange={(event) => { const file = event.currentTarget.files?.[0]; if (file) void uploadLogo(file); event.currentTarget.value = ''; }} /></label>{uploadPercent !== null && <div className="upload-progress"><i style={{ width: `${uploadPercent}%` }} /></div>}</div></div>
        <div className="form-grid-admin"><Field label="Studio name (English)"><input maxLength={100} value={draft.studio_name} onChange={(event) => update('studio_name', event.target.value)} dir="ltr" /></Field><Field label="Studio name (Arabic)"><input maxLength={100} value={draft.studio_name_ar} onChange={(event) => update('studio_name_ar', event.target.value)} dir="rtl" /></Field></div>
        <div className="form-grid-admin"><Field label="Hero heading (English)"><input maxLength={160} value={draft.hero_title} onChange={(event) => update('hero_title', event.target.value)} dir="ltr" /></Field><Field label="Hero heading (Arabic)"><input maxLength={160} value={draft.hero_title_ar} onChange={(event) => update('hero_title_ar', event.target.value)} dir="rtl" /></Field></div>
        <div className="form-grid-admin"><Field label="Hero introduction (English)"><textarea rows={2} maxLength={600} value={draft.hero_subtitle} onChange={(event) => update('hero_subtitle', event.target.value)} dir="ltr" /></Field><Field label="Hero introduction (Arabic)"><textarea rows={2} maxLength={600} value={draft.hero_subtitle_ar} onChange={(event) => update('hero_subtitle_ar', event.target.value)} dir="rtl" /></Field></div>
        <div className="form-grid-admin"><Field label="About the studio (English)"><textarea rows={4} maxLength={4000} value={draft.about_text} onChange={(event) => update('about_text', event.target.value)} dir="ltr" /></Field><Field label="About the studio (Arabic)"><textarea rows={4} maxLength={4000} value={draft.about_text_ar} onChange={(event) => update('about_text_ar', event.target.value)} dir="rtl" /></Field></div>
        <div className="form-grid-admin"><Field label="WhatsApp number" hint="International format; digits will be used for the wa.me link."><input type="tel" maxLength={35} value={draft.whatsapp_number} onChange={(event) => update('whatsapp_number', event.target.value)} placeholder="+20 1…" dir="ltr" /></Field><Field label="Contact phone"><input type="tel" maxLength={35} value={draft.contact_phone} onChange={(event) => update('contact_phone', event.target.value)} dir="ltr" /></Field></div>
        <div className="form-grid-admin"><Field label="Contact email"><input type="email" maxLength={254} value={draft.contact_email} onChange={(event) => update('contact_email', event.target.value)} dir="ltr" /></Field><Field label="YouTube channel URL"><input type="url" maxLength={500} value={draft.youtube_url} onChange={(event) => update('youtube_url', event.target.value)} dir="ltr" /></Field></div>
        <div className="form-grid-admin"><Field label="Instagram URL"><input type="url" maxLength={500} value={draft.instagram_url} onChange={(event) => update('instagram_url', event.target.value)} dir="ltr" /></Field><Field label="Footer credit (English)"><input maxLength={400} value={draft.footer_note} onChange={(event) => update('footer_note', event.target.value)} dir="ltr" /></Field></div>
        <Field label="Footer credit (Arabic)"><input maxLength={400} value={draft.footer_note_ar} onChange={(event) => update('footer_note_ar', event.target.value)} dir="rtl" /></Field>
        <div className="settings-divider"><span>{tx(language, 'NAVIGATION & VISIBILITY')}</span></div>
        <div className="translation-editor"><b>{tx(language, 'Navigation labels (English)')}</b><div className="form-grid-admin three-cols">{([
          ['nav_home', 'Home'], ['nav_portfolio', 'Portfolio'], ['nav_services', 'Services'],
          ['nav_offers', 'Offers'], ['nav_about', 'About'], ['nav_contact', 'Contact'],
        ] as const).map(([key, label]) => <Field key={key} label={label}><input maxLength={40} value={draft[key]} placeholder={label} onChange={(event) => update(key, event.target.value)} dir="ltr" /></Field>)}</div></div>
        <div className="translation-editor"><b>{tx(language, 'Navigation labels (Arabic)')}</b><div className="form-grid-admin three-cols">{([
          ['nav_home_ar', 'Home'], ['nav_portfolio_ar', 'Portfolio'], ['nav_services_ar', 'Services'],
          ['nav_offers_ar', 'Offers'], ['nav_about_ar', 'About'], ['nav_contact_ar', 'Contact'],
        ] as const).map(([key, label]) => <Field key={key} label={label}><input maxLength={40} value={draft[key]} placeholder={tx(language, 'Arabic navigation label')} onChange={(event) => update(key, event.target.value)} dir="rtl" /></Field>)}</div></div>
        <div className="section-visibility"><b>{tx(language, 'Visible homepage sections')}</b><small>{tx(language, 'Unselected sections and their navigation links are hidden.')}</small><div className="section-switch-grid">{publicSections.map((section) => { const checked = (draft.visible_sections || '').split(',').includes(section.id); return <label className="check-row" key={section.id}><input type="checkbox" checked={checked} onChange={(event) => { const selected = new Set((draft.visible_sections || '').split(',').filter(Boolean)); if (event.target.checked) selected.add(section.id); else selected.delete(section.id); update('visible_sections', [...selected].join(',')); }} /><span><b>{tx(language, section.label)}</b></span></label>; })}</div></div>
        <div className="form-grid-admin"><Field label="Maintenance / announcement message (English)" hint="Leave blank to hide the message bar."><input maxLength={500} value={draft.maintenance_message} onChange={(event) => update('maintenance_message', event.target.value)} placeholder="A short temporary studio notice" dir="ltr" /></Field><Field label="Maintenance / announcement message (Arabic)" hint="Leave blank to hide the message bar."><input maxLength={500} value={draft.maintenance_message_ar} onChange={(event) => update('maintenance_message_ar', event.target.value)} dir="rtl" /></Field></div>
        <label className="check-row notification-preference"><input type="checkbox" checked={draft.dashboard_booking_alerts !== 'off'} onChange={(event) => update('dashboard_booking_alerts', event.target.checked ? 'on' : 'off')} /><span><b>{tx(language, 'Show pending booking alerts in the dashboard')}</b><small>{tx(language, 'In-dashboard only. No email or WhatsApp message is sent.')}</small></span></label>
        <div className="settings-divider"><span>{tx(language, 'SEARCH & MEDIA')}</span></div>
        <div className="upload-format-manager"><b>{tx(language, 'Enabled upload formats')}</b><small>{tx(language, "Choose from the studio's supported safe formats. Keep at least one image type enabled.")}</small><div className="upload-format-grid">{uploadFormatOptions.map((format) => { const checked = enabledFormats.has(format.mime); return <label className="upload-format-option" key={format.mime}><input type="checkbox" checked={checked} onChange={(event) => { const formats = new Set(enabledFormats); if (event.target.checked) formats.add(format.mime); else { const imageCount = uploadFormatOptions.filter((item) => item.category === 'image' && formats.has(item.mime)).length; if (format.category === 'image' && imageCount <= 1) { showNotice('error', 'At least one image format must stay enabled for project covers and the studio logo.'); return; } formats.delete(format.mime); } update('upload_formats', [...formats].join(',')); }} /><span><b>{tx(language, format.label)}</b><small>{tx(language, format.category)} · <bdi dir="ltr">{format.mime}</bdi></small></span></label>; })}</div></div>
        <div className="form-grid-admin"><Field label="SEO title (English)"><input maxLength={160} value={draft.seo_title} onChange={(event) => update('seo_title', event.target.value)} dir="ltr" /></Field><Field label="SEO title (Arabic)"><input maxLength={160} value={draft.seo_title_ar} onChange={(event) => update('seo_title_ar', event.target.value)} dir="rtl" /></Field></div>
        <Field label="Maximum upload size (MB)"><input type="number" min="1" max="80" value={draft.upload_limit_mb} onChange={(event) => update('upload_limit_mb', event.target.value)} /></Field>
        <div className="form-grid-admin"><Field label="SEO description (English)"><textarea rows={2} maxLength={320} value={draft.seo_description} onChange={(event) => update('seo_description', event.target.value)} dir="ltr" /></Field><Field label="SEO description (Arabic)"><textarea rows={2} maxLength={320} value={draft.seo_description_ar} onChange={(event) => update('seo_description_ar', event.target.value)} dir="rtl" /></Field></div>
        <Field label="Social sharing image URL"><input type="text" maxLength={2048} value={draft.social_image} onChange={(event) => update('social_image', event.target.value)} placeholder="https://… or /api/media/…" dir="ltr" /></Field>
        <div className="form-actions"><span className="save-hint">{tx(language, 'Saved content is visible to the public site.')}</span><button type="submit" className="button button-primary" disabled={busy}>{busy ? tx(language, 'Saving…') : t(language, 'saveChanges')} <Save size={15} /></button></div>
      </form>
      <div className="settings-side-column">
        <form className="dashboard-card password-card" onSubmit={updatePassword}><div className="card-head"><div><span className="eyebrow">{tx(language, 'ACCOUNT SECURITY')}</span><h3>{tx(language, 'Change password')}</h3></div><ShieldCheck size={18} /></div><Field label="Current password"><input type="password" autoComplete="current-password" required value={currentPassword} onChange={(event) => setCurrentPassword(event.target.value)} /></Field><Field label="New password" hint="At least 12 characters."><input type="password" autoComplete="new-password" required minLength={12} maxLength={300} value={newPassword} onChange={(event) => setNewPassword(event.target.value)} /></Field><button type="submit" className="button button-outline button-full" disabled={passwordBusy}>{passwordBusy ? tx(language, 'Updating…') : tx(language, 'Update administrator password')} <ShieldCheck size={15} /></button><small className="password-note">{tx(language, 'Passwords are stored as PBKDF2 hashes. No password is saved in this browser.')}</small></form>
        <section className="dashboard-card audit-card"><div className="card-head"><div><span className="eyebrow">{tx(language, 'ACCOUNTABILITY')}</span><h3>{tx(language, 'Audit trail')}</h3></div><Activity size={17} /></div>{audit.length ? <ul className="audit-list">{audit.slice(0, 12).map((item) => <li key={item.id}><span className="activity-dot" /><div><b>{tx(language, item.action)} · {tx(language, item.entity_type)}</b><small>{item.details || item.entity_id || '—'}</small><time>{dateLabel(item.created_at, language)}</time></div></li>)}</ul> : <div className="dashboard-empty"><Activity size={20} /><p>{tx(language, 'Administrative changes are recorded here.')}</p></div>}</section>
        <div className="security-note"><ShieldCheck size={17} /><div><b>{tx(language, 'Admin access is private')}</b><p>{tx(language, 'API changes require a valid server-side session. This account has no public registration route.')}</p></div></div>
      </div>
    </div>
  </>;
}

function ArrowUpDownIcon() { return <ArrowDownUp size={14} />; }
function DiscIcon() { return <span className="disc-placeholder"><AudioLines size={19} /></span>; }
function HeadphoneIcon() { return <span className="headphone-placeholder"><AudioLines size={17} /></span>; }
