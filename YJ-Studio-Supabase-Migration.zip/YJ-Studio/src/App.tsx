import { useEffect, useLayoutEffect, useState } from 'react';
import PublicSite from './PublicSite';
import AdminSite from './AdminSite';
import type { Language, ThemeMode } from './i18n';

type BeforeInstallPrompt = Event & { prompt: () => Promise<void>; userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }> };

function savedLanguage(): Language {
  try { return localStorage.getItem('yj-language') === 'en' ? 'en' : 'ar'; } catch { return 'ar'; }
}

function savedThemeMode(): ThemeMode {
  try {
    const value = localStorage.getItem('yj-theme-mode');
    return value === 'dark' || value === 'light' ? value : 'system';
  } catch { return 'system'; }
}

function resolvedTheme(mode: ThemeMode, systemPrefersLight: boolean): 'light' | 'dark' {
  return mode === 'system' ? (systemPrefersLight ? 'light' : 'dark') : mode;
}

export default function App() {
  const [language, setLanguage] = useState<Language>(savedLanguage);
  const [themeMode, setThemeMode] = useState<ThemeMode>(savedThemeMode);
  const [path, setPath] = useState(window.location.pathname);
  const [installPrompt, setInstallPrompt] = useState<BeforeInstallPrompt | null>(null);

  useEffect(() => {
    const handleNavigation = () => setPath(window.location.pathname);
    const handleInstallPrompt = (event: Event) => {
      event.preventDefault();
      setInstallPrompt(event as BeforeInstallPrompt);
    };
    window.addEventListener('popstate', handleNavigation);
    window.addEventListener('beforeinstallprompt', handleInstallPrompt);
    return () => {
      window.removeEventListener('popstate', handleNavigation);
      window.removeEventListener('beforeinstallprompt', handleInstallPrompt);
    };
  }, []);

  useLayoutEffect(() => {
    document.documentElement.lang = language;
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
    try { localStorage.setItem('yj-language', language); } catch { /* Preference remains active for this visit. */ }
  }, [language]);

  useLayoutEffect(() => {
    const media = window.matchMedia('(prefers-color-scheme: light)');
    const apply = () => {
      const resolved = resolvedTheme(themeMode, media.matches);
      document.documentElement.dataset.themeMode = themeMode;
      document.documentElement.dataset.theme = resolved;
      document.querySelector('meta[name="theme-color"]')?.setAttribute('content', resolved === 'light' ? '#f4f8fa' : '#071119');
      document.querySelector('link[rel="manifest"]')?.setAttribute('href', resolved === 'light' ? '/manifest-light.webmanifest' : '/manifest.webmanifest');
    };
    apply();
    media.addEventListener('change', apply);
    try { localStorage.setItem('yj-theme-mode', themeMode); } catch { /* Preference remains active for this visit. */ }
    return () => media.removeEventListener('change', apply);
  }, [themeMode]);

  useEffect(() => {
    const syncPreferences = (event: StorageEvent) => {
      if (event.key === 'yj-language') setLanguage(event.newValue === 'en' ? 'en' : 'ar');
      if (event.key === 'yj-theme-mode') setThemeMode(event.newValue === 'dark' || event.newValue === 'light' ? event.newValue : 'system');
    };
    window.addEventListener('storage', syncPreferences);
    return () => window.removeEventListener('storage', syncPreferences);
  }, []);

  const install = async () => {
    if (!installPrompt) return;
    await installPrompt.prompt();
    await installPrompt.userChoice;
    setInstallPrompt(null);
  };

  const sharedPreferences = { language, onLanguageChange: setLanguage, themeMode, onThemeChange: setThemeMode };
  if (path.startsWith('/admin')) return <AdminSite {...sharedPreferences} />;
  return <PublicSite {...sharedPreferences} onInstall={install} canInstall={Boolean(installPrompt)} />;
}
