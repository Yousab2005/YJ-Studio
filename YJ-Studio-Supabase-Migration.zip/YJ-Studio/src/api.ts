export async function api<T>(path: string, options: RequestInit = {}): Promise<T> {
  const headers = new Headers(options.headers);
  const method = (options.method ?? 'GET').toUpperCase();
  if (!['GET', 'HEAD', 'OPTIONS'].includes(method)) headers.set('X-YJ-Request', '1');
  if (options.body && !(options.body instanceof FormData) && !headers.has('Content-Type')) headers.set('Content-Type', 'application/json');
  const response = await fetch(path, { ...options, method, headers, credentials: 'include' });
  const body = await response.json().catch(() => ({})) as T & { error?: string };
  if (!response.ok) throw new Error(body.error || `Request failed (${response.status}).`);
  return body;
}

export function uploadMedia(file: File, onProgress: (percent: number) => void): Promise<{ id: string; url: string; kind: 'image' | 'audio' | 'video'; title: string; mime: string }> {
  return new Promise((resolve, reject) => {
    const request = new XMLHttpRequest();
    request.open('POST', '/api/admin/media');
    request.withCredentials = true;
    request.setRequestHeader('X-YJ-Request', '1');
    request.upload.onprogress = (event) => {
      if (event.lengthComputable) onProgress(Math.round((event.loaded / event.total) * 100));
    };
    request.onerror = () => reject(new Error('Upload failed. Check your connection and try again.'));
    request.onload = () => {
      const result = JSON.parse(request.responseText || '{}') as { error?: string; id: string; url: string; kind: 'image' | 'audio' | 'video'; title: string; mime: string };
      if (request.status < 200 || request.status >= 300) reject(new Error(result.error || `Upload failed (${request.status}).`));
      else resolve(result);
    };
    const data = new FormData();
    data.set('file', file);
    request.send(data);
  });
}
