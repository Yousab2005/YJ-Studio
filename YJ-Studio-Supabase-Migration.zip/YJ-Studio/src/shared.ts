import { z } from 'zod';

export const projectCategories = [
  'Music production',
  'Recording sessions',
  'Mixing & mastering',
  'Audio engineering',
  'Music videos',
] as const;

export const uploadFormatOptions = [
  { mime: 'image/jpeg', label: 'JPEG images', category: 'image' },
  { mime: 'image/png', label: 'PNG images', category: 'image' },
  { mime: 'image/webp', label: 'WebP images', category: 'image' },
  { mime: 'audio/mpeg', label: 'MP3 audio', category: 'audio' },
  { mime: 'audio/mp3', label: 'MP3 audio (alternate MIME)', category: 'audio' },
  { mime: 'audio/wav', label: 'WAV audio', category: 'audio' },
  { mime: 'audio/x-wav', label: 'WAV audio (alternate MIME)', category: 'audio' },
  { mime: 'audio/ogg', label: 'OGG audio', category: 'audio' },
  { mime: 'audio/mp4', label: 'M4A audio', category: 'audio' },
  { mime: 'video/mp4', label: 'MP4 video', category: 'video' },
  { mime: 'video/webm', label: 'WebM video', category: 'video' },
] as const;

export const mediaSchema = z.object({
  id: z.string().max(100),
  title: z.string().max(140),
  title_ar: z.string().max(140).default(''),
  kind: z.enum(['image', 'audio', 'video', 'youtube', 'external']),
  url: z.string().max(2048),
  mime: z.string().max(120).optional(),
});

export const projectSchema = z.object({
  id: z.string().max(80).optional(),
  title: z.string().trim().min(2).max(120),
  title_ar: z.string().max(120).default(''),
  category: z.enum(projectCategories),
  description: z.string().max(4000).default(''),
  description_ar: z.string().max(4000).default(''),
  tags: z.array(z.string().trim().min(1).max(30)).max(20).default([]),
  credits: z.string().max(500).default(''),
  credits_ar: z.string().max(500).default(''),
  release_date: z.string().max(30).nullable().optional(),
  cover_image: z.string().max(2048).default(''),
  media: z.array(mediaSchema).max(40).default([]),
  is_published: z.boolean().default(false),
  is_featured: z.boolean().default(false),
  sort_order: z.number().int().min(0).max(100000).default(0),
});

export const serviceSchema = z.object({
  id: z.string().max(80).optional(),
  name: z.string().trim().min(2).max(100),
  name_ar: z.string().max(100).default(''),
  description: z.string().max(2000).default(''),
  description_ar: z.string().max(2000).default(''),
  price: z.number().min(0).max(10000000),
  currency: z.string().trim().min(3).max(6).default('EGP'),
  billing_unit: z.string().trim().min(2).max(50).default('per project'),
  duration_minutes: z.number().int().min(15).max(1440).nullable().optional(),
  discount_price: z.number().min(0).max(10000000).nullable().optional(),
  discount_start: z.string().max(35).nullable().optional(),
  discount_end: z.string().max(35).nullable().optional(),
  is_active: z.boolean().default(true),
  sort_order: z.number().int().min(0).max(100000).default(0),
});

export const campaignSchema = z.object({
  id: z.string().max(80).optional(),
  title: z.string().trim().min(2).max(120),
  title_ar: z.string().max(120).default(''),
  description: z.string().max(3000).default(''),
  description_ar: z.string().max(3000).default(''),
  kind: z.enum(['studio', 'third-party']).default('studio'),
  placement: z.enum(['homepage hero', 'homepage banner', 'portfolio', 'services', 'announcements']).default('announcements'),
  media_url: z.string().max(2048).default(''),
  cta_label: z.string().max(50).default(''),
  cta_label_ar: z.string().max(50).default(''),
  destination_url: z.string().max(2048).default(''),
  start_at: z.string().max(35).nullable().optional(),
  end_at: z.string().max(35).nullable().optional(),
  status: z.enum(['draft', 'scheduled', 'active', 'paused', 'archived']).default('draft'),
  sort_order: z.number().int().min(0).max(100000).default(0),
});

export const bookingSchema = z.object({
  customer_name: z.string().trim().min(2).max(120),
  phone: z.string().trim().min(7).max(35),
  email: z.union([z.string().trim().email().max(254), z.literal('')]).optional(),
  service_id: z.string().min(1).max(80),
  preferred_at: z.string().min(10).max(35),
  duration_minutes: z.number().int().min(30).max(600).default(60),
  project_details: z.string().max(2000).default(''),
  language: z.enum(['en', 'ar']).default('ar'),
});

export type Project = z.infer<typeof projectSchema> & { created_at?: string; updated_at?: string };
export type ProjectMedia = z.infer<typeof mediaSchema>;
export type Service = z.infer<typeof serviceSchema> & { created_at?: string; updated_at?: string };
export type Campaign = z.infer<typeof campaignSchema> & {
  impressions?: number;
  clicks?: number;
  created_at?: string;
  updated_at?: string;
};
export type BookingStatus = 'pending' | 'confirmed' | 'completed' | 'cancelled' | 'rejected';
export type Booking = {
  id: string;
  reference: string;
  customer_name: string;
  phone: string;
  email: string | null;
  service_id: string;
  service_name: string;
  service_name_ar: string;
  quoted_price: number;
  currency: string;
  preferred_at: string;
  duration_minutes: number;
  project_details: string;
  status: BookingStatus;
  admin_note: string;
  created_at: string;
  updated_at: string;
};

export type StudioSettings = {
  studio_name: string;
  studio_name_ar: string;
  hero_title: string;
  hero_title_ar: string;
  hero_subtitle: string;
  hero_subtitle_ar: string;
  about_text: string;
  about_text_ar: string;
  contact_phone: string;
  whatsapp_number: string;
  contact_email: string;
  youtube_url: string;
  instagram_url: string;
  footer_note: string;
  footer_note_ar: string;
  seo_title: string;
  seo_title_ar: string;
  seo_description: string;
  seo_description_ar: string;
  logo_path: string;
  upload_formats: string;
  upload_limit_mb: string;
  [key: string]: string;
};

export type PublicData = {
  settings: StudioSettings;
  services: Service[];
  projects: Project[];
  campaigns: Campaign[];
};

export const defaultSettings: StudioSettings = {
  studio_name: 'YJ Studio',
  studio_name_ar: 'استوديو YJ',
  hero_title: 'Sound that stays with you.',
  hero_title_ar: 'صوت يبقى معك.',
  hero_subtitle: 'Audio engineering, music production and visual storytelling shaped with precision.',
  hero_subtitle_ar: 'هندسة صوتية وإنتاج موسيقي وسرد بصري متقن.',
  about_text: 'YJ Studio is a creative recording space for artists who care about the details. From the first take to the final master, every project receives focused engineering and a sound of its own.',
  about_text_ar: 'YJ Studio مساحة تسجيل إبداعية للفنانين الذين يهتمون بالتفاصيل. من التسجيل الأول حتى الماستر النهائي، يحظى كل مشروع بهندسة دقيقة وصوت يميّزه.',
  contact_phone: '',
  whatsapp_number: '',
  contact_email: '',
  youtube_url: '',
  instagram_url: '',
  footer_note: 'Created & Engineered by Engineer Yousab',
  footer_note_ar: 'إبداع وهندسة صوتية: المهندس يوساب',
  seo_title: 'YJ Studio | Sound Engineering & Recording',
  seo_title_ar: 'YJ Studio | هندسة صوتية وتسجيل',
  seo_description: 'Recording, music production, mixing, mastering and music-video production at YJ Studio.',
  seo_description_ar: 'تسجيل وإنتاج موسيقي ومكس وماستر وإنتاج فيديوهات موسيقية في YJ Studio.',
  logo_path: '/yj-studio-logo.jpg',
  upload_formats: uploadFormatOptions.map((format) => format.mime).join(','),
  social_image: '/yj-studio-logo.jpg',
  upload_limit_mb: '80',
  maintenance_message: '',
  maintenance_message_ar: '',
  visible_sections: 'portfolio,services,offers,about,booking,contact',
  nav_home: '',
  nav_home_ar: '',
  nav_portfolio: '',
  nav_portfolio_ar: '',
  nav_services: '',
  nav_services_ar: '',
  nav_offers: '',
  nav_offers_ar: '',
  nav_about: '',
  nav_about_ar: '',
  nav_contact: '',
  nav_contact_ar: '',
  dashboard_booking_alerts: 'on',
};
