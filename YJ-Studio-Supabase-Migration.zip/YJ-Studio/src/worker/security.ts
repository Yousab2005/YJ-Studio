import type { Context } from 'hono';
import type { AdminIdentity, Env } from './types';

const encoder = new TextEncoder();
const sessionCookie = 'yj_admin';
const sessionLifetimeSeconds = 60 * 60 * 8;
const passwordIterations = 310_000;

function toBase64Url(bytes: Uint8Array): string {
  let binary = '';
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replaceAll('+', '-').replaceAll('/', '_').replaceAll('=', '');
}

function fromBase64Url(value: string): Uint8Array {
  const normalized = value.replaceAll('-', '+').replaceAll('_', '/');
  const binary = atob(normalized + '='.repeat((4 - (normalized.length % 4)) % 4));
  return Uint8Array.from(binary, (char) => char.charCodeAt(0));
}

export async function digest(value: string): Promise<string> {
  const result = await crypto.subtle.digest('SHA-256', encoder.encode(value));
  return toBase64Url(new Uint8Array(result));
}

export async function hashPassword(password: string): Promise<string> {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const key = await crypto.subtle.importKey('raw', encoder.encode(password), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits(
    { name: 'PBKDF2', salt, iterations: passwordIterations, hash: 'SHA-256' },
    key,
    256,
  );
  return `pbkdf2$${passwordIterations}$${toBase64Url(salt)}$${toBase64Url(new Uint8Array(bits))}`;
}

export async function verifyPassword(password: string, stored: string): Promise<boolean> {
  const [algorithm, iterationsText, saltText, expectedText] = stored.split('$');
  const iterations = Number(iterationsText);
  if (algorithm !== 'pbkdf2' || !Number.isInteger(iterations) || iterations < 100_000 || iterations > 1_000_000 || !saltText || !expectedText) return false;
  try {
    const key = await crypto.subtle.importKey('raw', encoder.encode(password), 'PBKDF2', false, ['deriveBits']);
    const result = await crypto.subtle.deriveBits(
      { name: 'PBKDF2', salt: fromBase64Url(saltText) as unknown as BufferSource, iterations, hash: 'SHA-256' },
      key,
      256,
    );
    const actual = new Uint8Array(result);
    const expected = fromBase64Url(expectedText);
    if (actual.length !== expected.length) return false;
    let diff = 0;
    for (let i = 0; i < actual.length; i += 1) diff |= actual[i] ^ expected[i];
    return diff === 0;
  } catch {
    return false;
  }
}

function readCookie(request: Request, name: string): string | null {
  const cookieHeader = request.headers.get('Cookie') ?? '';
  for (const part of cookieHeader.split(';')) {
    const [key, ...rest] = part.trim().split('=');
    if (key === name) return rest.join('=') || null;
  }
  return null;
}

export async function currentAdmin(context: Context<{ Bindings: Env; Variables: { admin: AdminIdentity } }>): Promise<AdminIdentity | null> {
  const token = readCookie(context.req.raw, sessionCookie);
  if (!token || token.length > 100) return null;
  const tokenHash = await digest(token);
  const now = new Date().toISOString();
  const row = await context.env.DB.prepare(
    "SELECT admins.id, admins.username, roles.name AS role FROM sessions JOIN admins ON admins.id = sessions.admin_id JOIN admin_roles ON admin_roles.admin_id = admins.id JOIN roles ON roles.id = admin_roles.role_id WHERE sessions.token_hash = ? AND sessions.expires_at > ? AND roles.name = 'admin'",
  ).bind(tokenHash, now).first<AdminIdentity>();
  return row;
}

export async function createSession(context: Context<{ Bindings: Env; Variables: { admin: AdminIdentity } }>, admin: AdminIdentity): Promise<void> {
  const token = toBase64Url(crypto.getRandomValues(new Uint8Array(32)));
  const expiresAt = new Date(Date.now() + sessionLifetimeSeconds * 1000).toISOString();
  await context.env.DB.prepare('INSERT INTO sessions(token_hash, admin_id, expires_at) VALUES(?, ?, ?)')
    .bind(await digest(token), admin.id, expiresAt)
    .run();
  const secure = context.env.NODE_ENV === 'production' ? '; Secure' : '';
  context.header('Set-Cookie', `${sessionCookie}=${token}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${sessionLifetimeSeconds}${secure}`);
}

export async function clearSession(context: Context<{ Bindings: Env; Variables: { admin: AdminIdentity } }>): Promise<void> {
  const token = readCookie(context.req.raw, sessionCookie);
  if (token) await context.env.DB.prepare('DELETE FROM sessions WHERE token_hash = ?').bind(await digest(token)).run();
  const secure = context.env.NODE_ENV === 'production' ? '; Secure' : '';
  context.header('Set-Cookie', `${sessionCookie}=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0${secure}`);
}

export async function currentSessionDigest(context: Context<{ Bindings: Env; Variables: { admin: AdminIdentity } }>): Promise<string | null> {
  const token = readCookie(context.req.raw, sessionCookie);
  return token ? digest(token) : null;
}

export function verifySameOrigin(context: Context<{ Bindings: Env; Variables: { admin: AdminIdentity } }>): boolean {
  const origin = context.req.header('Origin');
  if (!origin || context.req.header('X-YJ-Request') !== '1') return false;
  const allowed = new Set([new URL(context.req.url).origin]);
  for (const value of context.env.ALLOWED_ORIGINS?.split(',') ?? []) {
    if (value.trim()) allowed.add(value.trim());
  }
  if (context.env.NODE_ENV !== 'production') {
    allowed.add('http://localhost:5173');
    allowed.add('http://127.0.0.1:5173');
  }
  return allowed.has(origin);
}

export function newId(): string {
  return crypto.randomUUID();
}

export function newReference(): string {
  const raw = toBase64Url(crypto.getRandomValues(new Uint8Array(6))).toUpperCase().slice(0, 8);
  return `YJ-${raw}`;
}
