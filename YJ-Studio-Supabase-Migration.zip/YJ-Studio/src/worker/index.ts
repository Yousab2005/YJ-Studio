import { Hono } from 'hono';
import { bookingSchema, campaignSchema, defaultSettings, projectSchema, serviceSchema, uploadFormatOptions, type BookingStatus } from '../shared';
import { clearSession, createSession, currentAdmin, currentSessionDigest, digest, hashPassword, newId, newReference, verifyPassword, verifySameOrigin } from './security';
import type { AdminIdentity, D1Statement, Env } from './types';

type AppEnv = { Bindings: Env; Variables: { admin: AdminIdentity } };
type ProjectRow = {
  id: string; title: string; title_ar: string; category: string; description: string; description_ar: string; tags_json: string; credits: string; credits_ar: string;
  release_date: string | null; cover_image: string; media_json: string; is_published: number; is_featured: number;
  sort_order: number; created_at: string; updated_at: string;
};
type ServiceRow = {
  id: string; name: string; name_ar: string; description: string; description_ar: string; price: number; currency: string; billing_unit: string;
  duration_minutes: number | null; discount_price: number | null; discount_start: string | null; discount_end: string | null;
  is_active: number; sort_order: number; created_at: string; updated_at: string;
};
type CampaignRow = {
  id: string; title: string; title_ar: string; description: string; description_ar: string; kind: string; placement: string; media_url: string; cta_label: string; cta_label_ar: string;
  destination_url: string; start_at: string | null; end_at: string | null; status: string; sort_order: number;
  impressions: number; clicks: number; created_at: string; updated_at: string;
};
type BookingRow = {
  id: string; reference: string; customer_name: string; phone: string; email: string | null; service_id: string;
  service_name: string; service_name_ar: string; quoted_price: number; currency: string; preferred_at: string; duration_minutes: number;
  project_details: string; status: BookingStatus; admin_note: string; created_at: string; updated_at: string;
};

const app = new Hono<AppEnv>();
const publicSettingKeys = [
  'studio_name', 'studio_name_ar', 'hero_title', 'hero_title_ar', 'hero_subtitle', 'hero_subtitle_ar', 'about_text', 'about_text_ar',
  'contact_phone', 'whatsapp_number', 'contact_email', 'youtube_url', 'instagram_url', 'footer_note', 'footer_note_ar',
  'seo_title', 'seo_title_ar', 'seo_description', 'seo_description_ar', 'logo_path', 'social_image',
  'maintenance_message', 'maintenance_message_ar', 'visible_sections', 'nav_home', 'nav_home_ar', 'nav_portfolio', 'nav_portfolio_ar',
  'nav_services', 'nav_services_ar', 'nav_offers', 'nav_offers_ar', 'nav_about', 'nav_about_ar', 'nav_contact', 'nav_contact_ar',
];

app.use('*', async (c, next) => {
  await next();
  const pathname = new URL(c.req.url).pathname;
  c.header('X-Content-Type-Options', 'nosniff');
  c.header('X-Frame-Options', 'DENY');
  c.header('Referrer-Policy', 'strict-origin-when-cross-origin');
  c.header('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  c.header('Cross-Origin-Resource-Policy', 'same-origin');
  if (pathname.startsWith('/api/admin/')) c.header('Cache-Control', 'private, no-store');
  else if (pathname.startsWith('/api/')) c.header('Cache-Control', 'no-store');
  if (c.env.NODE_ENV === 'production') {
    c.header('Content-Security-Policy', "default-src 'self'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'; object-src 'none'; img-src 'self' data: https: blob:; media-src 'self' https: blob:; frame-src https://www.youtube-nocookie.com; connect-src 'self'; font-src 'self' data: https://fonts.gstatic.com; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; script-src 'self'; worker-src 'self'");
  }
});

app.use('/api/admin/*', async (c, next) => {
  const path = new URL(c.req.url).pathname;
  const method = c.req.method;
  if (!['GET', 'HEAD', 'OPTIONS'].includes(method)) {
    if (!verifySameOrigin(c)) return c.json({ error: 'Request origin check failed.' }, 403);
  }
  if (path.endsWith('/login')) return next();
  if (path.endsWith('/me') && method === 'GET') return next();
  const admin = await currentAdmin(c);
  if (!admin) return c.json({ error: 'Please sign in to continue.' }, 401);
  c.set('admin', admin);
  return next();
});

function nowIso(): string {
  return new Date().toISOString();
}

function parseTags(value: string): string[] {
  try {
    const parsed: unknown = JSON.parse(value);
    return Array.isArray(parsed) ? parsed.filter((item): item is string => typeof item === 'string') : [];
  } catch {
    return [];
  }
}

function parseMedia(value: string): Array<{ id: string; title: string; title_ar?: string; kind: string; url: string; mime?: string }> {
  try {
    const parsed: unknown = JSON.parse(value);
    return Array.isArray(parsed) ? parsed.filter((item) => item && typeof item === 'object') as Array<{ id: string; title: string; title_ar?: string; kind: string; url: string; mime?: string }> : [];
  } catch {
    return [];
  }
}

function mapProject(row: ProjectRow) {
  return {
    id: row.id, title: row.title, title_ar: row.title_ar, category: row.category, description: row.description, description_ar: row.description_ar, tags: parseTags(row.tags_json),
    credits: row.credits, credits_ar: row.credits_ar, release_date: row.release_date, cover_image: row.cover_image, media: parseMedia(row.media_json),
    is_published: Boolean(row.is_published), is_featured: Boolean(row.is_featured), sort_order: row.sort_order,
    created_at: row.created_at, updated_at: row.updated_at,
  };
}

function mapService(row: ServiceRow) {
  return {
    id: row.id, name: row.name, name_ar: row.name_ar, description: row.description, description_ar: row.description_ar, price: row.price, currency: row.currency,
    billing_unit: row.billing_unit, duration_minutes: row.duration_minutes, discount_price: row.discount_price,
    discount_start: row.discount_start, discount_end: row.discount_end, is_active: Boolean(row.is_active),
    sort_order: row.sort_order, created_at: row.created_at, updated_at: row.updated_at,
  };
}

function mapCampaign(row: CampaignRow) {
  return {
    id: row.id, title: row.title, title_ar: row.title_ar, description: row.description, description_ar: row.description_ar, kind: row.kind, placement: row.placement,
    media_url: row.media_url, cta_label: row.cta_label, cta_label_ar: row.cta_label_ar, destination_url: row.destination_url,
    start_at: row.start_at, end_at: row.end_at, status: row.status, sort_order: row.sort_order,
    impressions: row.impressions, clicks: row.clicks, created_at: row.created_at, updated_at: row.updated_at,
  };
}

function mapBooking(row: BookingRow) {
  return { ...row };
}

async function readSettings(env: Env): Promise<Record<string, string>> {
  const rows = await env.DB.prepare('SELECT key, value FROM settings').all<{ key: string; value: string }>();
  return { ...defaultSettings, ...Object.fromEntries(rows.results.map((row) => [row.key, row.value])) };
}

async function writeAudit(c: { env: Env; get(key: 'admin'): AdminIdentity }, action: string, entityType: string, entityId: string | null, details = ''): Promise<void> {
  await c.env.DB.prepare('INSERT INTO audit_logs(id, admin_id, action, entity_type, entity_id, details) VALUES(?, ?, ?, ?, ?, ?)')
    .bind(newId(), c.get('admin').id, action, entityType, entityId, details.slice(0, 400))
    .run();
}

function sqlValue(value: boolean): number {
  return value ? 1 : 0;
}

function safeMediaUrl(value: string): boolean {
  if (!value) return true;
  if (/^\/api\/media\/[a-zA-Z0-9._-]+$/.test(value)) return true;
  try {
    return new URL(value).protocol === 'https:';
  } catch {
    return false;
  }
}

function safeDestination(value: string): boolean {
  if (!value) return true;
  if (/^\/(?!\/)[a-zA-Z0-9/_?#=&.%-]*$/.test(value)) return true;
  try {
    return new URL(value).protocol === 'https:';
  } catch {
    return false;
  }
}

function validOptionalDate(value: string | null | undefined): boolean {
  return !value || !Number.isNaN(new Date(value).getTime());
}

function toIsoOrNull(value: string | null | undefined): string | null {
  if (!value) return null;
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? null : date.toISOString();
}

async function parseJson<T>(request: Request, schema: { safeParse(value: unknown): { success: true; data: T } | { success: false; error: { issues: Array<{ message: string; path: PropertyKey[] }> } } }): Promise<{ data?: T; error?: string }> {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return { error: 'Request body must be valid JSON.' };
  }
  const result = schema.safeParse(body);
  if (!result.success) return { error: result.error.issues.map((issue) => `${issue.path.join('.') || 'form'}: ${issue.message}`).join(' · ') };
  return { data: result.data };
}

async function getActiveService(env: Env, serviceId: string): Promise<ServiceRow | null> {
  return env.DB.prepare('SELECT * FROM services WHERE id = ? AND is_active = 1').bind(serviceId).first<ServiceRow>();
}

function currentServicePrice(service: ServiceRow, durationMinutes: number, now = Date.now()): number {
  const hasDiscount = service.discount_price !== null
    && (!service.discount_start || new Date(service.discount_start).getTime() <= now)
    && (!service.discount_end || new Date(service.discount_end).getTime() >= now);
  const base = hasDiscount ? service.discount_price as number : service.price;
  return service.billing_unit.toLowerCase().includes('hour') ? base * Math.ceil(durationMinutes / 60) : base;
}

async function bookingConflict(env: Env, preferredAt: string, durationMinutes: number, excludeId?: string): Promise<boolean> {
  const start = new Date(preferredAt);
  if (Number.isNaN(start.getTime()) || start.getTime() <= Date.now()) return true;
  const end = new Date(start.getTime() + durationMinutes * 60_000).toISOString();
  const query = excludeId
    ? "SELECT id FROM bookings WHERE status IN ('pending', 'confirmed') AND id <> ? AND preferred_at < ? AND datetime(preferred_at, '+' || duration_minutes || ' minutes') > datetime(?) LIMIT 1"
    : "SELECT id FROM bookings WHERE status IN ('pending', 'confirmed') AND preferred_at < ? AND datetime(preferred_at, '+' || duration_minutes || ' minutes') > datetime(?) LIMIT 1";
  const statement = env.DB.prepare(query);
  const result = excludeId
    ? await statement.bind(excludeId, end, start.toISOString()).first<{ id: string }>()
    : await statement.bind(end, start.toISOString()).first<{ id: string }>();
  return Boolean(result);
}

app.get('/api/health', (c) => c.json({ ok: true, service: 'yj-studio' }));

app.get('/api/public', async (c) => {
  const now = nowIso();
  const [settings, serviceRows, projectRows, campaignRows] = await Promise.all([
    readSettings(c.env),
    c.env.DB.prepare('SELECT * FROM services WHERE is_active = 1 ORDER BY sort_order, name').all<ServiceRow>(),
    c.env.DB.prepare('SELECT * FROM projects WHERE is_published = 1 ORDER BY is_featured DESC, sort_order, release_date DESC, created_at DESC').all<ProjectRow>(),
    c.env.DB.prepare("SELECT * FROM campaigns WHERE status IN ('active', 'scheduled') AND (start_at IS NULL OR start_at <= ?) AND (end_at IS NULL OR end_at >= ?) ORDER BY sort_order, created_at DESC").bind(now, now).all<CampaignRow>(),
  ]);
  if (campaignRows.results.length) {
    await c.env.DB.batch(campaignRows.results.map((row) => c.env.DB.prepare('UPDATE campaigns SET impressions = impressions + 1 WHERE id = ?').bind(row.id)));
  }
  return c.json({
    settings: Object.fromEntries(publicSettingKeys.map((key) => [key, settings[key] ?? ''])),
    services: serviceRows.results.map(mapService),
    projects: projectRows.results.map(mapProject),
    campaigns: campaignRows.results.map(mapCampaign),
  });
});

app.post('/api/bookings', async (c) => {
  const parsed = await parseJson(c.req.raw, bookingSchema);
  if (parsed.error || !parsed.data) return c.json({ error: parsed.error ?? 'Invalid booking.' }, 400);
  const input = parsed.data;
  const service = await getActiveService(c.env, input.service_id);
  if (!service) return c.json({ error: 'That service is no longer available. Refresh the page and choose another service.' }, 400);
  const preferredAt = toIsoOrNull(input.preferred_at);
  if (!preferredAt) return c.json({ error: 'Choose a valid appointment date and time.' }, 400);
  const duration = service.billing_unit.toLowerCase().includes('hour') ? input.duration_minutes : service.duration_minutes ?? input.duration_minutes;
  if (await bookingConflict(c.env, preferredAt, duration)) return c.json({ error: 'That time conflicts with another pending or confirmed session. Please choose another time.' }, 409);
  const reference = newReference();
  const id = newId();
  const price = currentServicePrice(service, duration);
  const serviceName = input.language === 'ar' ? service.name_ar || service.name : service.name;
  await c.env.DB.prepare('INSERT INTO bookings(id, reference, customer_name, phone, email, service_id, service_name, service_name_ar, quoted_price, currency, preferred_at, duration_minutes, project_details, status) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')
    .bind(id, reference, input.customer_name, input.phone, input.email || null, service.id, service.name, service.name_ar || service.name, price, service.currency, preferredAt, duration, input.project_details, 'pending')
    .run();
  return c.json({ reference, status: 'pending', service_name: serviceName, service_name_ar: service.name_ar || service.name, quoted_price: price, currency: service.currency }, 201);
});

app.post('/api/campaigns/:id/click', async (c) => {
  const now = nowIso();
  const result = await c.env.DB.prepare("UPDATE campaigns SET clicks = clicks + 1 WHERE id = ? AND status IN ('active', 'scheduled') AND (start_at IS NULL OR start_at <= ?) AND (end_at IS NULL OR end_at >= ?)")
    .bind(c.req.param('id'), now, now).run();
  return c.json({ counted: result.meta.changes > 0 });
});

app.get('/api/media/:key', async (c) => {
  const key = c.req.param('key');
  if (!/^[a-zA-Z0-9._-]{1,180}$/.test(key)) return c.notFound();
  const path = `/api/media/${key}`;
  const admin = await currentAdmin(c);
  if (!admin) {
    const now = nowIso();
    const publicUse = await c.env.DB.prepare(
      "SELECT id FROM projects WHERE is_published = 1 AND (cover_image = ? OR media_json LIKE ?) UNION ALL SELECT id FROM campaigns WHERE status IN ('active', 'scheduled') AND (start_at IS NULL OR start_at <= ?) AND (end_at IS NULL OR end_at >= ?) AND media_url = ? UNION ALL SELECT key AS id FROM settings WHERE key IN ('logo_path', 'social_image') AND value = ? LIMIT 1",
    ).bind(path, `%${key}%`, now, now, path, path).first<{ id: string }>();
    if (!publicUse) return c.notFound();
  }
  const object = await c.env.MEDIA.get(key);
  if (!object) return c.notFound();
  const headers = new Headers();
  object.writeHttpMetadata(headers);
  headers.set('Content-Type', object.httpMetadata?.contentType ?? 'application/octet-stream');
  headers.set('Cache-Control', 'private, no-store');
  headers.set('X-Content-Type-Options', 'nosniff');
  return new Response(object.body, { headers });
});

app.post('/api/admin/login', async (c) => {
  let body: { username?: unknown; password?: unknown };
  try { body = await c.req.json(); } catch { return c.json({ error: 'Enter your username and password.' }, 400); }
  const username = typeof body.username === 'string' ? body.username.trim().toLowerCase().slice(0, 120) : '';
  const password = typeof body.password === 'string' ? body.password.slice(0, 300) : '';
  const ip = c.req.header('CF-Connecting-IP') ?? c.req.header('X-Forwarded-For')?.split(',')[0]?.trim() ?? 'unknown';
  const ipHash = await digest(ip);
  const now = Date.now();
  const limit = await c.env.DB.prepare('SELECT failed_count, window_start, blocked_until FROM login_attempts WHERE ip_hash = ?').bind(ipHash)
    .first<{ failed_count: number; window_start: string; blocked_until: string | null }>();
  if (limit?.blocked_until && new Date(limit.blocked_until).getTime() > now) return c.json({ error: 'Too many sign-in attempts. Try again in 15 minutes.' }, 429);
  const admin = username ? await c.env.DB.prepare('SELECT id, username, password_hash FROM admins WHERE username = ?').bind(username).first<AdminIdentity & { password_hash: string }>() : null;
  const valid = Boolean(admin && password && await verifyPassword(password, admin.password_hash));
  if (!valid || !admin) {
    const withinWindow = limit && now - new Date(limit.window_start).getTime() < 15 * 60_000;
    const failures = withinWindow ? limit.failed_count + 1 : 1;
    const windowStart = withinWindow ? limit.window_start : nowIso();
    const blockedUntil = failures >= 5 ? new Date(now + 15 * 60_000).toISOString() : null;
    await c.env.DB.prepare('INSERT INTO login_attempts(ip_hash, failed_count, window_start, blocked_until) VALUES(?, ?, ?, ?) ON CONFLICT(ip_hash) DO UPDATE SET failed_count = excluded.failed_count, window_start = excluded.window_start, blocked_until = excluded.blocked_until')
      .bind(ipHash, failures, windowStart, blockedUntil).run();
    return c.json({ error: 'The username or password is incorrect.' }, 401);
  }
  await c.env.DB.prepare('DELETE FROM login_attempts WHERE ip_hash = ?').bind(ipHash).run();
  await createSession(c, admin);
  return c.json({ id: admin.id, username: admin.username });
});

app.get('/api/admin/me', async (c) => {
  const admin = await currentAdmin(c);
  return c.json(admin ? { authenticated: true, ...admin } : { authenticated: false });
});

app.post('/api/admin/logout', async (c) => {
  await clearSession(c);
  return c.json({ ok: true });
});

app.get('/api/admin/overview', async (c) => {
  const [projects, audio, videos, bookings, campaigns, activities] = await Promise.all([
    c.env.DB.prepare('SELECT COUNT(*) AS total, SUM(is_published) AS published FROM projects').first<{ total: number; published: number | null }>(),
    c.env.DB.prepare("SELECT SUM(CASE WHEN media_json LIKE '%\"kind\":\"audio\"%' THEN 1 ELSE 0 END) AS total FROM projects").first<{ total: number | null }>(),
    c.env.DB.prepare("SELECT SUM(CASE WHEN media_json LIKE '%\"kind\":\"video\"%' OR media_json LIKE '%\"kind\":\"youtube\"%' THEN 1 ELSE 0 END) AS total FROM projects").first<{ total: number | null }>(),
    c.env.DB.prepare("SELECT SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) AS pending, SUM(CASE WHEN status = 'confirmed' THEN 1 ELSE 0 END) AS confirmed, COUNT(*) AS total FROM bookings").first<{ pending: number | null; confirmed: number | null; total: number }>(),
    c.env.DB.prepare("SELECT COUNT(*) AS total FROM campaigns WHERE status IN ('active', 'scheduled') AND (start_at IS NULL OR start_at <= ?) AND (end_at IS NULL OR end_at >= ?)").bind(nowIso(), nowIso()).first<{ total: number }>(),
    c.env.DB.prepare('SELECT id, action, entity_type, entity_id, details, created_at FROM audit_logs ORDER BY created_at DESC LIMIT 10').all(),
  ]);
  return c.json({
    projects: projects?.total ?? 0, published: projects?.published ?? 0, audio_tracks: audio?.total ?? 0,
    videos: videos?.total ?? 0, bookings: bookings?.total ?? 0, pending_bookings: bookings?.pending ?? 0,
    confirmed_bookings: bookings?.confirmed ?? 0, active_promotions: campaigns?.total ?? 0,
    recent_activities: activities.results,
  });
});

app.get('/api/admin/projects', async (c) => {
  const rows = await c.env.DB.prepare('SELECT * FROM projects ORDER BY is_published DESC, is_featured DESC, sort_order, updated_at DESC').all<ProjectRow>();
  return c.json(rows.results.map(mapProject));
});

app.post('/api/admin/projects', async (c) => {
  const parsed = await parseJson(c.req.raw, projectSchema);
  if (parsed.error || !parsed.data) return c.json({ error: parsed.error ?? 'Invalid project.' }, 400);
  const project = parsed.data;
  if (!safeMediaUrl(project.cover_image) || project.media.some((item) => !safeMediaUrl(item.url)) || !validOptionalDate(project.release_date)) return c.json({ error: 'Use uploaded media or secure HTTPS links and enter a valid release date.' }, 400);
  const id = newId();
  await c.env.DB.prepare('INSERT INTO projects(id, title, title_ar, category, description, description_ar, tags_json, credits, credits_ar, release_date, cover_image, media_json, is_published, is_featured, sort_order) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')
    .bind(id, project.title, project.title_ar, project.category, project.description, project.description_ar, JSON.stringify(project.tags), project.credits, project.credits_ar, project.release_date || null, project.cover_image, JSON.stringify(project.media), sqlValue(project.is_published), sqlValue(project.is_featured), project.sort_order)
    .run();
  await writeAudit(c, 'created', 'project', id, project.title);
  return c.json({ ...project, id }, 201);
});

app.put('/api/admin/projects/:id', async (c) => {
  const parsed = await parseJson(c.req.raw, projectSchema);
  if (parsed.error || !parsed.data) return c.json({ error: parsed.error ?? 'Invalid project.' }, 400);
  const project = parsed.data;
  if (!safeMediaUrl(project.cover_image) || project.media.some((item) => !safeMediaUrl(item.url)) || !validOptionalDate(project.release_date)) return c.json({ error: 'Use uploaded media or secure HTTPS links and enter a valid release date.' }, 400);
  const id = c.req.param('id');
  const result = await c.env.DB.prepare('UPDATE projects SET title = ?, title_ar = ?, category = ?, description = ?, description_ar = ?, tags_json = ?, credits = ?, credits_ar = ?, release_date = ?, cover_image = ?, media_json = ?, is_published = ?, is_featured = ?, sort_order = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?')
    .bind(project.title, project.title_ar, project.category, project.description, project.description_ar, JSON.stringify(project.tags), project.credits, project.credits_ar, project.release_date || null, project.cover_image, JSON.stringify(project.media), sqlValue(project.is_published), sqlValue(project.is_featured), project.sort_order, id)
    .run();
  if (!result.meta.changes) return c.notFound();
  await writeAudit(c, 'updated', 'project', id, project.title);
  return c.json({ ...project, id });
});

app.delete('/api/admin/projects/:id', async (c) => {
  const id = c.req.param('id');
  const row = await c.env.DB.prepare('SELECT title FROM projects WHERE id = ?').bind(id).first<{ title: string }>();
  if (!row) return c.notFound();
  await c.env.DB.prepare('DELETE FROM projects WHERE id = ?').bind(id).run();
  await writeAudit(c, 'deleted', 'project', id, row.title);
  return c.json({ ok: true });
});

app.get('/api/admin/services', async (c) => {
  const rows = await c.env.DB.prepare('SELECT * FROM services ORDER BY sort_order, name').all<ServiceRow>();
  return c.json(rows.results.map(mapService));
});

app.post('/api/admin/services', async (c) => {
  const parsed = await parseJson(c.req.raw, serviceSchema);
  if (parsed.error || !parsed.data) return c.json({ error: parsed.error ?? 'Invalid service.' }, 400);
  const service = parsed.data;
  if (!validOptionalDate(service.discount_start) || !validOptionalDate(service.discount_end)) return c.json({ error: 'Enter valid discount start and end dates.' }, 400);
  const id = newId();
  await c.env.DB.prepare('INSERT INTO services(id, name, name_ar, description, description_ar, price, currency, billing_unit, duration_minutes, discount_price, discount_start, discount_end, is_active, sort_order) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')
    .bind(id, service.name, service.name_ar, service.description, service.description_ar, service.price, service.currency.toUpperCase(), service.billing_unit, service.duration_minutes ?? null, service.discount_price ?? null, toIsoOrNull(service.discount_start), toIsoOrNull(service.discount_end), sqlValue(service.is_active), service.sort_order)
    .run();
  await writeAudit(c, 'created', 'service', id, service.name);
  return c.json({ ...service, id }, 201);
});

app.put('/api/admin/services/:id', async (c) => {
  const parsed = await parseJson(c.req.raw, serviceSchema);
  if (parsed.error || !parsed.data) return c.json({ error: parsed.error ?? 'Invalid service.' }, 400);
  const service = parsed.data;
  if (!validOptionalDate(service.discount_start) || !validOptionalDate(service.discount_end)) return c.json({ error: 'Enter valid discount start and end dates.' }, 400);
  const id = c.req.param('id');
  const result = await c.env.DB.prepare('UPDATE services SET name = ?, name_ar = ?, description = ?, description_ar = ?, price = ?, currency = ?, billing_unit = ?, duration_minutes = ?, discount_price = ?, discount_start = ?, discount_end = ?, is_active = ?, sort_order = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?')
    .bind(service.name, service.name_ar, service.description, service.description_ar, service.price, service.currency.toUpperCase(), service.billing_unit, service.duration_minutes ?? null, service.discount_price ?? null, toIsoOrNull(service.discount_start), toIsoOrNull(service.discount_end), sqlValue(service.is_active), service.sort_order, id)
    .run();
  if (!result.meta.changes) return c.notFound();
  await writeAudit(c, 'updated', 'service', id, service.name);
  return c.json({ ...service, id });
});

app.delete('/api/admin/services/:id', async (c) => {
  const id = c.req.param('id');
  const count = await c.env.DB.prepare('SELECT COUNT(*) AS total FROM bookings WHERE service_id = ?').bind(id).first<{ total: number }>();
  if ((count?.total ?? 0) > 0) return c.json({ error: 'This service has booking history. Disable it instead of deleting it.' }, 409);
  const row = await c.env.DB.prepare('SELECT name FROM services WHERE id = ?').bind(id).first<{ name: string }>();
  if (!row) return c.notFound();
  await c.env.DB.prepare('DELETE FROM services WHERE id = ?').bind(id).run();
  await writeAudit(c, 'deleted', 'service', id, row.name);
  return c.json({ ok: true });
});

app.get('/api/admin/campaigns', async (c) => {
  const rows = await c.env.DB.prepare('SELECT * FROM campaigns ORDER BY sort_order, created_at DESC').all<CampaignRow>();
  return c.json(rows.results.map(mapCampaign));
});

app.post('/api/admin/campaigns', async (c) => {
  const parsed = await parseJson(c.req.raw, campaignSchema);
  if (parsed.error || !parsed.data) return c.json({ error: parsed.error ?? 'Invalid campaign.' }, 400);
  const campaign = parsed.data;
  if (!safeMediaUrl(campaign.media_url) || !safeDestination(campaign.destination_url) || !validOptionalDate(campaign.start_at) || !validOptionalDate(campaign.end_at)) return c.json({ error: 'Campaign media, dates, or destination are invalid. Use uploaded files, secure HTTPS links, or a site path.' }, 400);
  const id = newId();
  await c.env.DB.prepare('INSERT INTO campaigns(id, title, title_ar, description, description_ar, kind, placement, media_url, cta_label, cta_label_ar, destination_url, start_at, end_at, status, sort_order) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')
    .bind(id, campaign.title, campaign.title_ar, campaign.description, campaign.description_ar, campaign.kind, campaign.placement, campaign.media_url, campaign.cta_label, campaign.cta_label_ar, campaign.destination_url, toIsoOrNull(campaign.start_at), toIsoOrNull(campaign.end_at), campaign.status, campaign.sort_order)
    .run();
  await writeAudit(c, 'created', 'campaign', id, campaign.title);
  return c.json({ ...campaign, id, impressions: 0, clicks: 0 }, 201);
});

app.put('/api/admin/campaigns/:id', async (c) => {
  const parsed = await parseJson(c.req.raw, campaignSchema);
  if (parsed.error || !parsed.data) return c.json({ error: parsed.error ?? 'Invalid campaign.' }, 400);
  const campaign = parsed.data;
  if (!safeMediaUrl(campaign.media_url) || !safeDestination(campaign.destination_url) || !validOptionalDate(campaign.start_at) || !validOptionalDate(campaign.end_at)) return c.json({ error: 'Campaign media, dates, or destination are invalid. Use uploaded files, secure HTTPS links, or a site path.' }, 400);
  const id = c.req.param('id');
  const result = await c.env.DB.prepare('UPDATE campaigns SET title = ?, title_ar = ?, description = ?, description_ar = ?, kind = ?, placement = ?, media_url = ?, cta_label = ?, cta_label_ar = ?, destination_url = ?, start_at = ?, end_at = ?, status = ?, sort_order = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?')
    .bind(campaign.title, campaign.title_ar, campaign.description, campaign.description_ar, campaign.kind, campaign.placement, campaign.media_url, campaign.cta_label, campaign.cta_label_ar, campaign.destination_url, toIsoOrNull(campaign.start_at), toIsoOrNull(campaign.end_at), campaign.status, campaign.sort_order, id)
    .run();
  if (!result.meta.changes) return c.notFound();
  await writeAudit(c, 'updated', 'campaign', id, campaign.title);
  return c.json({ ...campaign, id });
});

app.delete('/api/admin/campaigns/:id', async (c) => {
  const id = c.req.param('id');
  const row = await c.env.DB.prepare('SELECT title FROM campaigns WHERE id = ?').bind(id).first<{ title: string }>();
  if (!row) return c.notFound();
  await c.env.DB.prepare('DELETE FROM campaigns WHERE id = ?').bind(id).run();
  await writeAudit(c, 'deleted', 'campaign', id, row.title);
  return c.json({ ok: true });
});

app.get('/api/admin/bookings', async (c) => {
  const status = c.req.query('status');
  const search = c.req.query('search')?.trim().slice(0, 120);
  const day = c.req.query('day')?.slice(0, 10);
  const clauses: string[] = [];
  const values: unknown[] = [];
  if (status && ['pending', 'confirmed', 'completed', 'cancelled', 'rejected'].includes(status)) { clauses.push('status = ?'); values.push(status); }
  if (search) { clauses.push('(customer_name LIKE ? OR phone LIKE ? OR reference LIKE ?)'); values.push(`%${search}%`, `%${search}%`, `%${search}%`); }
  if (day && /^\d{4}-\d{2}-\d{2}$/.test(day)) { clauses.push('substr(preferred_at, 1, 10) = ?'); values.push(day); }
  const query = `SELECT * FROM bookings${clauses.length ? ` WHERE ${clauses.join(' AND ')}` : ''} ORDER BY preferred_at DESC LIMIT 500`;
  const rows = await c.env.DB.prepare(query).bind(...values).all<BookingRow>();
  return c.json(rows.results.map(mapBooking));
});

app.put('/api/admin/bookings/:id', async (c) => {
  let body: { status?: unknown; preferred_at?: unknown; duration_minutes?: unknown; admin_note?: unknown };
  try { body = await c.req.json(); } catch { return c.json({ error: 'Invalid booking update.' }, 400); }
  const status = body.status as BookingStatus;
  if (!['pending', 'confirmed', 'completed', 'cancelled', 'rejected'].includes(status)) return c.json({ error: 'Choose a valid booking status.' }, 400);
  const id = c.req.param('id');
  const existing = await c.env.DB.prepare('SELECT * FROM bookings WHERE id = ?').bind(id).first<BookingRow>();
  if (!existing) return c.notFound();
  const preferredAt = typeof body.preferred_at === 'string' ? toIsoOrNull(body.preferred_at) : existing.preferred_at;
  const duration = typeof body.duration_minutes === 'number' ? Math.max(30, Math.min(600, Math.round(body.duration_minutes))) : existing.duration_minutes;
  if (!preferredAt) return c.json({ error: 'Choose a valid appointment time.' }, 400);
  if (['pending', 'confirmed'].includes(status) && await bookingConflict(c.env, preferredAt, duration, id)) return c.json({ error: 'That appointment overlaps another pending or confirmed session.' }, 409);
  const note = typeof body.admin_note === 'string' ? body.admin_note.slice(0, 2000) : existing.admin_note;
  await c.env.DB.prepare('UPDATE bookings SET status = ?, preferred_at = ?, duration_minutes = ?, admin_note = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?')
    .bind(status, preferredAt, duration, note, id).run();
  await writeAudit(c, 'updated', 'booking', id, `${existing.reference} → ${status}`);
  return c.json({ ...existing, status, preferred_at: preferredAt, duration_minutes: duration, admin_note: note });
});

const settingKeys = new Set(Object.keys(defaultSettings));
const settingLimits: Record<string, number> = {
  studio_name: 100, hero_title: 160, hero_subtitle: 600, about_text: 4000, contact_phone: 35, whatsapp_number: 35,
  contact_email: 254, youtube_url: 500, instagram_url: 500, footer_note: 400, seo_title: 160, seo_description: 320,
  studio_name_ar: 100, hero_title_ar: 160, hero_subtitle_ar: 600, about_text_ar: 4000, footer_note_ar: 400,
  seo_title_ar: 160, seo_description_ar: 320, maintenance_message_ar: 500,
  logo_path: 2048, social_image: 2048, upload_limit_mb: 3, maintenance_message: 500, visible_sections: 100,
  upload_formats: 500,
  nav_home: 40, nav_portfolio: 40, nav_services: 40, nav_offers: 40, nav_about: 40, nav_contact: 40,
  nav_home_ar: 40, nav_portfolio_ar: 40, nav_services_ar: 40, nav_offers_ar: 40, nav_about_ar: 40, nav_contact_ar: 40,
  dashboard_booking_alerts: 3,
};
const visibleSectionNames = new Set(['portfolio', 'services', 'offers', 'about', 'booking', 'contact']);
const uploadFormatNames = new Set<string>(uploadFormatOptions.map((format) => format.mime));

app.get('/api/admin/settings', async (c) => c.json(await readSettings(c.env)));

app.put('/api/admin/settings', async (c) => {
  let body: { settings?: unknown };
  try { body = await c.req.json(); } catch { return c.json({ error: 'Settings must be valid JSON.' }, 400); }
  if (!body.settings || typeof body.settings !== 'object' || Array.isArray(body.settings)) return c.json({ error: 'Provide a settings object.' }, 400);
  const values = Object.entries(body.settings as Record<string, unknown>);
  if (values.length > settingKeys.size) return c.json({ error: 'Too many settings were sent.' }, 400);
  const statements: D1Statement[] = [];
  for (const [key, value] of values) {
    if (!settingKeys.has(key) || typeof value !== 'string' || value.length > (settingLimits[key] ?? 1000)) return c.json({ error: `Invalid value for ${key}.` }, 400);
    if (['logo_path', 'social_image'].includes(key) && !safeMediaUrl(value)) return c.json({ error: 'Brand and social images must be uploaded files or secure HTTPS links.' }, 400);
    if (['youtube_url', 'instagram_url'].includes(key) && value && !/^https:\/\//i.test(value)) return c.json({ error: 'Social links must use HTTPS.' }, 400);
    if (key === 'contact_email' && value && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) return c.json({ error: 'Enter a valid contact email address.' }, 400);
    if (key === 'upload_limit_mb' && (!/^\d+$/.test(value) || Number(value) < 1 || Number(value) > 80)) return c.json({ error: 'Upload size must be between 1 and 80 MB.' }, 400);
    if (key === 'visible_sections' && value && value.split(',').some((section) => !visibleSectionNames.has(section))) return c.json({ error: 'One or more public section names are invalid.' }, 400);
    if (key === 'dashboard_booking_alerts' && !['on', 'off'].includes(value)) return c.json({ error: 'Choose whether in-dashboard booking alerts are on or off.' }, 400);
    if (key === 'upload_formats') {
      const formats = value.split(',').filter(Boolean);
      if (!formats.length || formats.some((format) => !uploadFormatNames.has(format)) || new Set(formats).size !== formats.length || !formats.some((format) => format.startsWith('image/'))) {
        return c.json({ error: 'Choose supported formats, including at least one image format.' }, 400);
      }
    }
    statements.push(c.env.DB.prepare('INSERT INTO settings(key, value, updated_at) VALUES(?, ?, CURRENT_TIMESTAMP) ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = CURRENT_TIMESTAMP').bind(key, value));
  }
  if (statements.length) await c.env.DB.batch(statements);
  await writeAudit(c, 'updated', 'settings', null, values.map(([key]) => key).join(', '));
  return c.json(await readSettings(c.env));
});

app.post('/api/admin/account/password', async (c) => {
  let body: { current_password?: unknown; new_password?: unknown };
  try { body = await c.req.json(); } catch { return c.json({ error: 'Enter your current and new passwords.' }, 400); }
  const currentPassword = typeof body.current_password === 'string' ? body.current_password : '';
  const newPassword = typeof body.new_password === 'string' ? body.new_password : '';
  if (newPassword.length < 12 || newPassword.length > 300) return c.json({ error: 'Use a new password with at least 12 characters.' }, 400);
  const admin = c.get('admin');
  const stored = await c.env.DB.prepare('SELECT password_hash FROM admins WHERE id = ?').bind(admin.id).first<{ password_hash: string }>();
  if (!stored || !await verifyPassword(currentPassword, stored.password_hash)) return c.json({ error: 'Current password is incorrect.' }, 401);
  await c.env.DB.prepare('UPDATE admins SET password_hash = ? WHERE id = ?').bind(await hashPassword(newPassword), admin.id).run();
  const activeSession = await currentSessionDigest(c);
  if (activeSession) await c.env.DB.prepare('DELETE FROM sessions WHERE admin_id = ? AND token_hash <> ?').bind(admin.id, activeSession).run();
  await writeAudit(c, 'changed password', 'admin', admin.id);
  return c.json({ ok: true });
});

app.post('/api/admin/media', async (c) => {
  const form = await c.req.formData();
  const file = form.get('file');
  if (!(file instanceof File)) return c.json({ error: 'Choose a media file to upload.' }, 400);
  const allowed: Record<string, { kind: string; ext: string }> = {
    'image/jpeg': { kind: 'image', ext: 'jpg' }, 'image/png': { kind: 'image', ext: 'png' }, 'image/webp': { kind: 'image', ext: 'webp' },
    'audio/mpeg': { kind: 'audio', ext: 'mp3' }, 'audio/mp3': { kind: 'audio', ext: 'mp3' }, 'audio/wav': { kind: 'audio', ext: 'wav' },
    'audio/x-wav': { kind: 'audio', ext: 'wav' }, 'audio/ogg': { kind: 'audio', ext: 'ogg' }, 'audio/mp4': { kind: 'audio', ext: 'm4a' },
    'video/mp4': { kind: 'video', ext: 'mp4' }, 'video/webm': { kind: 'video', ext: 'webm' },
  };
  const type = allowed[file.type];
  if (!type) return c.json({ error: 'Supported formats: JPG, PNG, WebP, MP3, WAV, OGG, M4A, MP4 and WebM.' }, 415);
  const settings = await readSettings(c.env);
  const enabledFormats = new Set(settings.upload_formats.split(',').filter(Boolean));
  const maxBytes = Math.min(80, Math.max(1, Number(settings.upload_limit_mb) || 80)) * 1024 * 1024;
  if (!enabledFormats.has(file.type)) return c.json({ error: 'This media format is disabled in studio upload settings.' }, 415);
  if (file.size > maxBytes) return c.json({ error: `This file is larger than the ${Math.round(maxBytes / 1024 / 1024)} MB upload limit.` }, 413);
  const key = `${crypto.randomUUID()}.${type.ext}`;
  await c.env.MEDIA.put(key, await file.arrayBuffer(), {
    httpMetadata: { contentType: file.type, cacheControl: 'private, no-store' },
  });
  await writeAudit(c, 'uploaded', 'media', key, `${type.kind} · ${Math.ceil(file.size / 1024)} KB`);
  return c.json({ id: crypto.randomUUID(), url: `/api/media/${key}`, kind: type.kind, title: file.name.slice(0, 140), mime: file.type }, 201);
});

app.get('/api/admin/audit', async (c) => {
  const rows = await c.env.DB.prepare('SELECT audit_logs.id, admins.username, audit_logs.action, audit_logs.entity_type, audit_logs.entity_id, audit_logs.details, audit_logs.created_at FROM audit_logs LEFT JOIN admins ON admins.id = audit_logs.admin_id ORDER BY audit_logs.created_at DESC LIMIT 200').all();
  return c.json(rows.results);
});

app.notFound((c) => c.json({ error: 'Not found.' }, 404));
app.onError((error, c) => {
  // Keep private request data and implementation details out of API responses.
  console.error('YJ Studio API error:', error.name);
  return c.json({ error: 'Something went wrong. Please try again.' }, 500);
});

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const url = new URL(request.url);
    if (url.pathname.startsWith('/api/')) return app.fetch(request, env);
    const response = await env.ASSETS.fetch(request);
    const headers = new Headers(response.headers);
    headers.set('X-Content-Type-Options', 'nosniff');
    headers.set('X-Frame-Options', 'DENY');
    headers.set('Referrer-Policy', 'strict-origin-when-cross-origin');
    headers.set('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
    headers.set('Cross-Origin-Resource-Policy', 'same-origin');
    if (env.NODE_ENV === 'production') {
      headers.set('Content-Security-Policy', "default-src 'self'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'; object-src 'none'; img-src 'self' data: https: blob:; media-src 'self' https: blob:; frame-src https://www.youtube-nocookie.com; connect-src 'self'; font-src 'self' data: https://fonts.gstatic.com; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; script-src 'self'; worker-src 'self'");
    }
    return new Response(response.body, { status: response.status, statusText: response.statusText, headers });
  },
};
