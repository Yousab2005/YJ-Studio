import { useEffect, useMemo, useRef, useState, type FormEvent } from 'react';
import {
  ArrowDown, ArrowRight, ArrowUpRight, AudioLines, CalendarDays, Check, Disc3, Headphones,
  AtSign, CirclePlay, Menu, Music2, Pause, Play, Radio, Sparkles, X,
} from 'lucide-react';
import { api } from './api';
import type { Campaign, Project, PublicData, Service } from './shared';
import { defaultSettings } from './shared';
import { localize, t, tx, txf, type Language, type ThemeMode } from './i18n';
import PreferenceControls from './PreferenceControls';

type Props = { language: Language; onLanguageChange: (language: Language) => void; themeMode: ThemeMode; onThemeChange: (mode: ThemeMode) => void; onInstall?: () => void; canInstall?: boolean };
type Track = { url: string; title: string; title_ar?: string; project: string; project_ar?: string; mime?: string };
type BookingConfirmation = { reference: string; service_name: string; service_name_ar?: string; quoted_price: number; currency: string };

const categoryNames = ['Music production', 'Recording sessions', 'Mixing & mastering', 'Audio engineering', 'Music videos'];
const emptyProjects: Project[] = [];
const emptyServices: Service[] = [];
const emptyCampaigns: Campaign[] = [];
const currentYear = new Date().getFullYear();
const dateForInput = () => {
  const value = new Date(Date.now() + 60 * 60 * 1000);
  value.setMinutes(Math.ceil(value.getMinutes() / 30) * 30, 0, 0);
  return `${value.getFullYear()}-${String(value.getMonth() + 1).padStart(2, '0')}-${String(value.getDate()).padStart(2, '0')}T${String(value.getHours()).padStart(2, '0')}:${String(value.getMinutes()).padStart(2, '0')}`;
};

function formatPrice(price: number, currency: string, language: Language): string {
  const amount = new Intl.NumberFormat(language === 'ar' ? 'ar-EG' : 'en-EG', { maximumFractionDigits: 0 }).format(price);
  return `${amount} ${currency === 'EGP' && language === 'ar' ? 'ج.م' : currency}`;
}

function servicePrice(service: Service, duration: number, now: number): number {
  const discounted = service.discount_price !== null && service.discount_price !== undefined
    && (!service.discount_start || new Date(service.discount_start).getTime() <= now)
    && (!service.discount_end || new Date(service.discount_end).getTime() >= now);
  const unit = discounted ? service.discount_price! : service.price;
  return service.billing_unit.toLowerCase().includes('hour') ? unit * Math.ceil(duration / 60) : unit;
}

function waveformBars(count: number, seed: number) {
  return Array.from({ length: count }, (_, index) => {
    const wave = Math.abs(Math.sin((index + seed * 8) * 0.41) * Math.cos((index + seed) * 0.16));
    return `${22 + Math.round(wave * 78)}%`;
  });
}

function youtubeId(url: string): string | null {
  try {
    const parsed = new URL(url);
    if (parsed.hostname.includes('youtu.be')) return parsed.pathname.slice(1).split('/')[0] || null;
    if (parsed.hostname.includes('youtube.com')) return parsed.searchParams.get('v') || parsed.pathname.split('/').filter(Boolean).at(-1) || null;
  } catch { return null; }
  return null;
}

function Waveform({ count = 54, seed = 2, className = '' }: { count?: number; seed?: number; className?: string }) {
  const bars = waveformBars(count, seed);
  return <div className={`waveform ${className}`} aria-hidden="true">{bars.map((height, index) => <i key={index} style={{ height, animationDelay: `${(index % 13) * 0.035}s` }} />)}</div>;
}

function ProjectCard({ project, index, language, studioName, onPlay }: { project: Project; index: number; language: Language; studioName: string; onPlay: (track: Track) => void }) {
  const [expanded, setExpanded] = useState(false);
  const projectTitle = localize(project.title, project.title_ar, language);
  const projectDescription = localize(project.description, project.description_ar, language, project.category);
  const projectCredits = localize(project.credits, project.credits_ar, language);
  const audio = project.media.filter((item) => item.kind === 'audio');
  const imageMedia = project.media.filter((item) => item.kind === 'image');
  const videoMedia = project.media.filter((item) => item.kind === 'video');
  const youtubeMedia = project.media.filter((item) => item.kind === 'youtube');
  const cover = project.cover_image || imageMedia[0]?.url;
  return (
    <article className={`project-card ${project.is_featured ? 'project-featured' : ''}`}>
      <div className="project-art" style={cover ? { backgroundImage: `linear-gradient(180deg, transparent 35%, rgba(4, 8, 12, .85)), url("${cover}")` } : undefined}>
        {!cover && <div className="project-art-note"><Disc3 size={38} strokeWidth={1.2} /><Waveform count={26} seed={index + 6} /></div>}
        <span className="project-number">{String(index + 1).padStart(2, '0')}</span>
        {project.is_featured && <span className="featured-chip"><Sparkles size={12} /> {tx(language, 'Featured')}</span>}
        {audio.length > 0 && <button className="project-play" type="button" onClick={() => onPlay({ url: audio[0].url, title: audio[0].title, title_ar: audio[0].title_ar, project: project.title, project_ar: project.title_ar, mime: audio[0].mime })} aria-label={`${t(language, 'listen')}: ${projectTitle}`}><Play size={17} fill="currentColor" /></button>}
        <div className="project-cover-title"><span>{tx(language, project.category)}</span><h3>{projectTitle}</h3></div>
      </div>
      <div className="project-info">
        <p>{projectDescription}</p>
        <div className="project-meta"><span>{project.release_date || projectCredits || studioName}</span><button type="button" className="text-button" onClick={() => setExpanded((current) => !current)}>{expanded ? tx(language, 'Close') : t(language, 'openProject')} <ArrowUpRight size={14} /></button></div>
        {expanded && <div className="project-detail">
          {project.tags.length > 0 && <div className="tag-list">{project.tags.map((tag) => <span key={tag}>{tag}</span>)}</div>}
          {projectCredits && <p className="credit-line">{projectCredits}</p>}
          {audio.map((item) => { const title = localize(item.title, item.title_ar, language, projectTitle); return <button key={item.id} type="button" className="media-row" onClick={() => onPlay({ url: item.url, title: item.title, title_ar: item.title_ar, project: project.title, project_ar: project.title_ar, mime: item.mime })}><span className="media-icon"><Music2 size={16} /></span><span>{title}</span><Play size={14} /></button>; })}
          {imageMedia.length > 0 && <div className="detail-gallery">{imageMedia.map((item) => <img src={item.url} key={item.id} alt={localize(item.title, item.title_ar, language, projectTitle)} loading="lazy" />)}</div>}
          {videoMedia.map((item) => <video key={item.id} className="project-video" controls preload="metadata" src={item.url} aria-label={localize(item.title, item.title_ar, language, projectTitle)} />)}
          {youtubeMedia.map((item) => {
            const id = youtubeId(item.url);
            const mediaTitle = localize(item.title, item.title_ar, language, projectTitle);
            return id ? <div className="youtube-frame" key={item.id}><iframe src={`https://www.youtube-nocookie.com/embed/${encodeURIComponent(id)}`} title={mediaTitle} loading="lazy" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowFullScreen /></div> : <a key={item.id} className="media-row" href={item.url} target="_blank" rel="noreferrer"><CirclePlay size={16} />{mediaTitle || tx(language, 'Watch on YouTube')}<ArrowUpRight size={14} /></a>;
          })}
          {project.media.filter((item) => item.kind === 'external').map((item) => <a key={item.id} className="media-row" href={item.url} target="_blank" rel="noreferrer"><ArrowUpRight size={16} />{localize(item.title, item.title_ar, language, tx(language, 'Open media'))}</a>)}
        </div>}
      </div>
    </article>
  );
}

function OfferBanner({ campaign, language }: { campaign: Campaign; language: Language }) {
  const [counted, setCounted] = useState(false);
  const title = localize(campaign.title, campaign.title_ar, language);
  const description = localize(campaign.description, campaign.description_ar, language);
  const ctaLabel = localize(campaign.cta_label, campaign.cta_label_ar, language);
  const handleClick = () => {
    if (!counted) {
      setCounted(true);
      void api(`/api/campaigns/${campaign.id}/click`, { method: 'POST' }).catch(() => undefined);
    }
  };
  return <article className={`offer-card ${campaign.media_url ? 'offer-with-art' : ''}`} style={campaign.media_url ? { backgroundImage: `linear-gradient(90deg, rgba(5, 9, 13, .94), rgba(5, 9, 13, .55)), url("${campaign.media_url}")` } : undefined}>
    <div className="offer-symbol"><Sparkles size={20} /></div>
    <div className="offer-copy"><span className="eyebrow">{campaign.kind === 'studio' ? tx(language, 'YJ STUDIO') : tx(language, 'PARTNER ANNOUNCEMENT')} · {tx(language, campaign.placement)}</span><h3>{title}</h3><p>{description}</p></div>
    {ctaLabel && campaign.destination_url && <a className="button button-outline offer-action" href={campaign.destination_url} onClick={handleClick} target={campaign.destination_url.startsWith('http') ? '_blank' : undefined} rel="noreferrer">{ctaLabel} <ArrowUpRight size={16} /></a>}
  </article>;
}

export default function PublicSite({ language, onLanguageChange, themeMode, onThemeChange, onInstall, canInstall }: Props) {
  const [data, setData] = useState<PublicData | null>(null);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState('');
  const [mobileOpen, setMobileOpen] = useState(false);
  const [category, setCategory] = useState('all');
  const [search, setSearch] = useState('');
  const [selectedServiceId, setSelectedServiceId] = useState('');
  const [durationHours, setDurationHours] = useState(1);
  const [bookingError, setBookingError] = useState('');
  const [bookingConfirmation, setBookingConfirmation] = useState<BookingConfirmation | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [track, setTrack] = useState<Track | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [renderTime] = useState(() => Date.now());
  const audioRef = useRef<HTMLAudioElement>(null);
  const logoFallback = defaultSettings.logo_path;
  const settings = data?.settings ?? defaultSettings;
  const studioName = localize(settings.studio_name, settings.studio_name_ar, language, 'YJ Studio');

  useEffect(() => {
    let active = true;
    api<PublicData>('/api/public').then((result) => {
      if (!active) return;
      setData(result);
      if (result.services.length) setSelectedServiceId((current) => current || result.services[0].id || '');
      setLoadError('');
    }).catch((error: Error) => { if (active) setLoadError(error.message); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, []);

  useEffect(() => {
    document.title = localize(settings.seo_title, settings.seo_title_ar, language, 'YJ Studio');
    const description = document.querySelector('meta[name="description"]');
    if (description) description.setAttribute('content', localize(settings.seo_description, settings.seo_description_ar, language, ''));
    const socialImage = document.querySelector('meta[property="og:image"]');
    if (socialImage) socialImage.setAttribute('content', settings.social_image || settings.logo_path || '/yj-studio-logo.jpg');
    const socialTitle = document.querySelector('meta[property="og:title"]');
    if (socialTitle) socialTitle.setAttribute('content', document.title);
    const socialDescription = document.querySelector('meta[property="og:description"]');
    if (socialDescription) socialDescription.setAttribute('content', localize(settings.seo_description, settings.seo_description_ar, language, ''));
    const socialLocale = document.querySelector('meta[property="og:locale"]');
    if (socialLocale) socialLocale.setAttribute('content', language === 'ar' ? 'ar_EG' : 'en_US');
  }, [language, settings.logo_path, settings.seo_description, settings.seo_description_ar, settings.seo_title, settings.seo_title_ar, settings.social_image]);

  useEffect(() => {
    if (!track || !audioRef.current) return;
    const audio = audioRef.current;
    audio.src = track.url;
    audio.load();
    audio.play().then(() => setIsPlaying(true)).catch(() => setIsPlaying(false));
  }, [track]);

  const services = data?.services ?? emptyServices;
  const projects = data?.projects ?? emptyProjects;
  const campaigns = data?.campaigns ?? emptyCampaigns;
  const selectedService = services.find((service) => service.id === selectedServiceId) ?? services[0];
  const durationMinutes = selectedService?.billing_unit.toLowerCase().includes('hour') ? durationHours * 60 : selectedService?.duration_minutes ?? 60;
  const estimatedPrice = selectedService ? servicePrice(selectedService, durationMinutes, renderTime) : null;
  const liveProjects = useMemo(() => {
    const term = search.trim().toLowerCase();
    return projects.filter((project) => (category === 'all' || project.category === category)
      && (!term || `${project.title} ${project.title_ar} ${project.description} ${project.description_ar} ${project.tags.join(' ')}`.toLowerCase().includes(term)));
  }, [category, projects, search]);
  const liveOffers = campaigns.filter((campaign) => campaign.placement === 'announcements' || campaign.placement === 'homepage banner');
  const heroCampaign = campaigns.find((campaign) => campaign.placement === 'homepage hero');
  const portfolioCampaigns = campaigns.filter((campaign) => campaign.placement === 'portfolio');
  const serviceCampaigns = campaigns.filter((campaign) => campaign.placement === 'services');
  const visibleSections = new Set(settings.visible_sections.split(',').filter(Boolean));
  const isVisible = (section: string) => visibleSections.has(section);
  const featured = liveProjects.filter((project) => project.is_featured).slice(0, 3);
  const visibleFeatured = featured.length ? featured : liveProjects.slice(0, 3);

  const chooseTrack = (next: Track) => {
    if (track?.url === next.url && audioRef.current) {
      if (audioRef.current.paused) { void audioRef.current.play().then(() => setIsPlaying(true)).catch(() => setIsPlaying(false)); }
      else { audioRef.current.pause(); setIsPlaying(false); }
      return;
    }
    setTrack(next);
  };

  const scrollTo = (id: string) => {
    setMobileOpen(false);
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  async function submitBooking(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBookingError('');
    setBookingConfirmation(null);
    if (!selectedService) { setBookingError(t(language, 'noService')); return; }
    const bookingForm = event.currentTarget;
    const form = new FormData(bookingForm);
    const customerName = String(form.get('customer_name') || '').trim();
    const phone = String(form.get('phone') || '').trim();
    const email = String(form.get('email') || '').trim();
    const preferredAtValue = String(form.get('preferred_at') || '');
    const preferredAtTime = new Date(preferredAtValue).getTime();
    const earliestTime = new Date(dateForInput()).getTime();
    if (customerName.length < 2) { setBookingError('Enter a name with at least 2 characters.'); return; }
    if (phone.replace(/\D/g, '').length < 7) { setBookingError('Enter a valid phone number with at least 7 digits.'); return; }
    if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { setBookingError('Enter a valid email address or leave it blank.'); return; }
    if (!preferredAtValue || Number.isNaN(preferredAtTime)) { setBookingError('Choose a valid appointment date and time.'); return; }
    if (preferredAtTime < earliestTime) { setBookingError('Choose an appointment time at least one hour from now.'); return; }
    const payload = {
      customer_name: customerName,
      phone,
      email,
      service_id: selectedService.id ?? '',
      preferred_at: new Date(preferredAtTime).toISOString(),
      duration_minutes: durationMinutes,
      project_details: String(form.get('project_details') || ''),
      language,
    };
    setSubmitting(true);
    try {
      const result = await api<BookingConfirmation>('/api/bookings', { method: 'POST', body: JSON.stringify(payload) });
      setBookingConfirmation(result);
      bookingForm.reset();
    } catch (error) {
      setBookingError(error instanceof Error ? error.message : 'The booking could not be saved. Try again.');
    } finally { setSubmitting(false); }
  }

  const phoneForWhatsApp = settings.whatsapp_number.replace(/\D/g, '');
  const navItems = [
    ['top', localize(settings.nav_home, settings.nav_home_ar, language, t(language, 'home'))], ['portfolio', localize(settings.nav_portfolio, settings.nav_portfolio_ar, language, t(language, 'portfolio'))],
    ['services', localize(settings.nav_services, settings.nav_services_ar, language, t(language, 'services'))], ['offers', localize(settings.nav_offers, settings.nav_offers_ar, language, t(language, 'offers'))],
    ['about', localize(settings.nav_about, settings.nav_about_ar, language, t(language, 'about'))], ['contact', localize(settings.nav_contact, settings.nav_contact_ar, language, t(language, 'contact'))],
  ].filter(([id]) => id === 'top' || isVisible(id));

  return <div className={`public-site ${language === 'ar' ? 'rtl' : ''}`}>
    <header className="site-header">
      <a href="#top" className="brand" aria-label={`${studioName} ${t(language, 'home')}`} onClick={() => setMobileOpen(false)}><img src={settings.logo_path || logoFallback} alt={studioName} /><span><strong>{studioName.toUpperCase()}</strong><small>{tx(language, 'SOUND ENGINEERING')}</small></span></a>
      <nav className={`main-nav ${mobileOpen ? 'nav-open' : ''}`} aria-label={tx(language, 'Main navigation')}>
        {navItems.map(([id, label]) => <button type="button" key={id} className="nav-link" onClick={() => scrollTo(id)}>{label}</button>)}
        <div className="nav-preferences"><PreferenceControls language={language} onLanguageChange={onLanguageChange} themeMode={themeMode} onThemeChange={onThemeChange} /></div>
      </nav>
      <div className="header-actions">
        {canInstall && <button type="button" className="install-button" onClick={onInstall}><ArrowDown size={14} /> {tx(language, 'Install app')}</button>}
        {isVisible('booking') && <button type="button" className="header-booking" onClick={() => scrollTo('booking')}>{t(language, 'bookSession')} <ArrowUpRight size={15} /></button>}
        <button type="button" className="menu-toggle" aria-label={tx(language, mobileOpen ? 'Close menu' : 'Open menu')} aria-expanded={mobileOpen} onClick={() => setMobileOpen((open) => !open)}>{mobileOpen ? <X /> : <Menu />}</button>
      </div>
    </header>

    <main>
      <section className="hero-section" id="top">
        <div className="hero-grid" />
        <div className="hero-glow hero-glow-left" />
        <div className="hero-glow hero-glow-right" />
        <div className="hero-content">
          <div className="eyebrow hero-eyebrow"><span className="live-dot" /> {t(language, 'soundTag')}</div>
          <h1>{localize(settings.hero_title, settings.hero_title_ar, language)}</h1>
          <p className="hero-copy">{localize(settings.hero_subtitle, settings.hero_subtitle_ar, language)}</p>
          <div className="hero-actions">
            {isVisible('booking') && <button type="button" className="button button-primary" onClick={() => scrollTo('booking')}>{t(language, 'bookSession')} <ArrowRight size={17} /></button>}
            {isVisible('portfolio') && <button type="button" className="button button-ghost" onClick={() => scrollTo('portfolio')}>{t(language, 'exploreWork')} <ArrowDown size={16} /></button>}
          </div>
          <div className="hero-credits"><span><AudioLines size={15} /> {tx(language, 'Precision in every frequency')}</span><i /> <span>{tx(language, 'Independent sound. Lasting impact.')}</span></div>
        </div>
        <div className="hero-art-column">
          <div className="hero-signal-label signal-label-left"><span>{tx(language, 'INPUT')}</span><b dir="ltr">48 kHz</b></div>
          <div className="hero-art-wrap"><div className="hero-ring hero-ring-one" /><div className="hero-ring hero-ring-two" /><div className="logo-plate"><img src={settings.logo_path || logoFallback} alt={localize(settings.seo_title, settings.seo_title_ar, language, 'YJ Studio')} /></div><div className="orbit-point orbit-point-top" /><div className="orbit-point orbit-point-bottom" /></div>
          <div className="hero-signal-label signal-label-right"><span>{tx(language, 'OUTPUT')}</span><b dir="ltr">24 bit</b></div>
          <div className="hero-wave-strip"><Waveform count={48} seed={4} /></div>
        </div>
        <div className="hero-bottomline"><span>{tx(language, 'STUDIO NOTES')} <span className="cyan-text">/ 001</span></span><span><bdi dir="ltr">{tx(language, 'CAIRO · EGYPT')}</bdi> <span className="cyan-text">—</span> {tx(language, 'AVAILABLE FOR SELECT PROJECTS')}</span></div>
        {heroCampaign && <div className="hero-campaign"><Sparkles size={14} /><span>{localize(heroCampaign.title, heroCampaign.title_ar, language)}</span>{heroCampaign.destination_url ? <a href={heroCampaign.destination_url} onClick={() => void api(`/api/campaigns/${heroCampaign.id}/click`, { method: 'POST' }).catch(() => undefined)} target={heroCampaign.destination_url.startsWith('http') ? '_blank' : undefined} rel="noreferrer">{localize(heroCampaign.cta_label, heroCampaign.cta_label_ar, language, tx(language, 'Discover'))} <ArrowUpRight size={13} /></a> : heroCampaign.cta_label && isVisible('offers') && <button type="button" onClick={() => scrollTo('offers')}>{localize(heroCampaign.cta_label, heroCampaign.cta_label_ar, language)} <ArrowRight size={13} /></button>}</div>}
      </section>

      <section className="ticker-section" aria-label={t(language, 'services')}><div className="ticker-track"><span>{tx(language, 'RECORDING')}</span><i>✳</i><span>{tx(language, 'MUSIC PRODUCTION')}</span><i>✳</i><span>{tx(language, 'MIXING & MASTERING')}</span><i>✳</i><span>{tx(language, 'VISUAL PRODUCTION')}</span><i>✳</i><span>{tx(language, 'RECORDING')}</span><i>✳</i><span>{tx(language, 'MUSIC PRODUCTION')}</span><i>✳</i><span>{tx(language, 'MIXING & MASTERING')}</span><i>✳</i><span>{tx(language, 'VISUAL PRODUCTION')}</span><i>✳</i></div></section>

      {(settings.maintenance_message || settings.maintenance_message_ar) && <div className="maintenance-banner"><span className="live-dot" />{localize(settings.maintenance_message, settings.maintenance_message_ar, language)}</div>}
      {loading && <div className="loading-banner"><span className="spinner" /> {t(language, 'loading')}</div>}
      {loadError && <div className="site-error" role="alert">{tx(language, loadError)}</div>}

      {isVisible('portfolio') && <section className="section portfolio-section" id="portfolio">
        <div className="section-topline"><span className="eyebrow">01 / {tx(language, 'WORK')}</span><span className="section-aside">{tx(language, 'CRAFTED IN THE ROOM. HEARD EVERYWHERE.')}</span></div>
        <div className="section-heading-row"><div><h2>{t(language, 'latestProjects')}</h2><p>{t(language, 'portfolioIntro')}</p></div><span className="work-count">{String(projects.length).padStart(2, '0')} <small>{tx(language, 'PROJECTS')}</small></span></div>
        <div className="portfolio-tools">
          <div className="filter-row" role="group" aria-label={t(language, 'allCategories')}>
            <button type="button" className={category === 'all' ? 'filter active' : 'filter'} onClick={() => setCategory('all')}>{t(language, 'allCategories')}</button>
            {categoryNames.map((item) => <button type="button" className={category === item ? 'filter active' : 'filter'} key={item} onClick={() => setCategory(item)}>{tx(language, item)}</button>)}
          </div>
          <label className="project-search"><span className="sr-only">{t(language, 'searchProjects')}</span><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder={t(language, 'searchProjects')} /><span>⌕</span></label>
        </div>
        {portfolioCampaigns.map((campaign) => <OfferBanner key={campaign.id} campaign={campaign} language={language} />)}
        {loading && !projects.length ? <div className="project-skeletons"><i /><i /><i /></div> : liveProjects.length ? <div className="project-grid">{liveProjects.map((project, index) => <ProjectCard key={project.id} project={project} index={index} language={language} studioName={studioName} onPlay={chooseTrack} />)}</div> : <div className="empty-state"><Disc3 size={28} /><p>{search || category !== 'all' ? tx(language, 'No projects match this filter.') : t(language, 'noProjects')}</p></div>}
        {visibleFeatured.length > 0 && <div className="featured-note"><span><Sparkles size={15} /> {t(language, 'featuredWork')}</span><span>{visibleFeatured.map((item) => localize(item.title, item.title_ar, language)).join(' · ')}</span></div>}
      </section>}

      {isVisible('services') && <section className="section services-section" id="services">
        <div className="section-topline"><span className="eyebrow">02 / {t(language, 'services')}</span><span className="section-aside">{tx(language, 'BUILT AROUND THE SONG')}</span></div>
        <div className="section-heading-row"><div><h2>{t(language, 'servicesTitle')}</h2><p>{t(language, 'servicesIntro')}</p></div><span className="service-stamp"><Headphones size={21} /><span>{tx(language, 'STUDIO SERVICES')}</span></span></div>
        {serviceCampaigns.map((campaign) => <OfferBanner key={campaign.id} campaign={campaign} language={language} />)}
        {services.length ? <div className="service-grid">{services.map((service, index) => {
          const discounted = service.discount_price !== null && service.discount_price !== undefined && (!service.discount_start || new Date(service.discount_start).getTime() <= renderTime) && (!service.discount_end || new Date(service.discount_end).getTime() >= renderTime);
          return <article className={`service-card ${index === 0 ? 'service-card-featured' : ''}`} key={service.id}>
            <div className="service-card-top"><span className="service-index">0{index + 1}</span><span className="service-dot" /></div>
            <div className="service-icon">{index === 0 ? <Radio /> : index === 1 ? <AudioLines /> : <Disc3 />}</div>
            <h3>{localize(service.name, service.name_ar, language)}</h3><p>{localize(service.description, service.description_ar, language)}</p>
            <div className="service-price"><div>{discounted && <s><bdi dir="ltr">{formatPrice(service.price, service.currency, language)}</bdi></s>}<strong><bdi dir="ltr">{formatPrice(discounted ? service.discount_price! : service.price, service.currency, language)}</bdi></strong><small>{tx(language, service.billing_unit)}</small></div>{service.duration_minutes && <span dir="ltr">{service.duration_minutes} {tx(language, 'min')}</span>}</div>
            <button type="button" className="service-book" onClick={() => { setSelectedServiceId(service.id ?? ''); scrollTo('booking'); }}>{t(language, 'bookThis')} <ArrowRight size={16} /></button>
          </article>;
        })}</div> : <div className="empty-state"><Headphones size={28} /><p>{t(language, 'noService')}</p></div>}
      </section>}

      {isVisible('offers') && <section className="section offers-section" id="offers">
        <div className="section-topline"><span className="eyebrow">03 / {tx(language, 'NOTICEBOARD')}</span><span className="section-aside">{tx(language, 'A LITTLE NEWS FROM THE ROOM')}</span></div>
        <div className="section-heading-row"><div><h2>{t(language, 'offersTitle')}</h2><p>{t(language, 'offersIntro')}</p></div><span className="offers-count"><Sparkles size={17} /> {liveOffers.length} {tx(language, 'LIVE')}</span></div>
        {liveOffers.length ? <div className="offers-list">{liveOffers.map((campaign) => <OfferBanner key={campaign.id} campaign={campaign} language={language} />)}</div> : <div className="empty-state empty-state-small"><Sparkles size={24} /><p>{t(language, 'noOffers')}</p></div>}
      </section>}

      {isVisible('about') && <section className="about-section" id="about">
        <div className="about-image"><div className="about-image-grid" /><img src={settings.logo_path || logoFallback} alt={`${studioName} ${tx(language, 'emblem')}`} loading="lazy" /><div className="about-image-caption"><span>YJ / STUDIO</span><span><bdi dir="ltr">{tx(language, 'CAIRO · EGYPT')}</bdi></span></div></div>
        <div className="about-copy"><span className="eyebrow">04 / {tx(language, 'THE STUDIO')}</span><h2>{t(language, 'aboutTitle')}</h2><p>{localize(settings.about_text, settings.about_text_ar, language)}</p><div className="about-signature"><span className="signature-mark">YJ</span><span><b>{tx(language, 'Engineer Yousab')}</b><small>{tx(language, 'FOUNDER · AUDIO ENGINEER')}</small></span></div><div className="about-facts"><div><b>01</b><span>{tx(language, 'DETAIL DRIVEN')}</span></div><div><b>02</b><span>{tx(language, 'ARTIST FOCUSED')}</span></div><div><b>03</b><span>{tx(language, 'BUILT TO LAST')}</span></div></div></div>
      </section>}

      {isVisible('booking') && <section className="booking-section" id="booking">
        <div className="booking-visual"><div className="booking-ring ring-a" /><div className="booking-ring ring-b" /><div className="booking-visual-copy"><span className="eyebrow">05 / {tx(language, 'YOUR NEXT TAKE')}</span><h2>{t(language, 'bookingTitle')}</h2><p>{t(language, 'bookingIntro')}</p><div className="booking-accent"><Waveform count={32} seed={11} /><span><CalendarDays size={15} /> {tx(language, 'BY APPOINTMENT')}</span></div></div><span className="booking-visual-mark" dir="ltr">YJ—01</span></div>
        <div className="booking-panel">
          {bookingConfirmation ? <div className="booking-success" role="status"><div className="success-mark"><Check size={24} /></div><span className="eyebrow">{t(language, 'bookingSent')}</span><h3>{t(language, 'bookingReference')}</h3><strong className="booking-reference" dir="ltr">{bookingConfirmation.reference}</strong><p>{t(language, 'bookingPending')}</p><div className="confirmation-price">{localize(bookingConfirmation.service_name, bookingConfirmation.service_name_ar, language)}<b>{formatPrice(bookingConfirmation.quoted_price, bookingConfirmation.currency, language)}</b></div><div className="confirmation-actions">{phoneForWhatsApp && <a className="button button-outline" href={`https://wa.me/${phoneForWhatsApp}?text=${encodeURIComponent(txf(language, 'Hi, I submitted booking request {reference} for {service}.', { reference: bookingConfirmation.reference, service: localize(bookingConfirmation.service_name, bookingConfirmation.service_name_ar, language) }))}`} target="_blank" rel="noreferrer">{t(language, 'continueWhatsApp')} <ArrowUpRight size={15} /></a>}<button type="button" className="button button-ghost" onClick={() => setBookingConfirmation(null)}>{tx(language, 'Request another session')}</button></div></div> : <form className="booking-form" noValidate onSubmit={submitBooking}>
            <div className="booking-form-heading"><span className="eyebrow">{tx(language, 'SESSION REQUEST')}</span><span className="form-step" dir="ltr">01 — 03</span></div>
            {bookingError && <div className="form-error" role="alert">{tx(language, bookingError)}</div>}
            <div className="form-grid"><label>{t(language, 'name')}<input required name="customer_name" minLength={2} maxLength={120} autoComplete="name" /></label><label>{t(language, 'phone')}<input required name="phone" type="tel" minLength={7} maxLength={35} autoComplete="tel" dir="ltr" /></label></div>
            <label>{t(language, 'email')}<input name="email" type="email" maxLength={254} autoComplete="email" dir="ltr" /></label>
            <label>{t(language, 'service')}<select name="service_id" required value={selectedServiceId} onChange={(event) => setSelectedServiceId(event.target.value)} disabled={!services.length}><option value="" disabled>{t(language, 'service')}</option>{services.map((service) => <option key={service.id} value={service.id} dir="auto">{localize(service.name, service.name_ar, language)} · {formatPrice(service.price, service.currency, language)}</option>)}</select></label>
            <div className="form-grid"><label>{t(language, 'sessionTime')}<input required name="preferred_at" type="datetime-local" min={dateForInput()} defaultValue={dateForInput()} dir="ltr" /></label>{selectedService?.billing_unit.toLowerCase().includes('hour') && <label>{t(language, 'duration')}<select value={durationHours} onChange={(event) => setDurationHours(Number(event.target.value))}>{[1, 2, 3, 4, 5, 6].map((hours) => <option key={hours} value={hours}>{new Intl.NumberFormat(language === 'ar' ? 'ar-EG' : 'en-EG').format(hours)} {hours === 1 ? tx(language, 'hour') : tx(language, 'hours')}</option>)}</select></label>}</div>
            <label>{t(language, 'projectDetails')}<textarea name="project_details" rows={3} maxLength={2000} placeholder={tx(language, 'A few details about the session…')} /></label>
            <div className="booking-price-summary"><span>{t(language, 'amountDue')}</span><strong dir="ltr">{estimatedPrice === null ? '—' : formatPrice(estimatedPrice, selectedService?.currency ?? 'EGP', language)}</strong><small>{selectedService ? tx(language, selectedService.billing_unit) : ''}{selectedService?.billing_unit.toLowerCase().includes('hour') ? ` · ${new Intl.NumberFormat(language === 'ar' ? 'ar-EG' : 'en-EG').format(durationHours)} ${durationHours === 1 ? tx(language, 'hour') : tx(language, 'hours')}` : ''}</small></div>
            <button className="button button-primary booking-submit" type="submit" disabled={submitting || !services.length}>{submitting ? tx(language, 'Sending request…') : t(language, 'submitBooking')} <ArrowRight size={16} /></button>
            <p className="form-privacy">{t(language, 'bookingHelp')} <br />{t(language, 'privacyNote')}</p>
          </form>}
        </div>
      </section>}

      {isVisible('contact') && <section className="contact-strip" id="contact"><div><span className="eyebrow">{tx(language, 'LET’S MAKE SOMETHING THAT MATTERS')}</span><h2>{tx(language, 'Start with a conversation.')}</h2></div><div className="contact-actions">{phoneForWhatsApp && <a href={`https://wa.me/${phoneForWhatsApp}?text=${encodeURIComponent(txf(language, 'Hi, I would like to ask about a session at {studio}.', { studio: studioName }))}`} className="button button-primary" target="_blank" rel="noreferrer"><span>{t(language, 'sendWhatsApp')}</span><ArrowUpRight size={16} /></a>}{settings.contact_phone && <a href={`tel:${settings.contact_phone.replace(/[^+\d]/g, '')}`} className="button button-ghost" dir="ltr">{settings.contact_phone} <ArrowUpRight size={16} /></a>}{settings.contact_email && <a href={`mailto:${settings.contact_email}`} className="button button-ghost" dir="ltr">{settings.contact_email} <ArrowUpRight size={16} /></a>}{settings.youtube_url && <a href={settings.youtube_url} className="social-button" target="_blank" rel="noreferrer" aria-label="YouTube"><CirclePlay size={18} /></a>}{settings.instagram_url && <a href={settings.instagram_url} className="social-button" target="_blank" rel="noreferrer" aria-label="Instagram"><AtSign size={18} /></a>}</div></section>}
    </main>

    <footer className="site-footer"><a href="#top" className="footer-brand"><img src={settings.logo_path || logoFallback} alt="" /><span>{studioName.toUpperCase()}</span></a><div className="footer-credit"><span>{localize(settings.footer_note, settings.footer_note_ar, language)}</span><small dir="ltr">© {currentYear} {studioName.toUpperCase()} · CAIRO</small></div><a href="/admin" className="footer-admin">{t(language, 'admin')} <ArrowUpRight size={12} /></a></footer>

    {track && <div className="audio-dock" dir="ltr"><div className="dock-art"><AudioLines size={18} /></div><div className="dock-track"><span>{t(language, 'nowPlaying')}</span><strong>{localize(track.title, track.title_ar, language, track.project)}</strong><small>{localize(track.project, track.project_ar, language)}</small></div><button className="dock-play" type="button" onClick={() => { if (!audioRef.current) return; if (audioRef.current.paused) void audioRef.current.play().then(() => setIsPlaying(true)); else { audioRef.current.pause(); setIsPlaying(false); } }} aria-label={isPlaying ? t(language, 'pause') : t(language, 'listen')}>{isPlaying ? <Pause size={16} fill="currentColor" /> : <Play size={16} fill="currentColor" />}</button><audio ref={audioRef} controls onPlay={() => setIsPlaying(true)} onPause={() => setIsPlaying(false)} onEnded={() => setIsPlaying(false)} aria-label={tx(language, 'Audio player')} /><button type="button" className="dock-close" onClick={() => { audioRef.current?.pause(); setTrack(null); setIsPlaying(false); }} aria-label={tx(language, 'Close player')}><X size={15} /></button></div>}
  </div>;
}
