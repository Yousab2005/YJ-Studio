import { useEffect, useRef, useState, type KeyboardEvent } from 'react';
import { Check, ChevronDown, Monitor, Moon, Sun } from 'lucide-react';
import { themeLabel, tx, type Language, type ThemeMode } from './i18n';

type Props = {
  language: Language;
  onLanguageChange: (language: Language) => void;
  themeMode: ThemeMode;
  onThemeChange: (mode: ThemeMode) => void;
  className?: string;
};

const themeOptions: { mode: ThemeMode; icon: typeof Moon; en: string; ar: string }[] = [
  { mode: 'dark', icon: Moon, en: 'Dark Mode', ar: 'الوضع الداكن' },
  { mode: 'light', icon: Sun, en: 'Light Mode', ar: 'الوضع الفاتح' },
  { mode: 'system', icon: Monitor, en: 'System Mode', ar: 'حسب الجهاز' },
];

export default function PreferenceControls({ language, onLanguageChange, themeMode, onThemeChange, className = '' }: Props) {
  const [open, setOpen] = useState(false);
  const rootRef = useRef<HTMLDivElement>(null);
  const menuRef = useRef<HTMLDivElement>(null);
  const triggerRef = useRef<HTMLButtonElement>(null);
  const current = themeOptions.find((option) => option.mode === themeMode) ?? themeOptions[2];
  const ThemeIcon = current.icon;

  useEffect(() => {
    const closeOutside = (event: PointerEvent) => {
      if (!rootRef.current?.contains(event.target as Node)) setOpen(false);
    };
    const closeOnEscape = (event: globalThis.KeyboardEvent) => {
      if (event.key === 'Escape' && open) { setOpen(false); triggerRef.current?.focus(); }
    };
    document.addEventListener('pointerdown', closeOutside);
    document.addEventListener('keydown', closeOnEscape);
    return () => {
      document.removeEventListener('pointerdown', closeOutside);
      document.removeEventListener('keydown', closeOnEscape);
    };
  }, [open]);

  useEffect(() => {
    if (open) menuRef.current?.querySelector<HTMLButtonElement>('[aria-checked="true"]')?.focus();
  }, [open]);

  const handleMenuKeyDown = (event: KeyboardEvent<HTMLDivElement>) => {
    const buttons = Array.from(menuRef.current?.querySelectorAll<HTMLButtonElement>('[role="menuitemradio"]') ?? []);
    const currentIndex = buttons.indexOf(document.activeElement as HTMLButtonElement);
    if (event.key !== 'ArrowDown' && event.key !== 'ArrowUp') return;
    event.preventDefault();
    const direction = event.key === 'ArrowDown' ? 1 : -1;
    buttons[(currentIndex + direction + buttons.length) % buttons.length]?.focus();
  };

  return <div ref={rootRef} className={`preference-controls ${className}`}>
    <div className="language-control" role="group" aria-label={tx(language, 'Choose language')}>
      <button type="button" lang="ar" aria-pressed={language === 'ar'} className={language === 'ar' ? 'selected' : ''} onClick={() => onLanguageChange('ar')}>العربية</button>
      <button type="button" lang="en" aria-pressed={language === 'en'} className={language === 'en' ? 'selected' : ''} onClick={() => onLanguageChange('en')}>English</button>
    </div>
    <div className="theme-control">
      <button ref={triggerRef} type="button" className="theme-trigger" aria-label={`${tx(language, 'Current theme')}: ${themeLabel(language, themeMode)}`} aria-haspopup="menu" aria-expanded={open} onKeyDown={(event) => { if (event.key === 'ArrowDown') { event.preventDefault(); setOpen(true); } }} onClick={() => setOpen((value) => !value)}>
        <ThemeIcon size={16} aria-hidden="true" />
        <span>{themeLabel(language, themeMode)}</span>
        <ChevronDown size={13} aria-hidden="true" />
      </button>
      {open && <div className="theme-menu" role="menu" aria-label={tx(language, 'Choose theme')} ref={menuRef} onKeyDown={handleMenuKeyDown}>
        {themeOptions.map(({ mode, icon: Icon, en, ar }) => <button type="button" role="menuitemradio" aria-checked={themeMode === mode} className={themeMode === mode ? 'active' : ''} key={mode} onClick={() => { onThemeChange(mode); setOpen(false); }}>
          <Icon size={15} aria-hidden="true" />
          <span>{language === 'ar' ? ar : en}</span>
          {themeMode === mode && <Check size={14} className="theme-check" aria-hidden="true" />}
        </button>)}
      </div>}
    </div>
  </div>;
}
