export type Language = 'en' | 'ar';
export type ThemeMode = 'dark' | 'light' | 'system';

const copy = {
  en: {
    home: 'Home', portfolio: 'Portfolio', services: 'Services', offers: 'Offers', about: 'About', contact: 'Contact',
    bookSession: 'Book a session', exploreWork: 'Explore the work', soundTag: 'SOUND ENGINEERING · RECORDING · PRODUCTION',
    featuredWork: 'Selected work', latestProjects: 'Projects with a point of view.', portfolioIntro: 'A selection of the music and stories shaped at YJ Studio.',
    servicesTitle: 'Made around your sound.', servicesIntro: 'Clear pricing, thoughtful engineering, and a finished sound you can stand behind.',
    offersTitle: 'On the studio noticeboard.', offersIntro: 'Current studio offers, release notes, and announcements.',
    aboutTitle: 'A studio for the details.', bookingTitle: 'Let’s plan your next session.', bookingIntro: 'Tell us what you are making and when you would like to come in.',
    name: 'Your name', phone: 'Phone number', email: 'Email (optional)', service: 'Service', sessionTime: 'Preferred date and time',
    duration: 'Session length', projectDetails: 'Project details', submitBooking: 'Request a booking', bookingHelp: 'Your request will be reviewed by the studio. We will confirm the time with you.',
    perHour: 'hour', bookThis: 'Book this service', noProjects: 'New work is being prepared for the portfolio.', noOffers: 'There are no live announcements right now.',
    noService: 'There are no services available for booking right now.', searchProjects: 'Search projects', allCategories: 'All work', loading: 'Loading studio details…',
    bookingSent: 'Booking request received', bookingReference: 'Your reference', bookingPending: 'The studio will follow up to confirm the session.',
    amountDue: 'Current price estimate', includes: 'What’s included', currency: 'EGP', sendWhatsApp: 'Ask on WhatsApp', continueWhatsApp: 'Continue on WhatsApp',
    listen: 'Listen', pause: 'Pause', nowPlaying: 'Now playing', openProject: 'View project', byYousab: 'Created & Engineered by Engineer Yousab',
    privacyNote: 'Your contact details are shared only with the studio for this booking request.', language: 'العربية',
    admin: 'Admin', signIn: 'Sign in', username: 'Username or email', password: 'Password', dashboard: 'Dashboard',
    overview: 'Overview', projects: 'Projects', bookings: 'Bookings', campaigns: 'Campaigns', settings: 'Settings', signOut: 'Sign out',
    saveChanges: 'Save changes', cancel: 'Cancel', createNew: 'Create new', edit: 'Edit', delete: 'Delete', published: 'Published', draft: 'Draft',
    active: 'Active', paused: 'Paused', scheduled: 'Scheduled', archived: 'Archived', pending: 'Pending', confirmed: 'Confirmed',
    completed: 'Completed', cancelled: 'Cancelled', rejected: 'Rejected',
  },
  ar: {
    home: 'الرئيسية', portfolio: 'الأعمال', services: 'الخدمات', offers: 'العروض', about: 'من نحن', contact: 'تواصل معنا',
    bookSession: 'احجز جلسة', exploreWork: 'استكشف الأعمال', soundTag: 'هندسة صوتية · تسجيل · إنتاج موسيقي',
    featuredWork: 'أعمال مختارة', latestProjects: 'مشاريع لها طابعها الخاص.', portfolioIntro: 'مختارات من الموسيقى والحكايات التي صُنعت في YJ Studio.',
    servicesTitle: 'مصممة لتناسب صوتك.', servicesIntro: 'أسعار واضحة، وهندسة صوتية دقيقة، ونتيجة يمكنك الاعتزاز بها.',
    offersTitle: 'إعلانات الاستوديو.', offersIntro: 'عروض الاستوديو الحالية، وإصدارات جديدة، وآخر الأخبار.',
    aboutTitle: 'استوديو يهتم بالتفاصيل.', bookingTitle: 'لنخطط لجلستك القادمة.', bookingIntro: 'أخبرنا عن مشروعك والموعد المناسب لك.',
    name: 'الاسم', phone: 'رقم الهاتف', email: 'البريد الإلكتروني (اختياري)', service: 'الخدمة', sessionTime: 'التاريخ والوقت المفضلان',
    duration: 'مدة الجلسة', projectDetails: 'تفاصيل المشروع', submitBooking: 'إرسال طلب الحجز', bookingHelp: 'سيراجع الاستوديو طلبك وسيتواصل معك لتأكيد الموعد.',
    perHour: 'ساعة', bookThis: 'احجز هذه الخدمة', noProjects: 'نعمل على تجهيز أعمال جديدة لقسم المشاريع.', noOffers: 'لا توجد إعلانات حالية.',
    noService: 'لا توجد خدمات متاحة للحجز حالياً.', searchProjects: 'ابحث في الأعمال', allCategories: 'كل الأعمال', loading: 'جارٍ تحميل معلومات الاستوديو…',
    bookingSent: 'تم استلام طلب الحجز', bookingReference: 'رقم الطلب', bookingPending: 'سيتواصل معك الاستوديو لتأكيد الجلسة.',
    amountDue: 'السعر التقديري الحالي', includes: 'تشمل الخدمة', currency: 'جنيه مصري', sendWhatsApp: 'اسأل عبر واتساب', continueWhatsApp: 'متابعة عبر واتساب',
    listen: 'استمع', pause: 'إيقاف مؤقت', nowPlaying: 'يُشغّل الآن', openProject: 'عرض المشروع', byYousab: 'إبداع وهندسة صوتية: المهندس يوساب',
    privacyNote: 'تُستخدم بيانات التواصل لطلب الحجز فقط وتُشارك مع الاستوديو.', language: 'English',
    admin: 'الإدارة', signIn: 'تسجيل الدخول', username: 'اسم المستخدم أو البريد', password: 'كلمة المرور', dashboard: 'لوحة التحكم',
    overview: 'نظرة عامة', projects: 'المشاريع', bookings: 'الحجوزات', campaigns: 'الحملات', settings: 'الإعدادات', signOut: 'تسجيل الخروج',
    saveChanges: 'حفظ التغييرات', cancel: 'إلغاء', createNew: 'إنشاء جديد', edit: 'تعديل', delete: 'حذف', published: 'منشور', draft: 'مسودة',
    active: 'نشط', paused: 'متوقف مؤقتاً', scheduled: 'مجدول', archived: 'مؤرشف', pending: 'قيد الانتظار', confirmed: 'مؤكد',
    completed: 'مكتمل', cancelled: 'ملغي', rejected: 'مرفوض',
  },
} satisfies Record<Language, Record<string, string>>;

export type TranslationKey = keyof typeof copy.en;

export function t(language: Language, key: TranslationKey): string {
  return copy[language][key] ?? copy.en[key];
}

const phraseTranslations: Record<string, string> = {
  'Sound that stays with you.': 'صوت يبقى معك.',
  'Audio engineering, music production and visual storytelling shaped with precision.': 'هندسة صوتية وإنتاج موسيقي وسرد بصري متقن.',
  'Precision in every frequency': 'دقة في كل تردد',
  'Independent sound. Lasting impact.': 'صوت مستقل. وأثر يدوم.',
  'CRAFTED IN THE ROOM. HEARD EVERYWHERE.': 'صُنع في الاستوديو. ويصل إلى كل مكان.',
  'BUILT AROUND THE SONG': 'مصمم لخدمة الأغنية',
  'A LITTLE NEWS FROM THE ROOM': 'آخر أخبار الاستوديو',
  'LET’S MAKE SOMETHING THAT MATTERS': 'لنصنع شيئاً يترك أثراً',
  'Start with a conversation.': 'ابدأ بمحادثة.',
  'SESSION REQUEST': 'طلب جلسة',
  'BY APPOINTMENT': 'بموعد مسبق',
  'STUDIO SERVICES': 'خدمات الاستوديو',
  'PROJECTS': 'المشاريع',
  'LIVE': 'مباشر',
  'Featured': 'مميز',
  'Close': 'إغلاق',
  'Watch on YouTube': 'شاهد على YouTube',
  'Open media': 'افتح الوسائط',
  'INPUT': 'إدخال',
  'OUTPUT': 'إخراج',
  'STUDIO NOTES': 'ملاحظات الاستوديو',
  'AVAILABLE FOR SELECT PROJECTS': 'متاح لمشاريع مختارة',
  'Studio promotion': 'عرض من الاستوديو',
  'Partner announcement': 'إعلان شريك',
  'YJ STUDIO': 'YJ STUDIO',
  'PARTNER ANNOUNCEMENT': 'إعلان شريك',
  'PROJECTS WITH A POINT OF VIEW.': 'مشاريع لها طابعها الخاص.',
  'No projects match this filter.': 'لا توجد مشاريع تطابق هذا التصفية.',
  'LET’S PLAN YOUR NEXT SESSION.': 'لنخطط لجلستك القادمة.',
  'SOUND ENGINEERING': 'هندسة صوتية',
  'CONTROL ROOM': 'غرفة التحكم',
  'PRIVATE STUDIO ACCESS': 'دخول خاص للاستوديو',
  'PRIVATE SETTINGS': 'إعدادات خاصة',
  'YOUR STUDIO, AT A GLANCE': 'استوديوك في لمحة',
  'Good to have you back.': 'سعداء بعودتك.',
  'Here is what is happening across YJ Studio.': 'إليك آخر ما يحدث في YJ Studio.',
  'Projects': 'المشاريع',
  'Audio tracks': 'المقاطع الصوتية',
  'Video assets': 'مواد الفيديو',
  'Pending bookings': 'حجوزات قيد الانتظار',
  'Active promotions': 'العروض النشطة',
  'published': 'منشور',
  'Across all projects': 'في جميع المشاريع',
  'Videos & YouTube links': 'فيديوهات وروابط YouTube',
  'confirmed': 'مؤكد',
  'Live or in schedule': 'مباشر أو مجدول',
  'GET MOVING': 'ابدأ العمل',
  'Quick actions': 'إجراءات سريعة',
  'Add a project': 'أضف مشروعاً',
  'Publish new work to the portfolio': 'انشر عملاً جديداً في معرض الأعمال',
  'Update pricing': 'حدّث الأسعار',
  'Change a service or package': 'عدّل خدمة أو باقة',
  'New campaign': 'حملة جديدة',
  'Plan an offer or announcement': 'جهّز عرضاً أو إعلاناً',
  'Review bookings': 'راجع الحجوزات',
  'Confirm times and follow up': 'أكد المواعيد وتابع الطلبات',
  'THE LATEST': 'الأحدث',
  'Recent activity': 'النشاط الأخير',
  'Admin changes will appear here.': 'ستظهر تغييرات الإدارة هنا.',
  'PORTFOLIO MANAGEMENT': 'إدارة معرض الأعمال',
  'Projects & releases': 'المشاريع والإصدارات',
  'Create drafts, publish finished work, and keep the portfolio current.': 'أنشئ المسودات وانشر الأعمال الجاهزة وحدّث معرض الأعمال.',
  'NEW PORTFOLIO ENTRY': 'إضافة إلى معرض الأعمال',
  'Project details': 'تفاصيل المشروع',
  'Project title': 'عنوان المشروع',
  'Category': 'التصنيف',
  'Description': 'الوصف',
  'Credits': 'الاعتمادات',
  'Release date': 'تاريخ الإصدار',
  'Tags': 'الوسوم',
  'Comma separated · up to 20 tags': 'افصل بين الوسوم بفواصل · حتى 20 وسماً',
  'Cover image': 'صورة الغلاف',
  'Project media': 'وسائط المشروع',
  'Images, audio tracks, video files and YouTube links': 'صور ومقاطع صوتية وفيديو وروابط YouTube',
  'Upload media files': 'ارفع ملفات الوسائط',
  'Project title, image or audio details': 'تفاصيل عنوان المشروع أو الصورة أو الصوت',
  'Publish project': 'انشر المشروع',
  'Visible on the public website': 'ظاهر على الموقع العام',
  'Feature project': 'أبرز المشروع',
  'Show in the featured work area': 'أظهره ضمن الأعمال المختارة',
  'Display order': 'ترتيب العرض',
  'Preview': 'معاينة',
  'Preview project': 'عاين المشروع',
  'Hide preview': 'إخفاء المعاينة',
  'Preview project · not public': 'معاينة المشروع · غير منشور',
  'Untitled project': 'مشروع بلا عنوان',
  'Your project description will appear here.': 'سيظهر وصف المشروع هنا.',
  'Save project': 'احفظ المشروع',
  'PORTFOLIO CONTENT': 'محتوى معرض الأعمال',
  'All projects': 'كل المشاريع',
  'Published': 'منشور',
  'Drafts': 'مسودات',
  'No project records in this view yet.': 'لا توجد مشاريع في هذا العرض بعد.',
  'Use the form to build the first portfolio entry.': 'استخدم النموذج لإضافة أول مشروع.',
  'Updated': 'آخر تحديث',
  'Standard': 'عادي',
  'SERVICES & PRICING': 'الخدمات والأسعار',
  'Price list': 'قائمة الأسعار',
  'Prices are loaded from the studio database and update publicly as soon as you save.': 'تُحمّل الأسعار من قاعدة بيانات الاستوديو وتظهر للزوار بعد الحفظ.',
  'Service details': 'تفاصيل الخدمة',
  'Service name': 'اسم الخدمة',
  'Billing unit': 'وحدة التسعير',
  'Base price': 'السعر الأساسي',
  'Currency': 'العملة',
  'Default session length (minutes)': 'مدة الجلسة الافتراضية (دقيقة)',
  'Leave blank for services priced per track, project or package.': 'اتركه فارغاً للخدمات المسعّرة للمقطع أو المشروع أو الباقة.',
  'Promotional price': 'سعر العرض',
  'Optional · automatically applies in the chosen dates': 'اختياري · يطبق تلقائياً خلال المدة المحددة',
  'Discount price': 'سعر الخصم',
  'Starts': 'يبدأ',
  'Ends': 'ينتهي',
  'Available to book': 'متاح للحجز',
  'Visible to public visitors': 'ظاهر للزوار',
  'PUBLIC SERVICE CARD PREVIEW': 'معاينة بطاقة الخدمة العامة',
  'billing unit': 'وحدة التسعير',
  'Your service description will appear here.': 'سيظهر وصف الخدمة هنا.',
  'Add service': 'أضف خدمة',
  'PUBLIC PRICE LIST': 'قائمة الأسعار العامة',
  'Current services': 'الخدمات الحالية',
  'Showing all': 'عرض الكل',
  'Active only': 'النشطة فقط',
  'No services yet.': 'لا توجد خدمات بعد.',
  'PROMOTIONS & ANNOUNCEMENTS': 'العروض والإعلانات',
  'Campaign manager': 'إدارة الحملات',
  'Create studio offers or partner announcements, then set placement and schedule.': 'أنشئ عروض الاستوديو أو إعلانات الشركاء، ثم حدد المكان والموعد.',
  'Campaign details': 'تفاصيل الحملة',
  'Campaign title': 'عنوان الحملة',
  'Campaign type': 'نوع الحملة',
  'Third-party partner announcement': 'إعلان شريك خارجي',
  'Placement': 'مكان العرض',
  'Campaign artwork': 'صورة الحملة',
  'Enabled image or video formats': 'صيغ الصور والفيديو المفعّلة',
  'Replace artwork': 'استبدل الصورة',
  'Upload artwork': 'ارفع صورة',
  'Or use an existing HTTPS URL': 'أو استخدم رابط HTTPS موجوداً',
  'CTA label': 'نص زر الإجراء',
  'Destination URL': 'رابط الوجهة',
  'Start date': 'تاريخ البداية',
  'End date': 'تاريخ النهاية',
  'Campaign status': 'حالة الحملة',
  'PLACEMENT PREVIEW': 'معاينة مكان العرض',
  'Desktop': 'سطح المكتب',
  'Mobile': 'الهاتف',
  'Campaign headline': 'عنوان الحملة',
  'Your campaign message will appear in this placement.': 'ستظهر رسالة الحملة في هذا الموضع.',
  'Create campaign': 'أنشئ الحملة',
  'CAMPAIGN LIBRARY': 'مكتبة الحملات',
  'Promotions & news': 'العروض والأخبار',
  'Third-party announcement': 'إعلان شريك خارجي',
  'Any time': 'في أي وقت',
  'No end date': 'بلا تاريخ نهاية',
  'views': 'مشاهدة',
  'clicks': 'نقرة',
  'No campaigns in this view.': 'لا توجد حملات في هذا العرض.',
  'Create a studio offer or release announcement.': 'أنشئ عرضاً للاستوديو أو إعلان إصدار.',
  'APPOINTMENTS & CLIENTS': 'المواعيد والعملاء',
  'Booking schedule': 'جدول الحجوزات',
  'Customer details stay private to the admin area. Review requests, avoid overlaps and keep the studio calendar current.': 'تبقى بيانات العملاء خاصة في لوحة الإدارة. راجع الطلبات وتجنب تعارض المواعيد وحدّث جدول الاستوديو.',
  'All requests': 'كل الطلبات',
  'Search name, phone or booking ref': 'ابحث بالاسم أو الهاتف أو رقم الحجز',
  'All statuses': 'كل الحالات',
  'shown': 'معروض',
  'Reschedule': 'إعادة الجدولة',
  'Duration (minutes)': 'المدة (دقيقة)',
  'Admin note': 'ملاحظة للإدارة',
  'Private note for the studio': 'ملاحظة خاصة بالاستوديو',
  'Save booking': 'احفظ الحجز',
  'No bookings match these filters.': 'لا توجد حجوزات تطابق عوامل التصفية.',
  'No booking requests yet.': 'لا توجد طلبات حجز بعد.',
  'New requests from the public site will appear here.': 'ستظهر هنا الطلبات الجديدة من الموقع العام.',
  'STUDIO IDENTITY & CONTROL': 'هوية الاستوديو والإدارة',
  'Edit public studio information, metadata, contact links, upload limits and your administrator password.': 'عدّل معلومات الاستوديو وبيانات الموقع وروابط التواصل وحدود الرفع وكلمة مرور المدير.',
  'Studio identity & copy': 'هوية الاستوديو والنصوص',
  'Studio logo': 'شعار الاستوديو',
  'Used in the site header, footer and app identity.': 'يظهر في ترويسة الموقع وتذييله وهوية التطبيق.',
  'Upload new logo': 'ارفع شعاراً جديداً',
  'Studio name': 'اسم الاستوديو',
  'Hero heading': 'عنوان الواجهة',
  'Hero introduction': 'مقدمة الواجهة',
  'About the studio': 'نبذة عن الاستوديو',
  'WhatsApp number': 'رقم واتساب',
  'International format; digits will be used for the wa.me link.': 'استخدم الصيغة الدولية؛ ستستخدم الأرقام في رابط wa.me.',
  'Contact phone': 'هاتف التواصل',
  'Contact email': 'بريد التواصل',
  'YouTube channel URL': 'رابط قناة YouTube',
  'Instagram URL': 'رابط Instagram',
  'Footer credit': 'اعتماد التذييل',
  'Home navigation label': 'اسم الرئيسية في القائمة',
  'Portfolio navigation label': 'اسم الأعمال في القائمة',
  'Services navigation label': 'اسم الخدمات في القائمة',
  'Offers navigation label': 'اسم العروض في القائمة',
  'About navigation label': 'اسم نبذة في القائمة',
  'Contact navigation label': 'اسم التواصل في القائمة',
  'Visible homepage sections': 'الأقسام الظاهرة في الصفحة الرئيسية',
  'Unselected sections and their navigation links are hidden.': 'تُخفى الأقسام غير المحددة وروابطها في القائمة.',
  'Maintenance / announcement message': 'رسالة صيانة أو إعلان',
  'Leave blank to hide the message bar.': 'اتركه فارغاً لإخفاء شريط الرسالة.',
  'A short temporary studio notice': 'إشعار مؤقت قصير للاستوديو',
  'Maximum upload size (MB)': 'أقصى حجم للرفع (ميجابايت)',
  'Enabled upload formats': 'صيغ الملفات المسموح برفعها',
  'Choose from the studio\'s supported safe formats. Keep at least one image type enabled.': 'اختر من الصيغ الآمنة التي يدعمها الاستوديو. أبقِ صيغة صور واحدة على الأقل مفعّلة.',
  'Social sharing image URL': 'رابط صورة المشاركة الاجتماعية',
  'PUBLIC WEBSITE CONTENT': 'محتوى الموقع العام',
  'SEARCH & MEDIA': 'البحث والوسائط',
  'Studio settings saved. Public pages now use the updated copy.': 'حُفظت إعدادات الاستوديو وأصبحت النصوص الجديدة ظاهرة للزوار.',
  'New studio logo uploaded. Save settings to publish it.': 'رُفع شعار الاستوديو الجديد. احفظ الإعدادات لنشره.',
  'Logo files must be JPG, PNG or WebP.': 'يجب أن يكون الشعار بصيغة JPG أو PNG أو WebP.',
  'The logo file must be 10 MB or smaller.': 'يجب ألا يتجاوز حجم الشعار 10 ميجابايت.',
  'SECURE SESSION · 8 HOUR EXPIRY': 'جلسة آمنة · تنتهي خلال 8 ساعات',
  'SYSTEM LIVE': 'النظام يعمل',
  'View website': 'عرض الموقع',
  'Please sign in to continue.': 'سجّل الدخول للمتابعة.',
  'The username or password is incorrect.': 'اسم المستخدم أو كلمة المرور غير صحيحة.',
  'Too many sign-in attempts. Try again in 15 minutes.': 'محاولات دخول كثيرة. أعد المحاولة بعد 15 دقيقة.',
  'Something went wrong. Please try again.': 'حدث خطأ. حاول مرة أخرى.',
  'Request origin check failed.': 'تعذر التحقق من مصدر الطلب.',
  'This file is larger than the 80 MB upload limit.': 'حجم الملف يتجاوز حد الرفع البالغ 80 ميجابايت.',
  'This media format is disabled in studio upload settings.': 'صيغة الوسائط هذه معطلة في إعدادات الرفع.',
  'This campaign format is disabled in studio upload settings.': 'صيغة الحملة هذه معطلة في إعدادات الرفع.',
  'External media links must use HTTPS.': 'يجب أن تستخدم روابط الوسائط الخارجية HTTPS.',
  'Enter a valid HTTPS media link.': 'أدخل رابط وسائط HTTPS صالحاً.',
  'Save changes': 'حفظ التغييرات',
  'Cancel': 'إلغاء',
  'Saving…': 'جارٍ الحفظ…',
  'Saving': 'جارٍ الحفظ',
  'Uploading media…': 'جارٍ رفع الوسائط…',
  'Finishing upload…': 'جارٍ إنهاء الرفع…',
  'Upload failed. Check your connection and try again.': 'فشل الرفع. تحقق من الاتصال ثم أعد المحاولة.',
  'Could not save settings.': 'تعذر حفظ الإعدادات.',
  'Could not save this project.': 'تعذر حفظ المشروع.',
  'Could not save the service.': 'تعذر حفظ الخدمة.',
  'Could not save campaign.': 'تعذر حفظ الحملة.',
  'Could not update booking.': 'تعذر تحديث الحجز.',
  'Could not load dashboard data.': 'تعذر تحميل بيانات لوحة التحكم.',
  'Delete this project? This removes the portfolio record and cannot be undone. Uploaded files stay in storage until reviewed.': 'هل تريد حذف المشروع؟ سيُحذف سجل معرض الأعمال ولا يمكن التراجع. ستبقى الملفات المرفوعة في التخزين حتى مراجعتها.',
  'Delete this service? Services with booking history must be disabled instead.': 'هل تريد حذف الخدمة؟ عطّل الخدمات التي لها سجل حجوزات بدلاً من حذفها.',
  'Delete this campaign? This action cannot be undone.': 'هل تريد حذف الحملة؟ لا يمكن التراجع عن هذا الإجراء.',
  'This service has booking history. Disable it instead of deleting it.': 'لهذه الخدمة حجوزات سابقة. عطّلها بدلاً من حذفها.',
  'That time conflicts with another pending or confirmed session. Please choose another time.': 'يتعارض هذا الموعد مع جلسة معلقة أو مؤكدة. اختر موعداً آخر.',
  'That appointment overlaps another pending or confirmed session.': 'يتداخل هذا الموعد مع جلسة معلقة أو مؤكدة.',
  'Use uploaded media or secure HTTPS links.': 'استخدم وسائط مرفوعة أو روابط HTTPS آمنة.',
  'Enter a valid appointment date and time.': 'أدخل تاريخاً ووقتاً صالحين للجلسة.',
  'Choose a valid booking status.': 'اختر حالة حجز صالحة.',
  'Choose a valid appointment time.': 'اختر وقتاً صالحاً للجلسة.',
  'Enter a valid contact email address.': 'أدخل بريداً إلكترونياً صالحاً للتواصل.',
  'Choose whether in-dashboard booking alerts are on or off.': 'حدد تشغيل تنبيهات الحجوزات داخل لوحة التحكم أو إيقافها.',
  'At least one image format must stay enabled for project covers and the studio logo.': 'يجب إبقاء صيغة صور واحدة على الأقل لغلاف المشاريع وشعار الاستوديو.',
  'Admin accounts are provisioned from the command line. See README for the secure first-admin setup.': 'تُنشأ حسابات الإدارة من سطر الأوامر. راجع README لإعداد أول مدير بطريقة آمنة.',
  'No email or WhatsApp message is sent.': 'لا تُرسل رسائل بريد أو واتساب.',
};

phraseTranslations['Install app'] = 'تثبيت التطبيق';
phraseTranslations['Discover'] = 'اكتشف';
phraseTranslations.RECORDING = 'التسجيل';
phraseTranslations['MUSIC PRODUCTION'] = 'الإنتاج الموسيقي';
phraseTranslations['MIXING & MASTERING'] = 'المكس والماستر';
phraseTranslations['VISUAL PRODUCTION'] = 'الإنتاج المرئي';
phraseTranslations.WORK = 'الأعمال';
phraseTranslations.min = 'دقيقة';
phraseTranslations.NOTICEBOARD = 'لوحة الإعلانات';
phraseTranslations.emblem = 'الشعار';
phraseTranslations['THE STUDIO'] = 'الاستوديو';
phraseTranslations['Engineer Yousab'] = 'المهندس يوساب';
phraseTranslations['FOUNDER · AUDIO ENGINEER'] = 'المؤسس · مهندس صوت';
phraseTranslations['DETAIL DRIVEN'] = 'اهتمام بالتفاصيل';
phraseTranslations['ARTIST FOCUSED'] = 'الفنان أولاً';
phraseTranslations['BUILT TO LAST'] = 'جودة تدوم';
phraseTranslations['YOUR NEXT TAKE'] = 'تسجيلك القادم';
phraseTranslations['Back to website'] = 'العودة إلى الموقع';
phraseTranslations['Studio control room.'] = 'غرفة التحكم بالاستوديو.';
phraseTranslations['Sign in to manage projects, services, campaigns and bookings.'] = 'سجّل الدخول لإدارة المشاريع والخدمات والحملات والحجوزات.';
phraseTranslations.WORKSPACE = 'مساحة العمل';
phraseTranslations['Studio administrator'] = 'مدير الاستوديو';
phraseTranslations['Signed in'] = 'تم تسجيل الدخول';
phraseTranslations['Open dashboard menu'] = 'فتح قائمة لوحة التحكم';
phraseTranslations['YOUR CHANGES ARE SAVED TO THE STUDIO DATABASE'] = 'تُحفظ تغييراتك في قاعدة بيانات الاستوديو';
phraseTranslations['Open the schedule to confirm, reschedule or reply.'] = 'افتح الجدول لتأكيد الموعد أو تغييره أو الرد على الطلب.';
phraseTranslations['Studio update'] = 'تحديث في الاستوديو';
phraseTranslations['Edit project'] = 'تعديل المشروع';
phraseTranslations['Close project editor'] = 'إغلاق محرر المشروع';
phraseTranslations['e.g. Night Drive — Single'] = 'مثال: Night Drive — أغنية منفردة';
phraseTranslations['Arabic title'] = 'العنوان بالعربية';
phraseTranslations['Give visitors a sense of the project.'] = 'اكتب نبذة تعرّف الزوار بفكرة المشروع.';
phraseTranslations['Arabic description'] = 'الوصف بالعربية';
phraseTranslations['Artist · Engineer · Label'] = 'الفنان · المهندس · شركة الإنتاج';
phraseTranslations['Arabic credits'] = 'الأسماء والأدوار بالعربية';
phraseTranslations['R&B, vocals, single'] = 'إيقاع وغناء وأغنية منفردة';
phraseTranslations['No image formats enabled'] = 'لا توجد صيغ صور مفعّلة';
phraseTranslations['up to'] = 'حتى';
phraseTranslations.Selected = 'محدّد';
phraseTranslations['Project cover preview'] = 'معاينة غلاف المشروع';
phraseTranslations['Replace cover'] = 'استبدال الغلاف';
phraseTranslations['Upload cover'] = 'رفع الغلاف';
phraseTranslations['Uploaded to Supabase Storage'] = 'مرفوع إلى Supabase Storage';
phraseTranslations['Choose a local file'] = 'اختر ملفاً من جهازك';
phraseTranslations.ITEMS = 'عناصر';
phraseTranslations['Supabase Storage media'] = 'وسائط Supabase Storage';
phraseTranslations['External link'] = 'رابط خارجي';
phraseTranslations.Remove = 'إزالة';
phraseTranslations['Media link type'] = 'نوع رابط الوسائط';
phraseTranslations['Other HTTPS'] = 'رابط HTTPS آخر';
phraseTranslations['Media title (English)'] = 'عنوان الوسائط (بالإنجليزية)';
phraseTranslations['Link title (English)'] = 'اكتب العنوان بالإنجليزية';
phraseTranslations['Media title (Arabic)'] = 'عنوان الوسائط (بالعربية)';
phraseTranslations['Link title (Arabic)'] = 'اكتب العنوان بالعربية';
phraseTranslations['Media URL'] = 'رابط الوسائط';
phraseTranslations.Add = 'إضافة';
phraseTranslations['PREVIEW · NOT PUBLIC'] = 'معاينة · غير منشور';
phraseTranslations['media items'] = 'وسائط';
phraseTranslations.All = 'الكل';
phraseTranslations.media = 'وسائط';
phraseTranslations['LIVE SERVICES'] = 'خدمات متاحة';
phraseTranslations['Close service editor'] = 'إغلاق محرر الخدمة';
phraseTranslations['e.g. Vocal recording'] = 'مثال: تسجيل الغناء';
phraseTranslations['Arabic service name'] = 'اسم الخدمة بالعربية';
phraseTranslations['Describe what this service includes.'] = 'اشرح ما تتضمنه هذه الخدمة.';
phraseTranslations.Hidden = 'مخفي';
phraseTranslations['Summer recording offer'] = 'عرض التسجيل الصيفي';
phraseTranslations['Arabic campaign title'] = 'عنوان الحملة بالعربية';
phraseTranslations['What should visitors know?'] = 'ما المعلومات التي تريد مشاركتها مع الزوار؟';
phraseTranslations['Book now'] = 'احجز الآن';
phraseTranslations['Filter booking status'] = 'تصفية حالة الحجز';
phraseTranslations['Filter appointment date'] = 'تصفية تاريخ الموعد';
phraseTranslations.Requested = 'تاريخ الطلب';
phraseTranslations['Main navigation'] = 'التنقل الرئيسي';
phraseTranslations['Open menu'] = 'فتح القائمة';
phraseTranslations['Close menu'] = 'إغلاق القائمة';
phraseTranslations['Close player'] = 'إغلاق مشغل الصوت';
phraseTranslations['Audio player'] = 'مشغل الصوت';
phraseTranslations['Loading studio settings…'] = 'جارٍ تحميل إعدادات الاستوديو…';
phraseTranslations['Settings could not be loaded.'] = 'تعذّر تحميل الإعدادات.';
phraseTranslations.English = 'الإنجليزية';
phraseTranslations['Music production'] = 'إنتاج موسيقي';
phraseTranslations['Recording sessions'] = 'جلسات التسجيل';
phraseTranslations['Mixing & mastering'] = 'المكس والماستر';
phraseTranslations['Audio engineering'] = 'هندسة صوتية';
phraseTranslations['Music videos'] = 'فيديوهات موسيقية';
phraseTranslations['Checking secure session…'] = 'جارٍ التحقق من الجلسة الآمنة…';
phraseTranslations['Project title (English)'] = 'عنوان المشروع (بالإنجليزية)';
phraseTranslations['Project title (Arabic)'] = 'عنوان المشروع (بالعربية)';
phraseTranslations['Description (English)'] = 'الوصف (بالإنجليزية)';
phraseTranslations['Description (Arabic)'] = 'الوصف (بالعربية)';
phraseTranslations['Credits (English)'] = 'الأسماء والأدوار (بالإنجليزية)';
phraseTranslations['Credits (Arabic)'] = 'الأسماء والأدوار (بالعربية)';
phraseTranslations['Service name (English)'] = 'اسم الخدمة (بالإنجليزية)';
phraseTranslations['Service name (Arabic)'] = 'اسم الخدمة (بالعربية)';
phraseTranslations['Campaign title (English)'] = 'عنوان الحملة (بالإنجليزية)';
phraseTranslations['Campaign title (Arabic)'] = 'عنوان الحملة (بالعربية)';
phraseTranslations['CTA label (English)'] = 'نص زر الإجراء (بالإنجليزية)';
phraseTranslations['CTA label (Arabic)'] = 'نص زر الإجراء (بالعربية)';
phraseTranslations.Status = 'الحالة';
phraseTranslations['Studio name (English)'] = 'اسم الاستوديو (بالإنجليزية)';
phraseTranslations['Studio name (Arabic)'] = 'اسم الاستوديو (بالعربية)';
phraseTranslations['Hero heading (English)'] = 'عنوان الواجهة (بالإنجليزية)';
phraseTranslations['Hero heading (Arabic)'] = 'عنوان الواجهة (بالعربية)';
phraseTranslations['Hero introduction (English)'] = 'مقدمة الواجهة (بالإنجليزية)';
phraseTranslations['Hero introduction (Arabic)'] = 'مقدمة الواجهة (بالعربية)';
phraseTranslations['About the studio (English)'] = 'نبذة عن الاستوديو (بالإنجليزية)';
phraseTranslations['About the studio (Arabic)'] = 'نبذة عن الاستوديو (بالعربية)';
phraseTranslations['Footer credit (English)'] = 'حقوق النشر في التذييل (بالإنجليزية)';
phraseTranslations['Footer credit (Arabic)'] = 'حقوق النشر في التذييل (بالعربية)';
phraseTranslations['Maintenance / announcement message (English)'] = 'رسالة الصيانة أو الإعلان (بالإنجليزية)';
phraseTranslations['Maintenance / announcement message (Arabic)'] = 'رسالة الصيانة أو الإعلان (بالعربية)';
phraseTranslations['SEO title (English)'] = 'عنوان محركات البحث (بالإنجليزية)';
phraseTranslations['SEO title (Arabic)'] = 'عنوان محركات البحث (بالعربية)';
phraseTranslations['SEO description (English)'] = 'وصف محركات البحث (بالإنجليزية)';
phraseTranslations['SEO description (Arabic)'] = 'وصف محركات البحث (بالعربية)';
phraseTranslations['Current password'] = 'كلمة المرور الحالية';
phraseTranslations['New password'] = 'كلمة المرور الجديدة';
phraseTranslations['At least 12 characters.'] = '12 حرفاً على الأقل.';
phraseTranslations['Studio identity & copy'] = 'هوية الاستوديو ومحتواه';
phraseTranslations['Current studio logo'] = 'شعار الاستوديو الحالي';
phraseTranslations['Studio logo'] = 'شعار الاستوديو';
phraseTranslations['Used in the site header, footer and app identity.'] = 'يظهر في ترويسة الموقع وتذييله وهوية التطبيق.';
phraseTranslations['Upload new logo'] = 'رفع شعار جديد';
phraseTranslations['NAVIGATION & VISIBILITY'] = 'التنقل والأقسام الظاهرة';
phraseTranslations['Navigation labels (English)'] = 'عناوين التنقل (بالإنجليزية)';
phraseTranslations['Navigation labels (Arabic)'] = 'عناوين التنقل (بالعربية)';
phraseTranslations['Arabic home'] = 'الرئيسية بالعربية';
phraseTranslations['Arabic portfolio'] = 'الأعمال بالعربية';
phraseTranslations['Arabic services'] = 'الخدمات بالعربية';
phraseTranslations['Arabic offers'] = 'العروض بالعربية';
phraseTranslations['Arabic about'] = 'نبذة عنا بالعربية';
phraseTranslations['Arabic contact'] = 'التواصل بالعربية';
phraseTranslations['Visible homepage sections'] = 'أقسام الصفحة الرئيسية الظاهرة';
phraseTranslations['Unselected sections and their navigation links are hidden.'] = 'تُخفى الأقسام غير المحددة وروابطها من قائمة التنقل.';
phraseTranslations['Leave blank to hide the message bar.'] = 'اترك الحقل فارغاً لإخفاء شريط الرسالة.';
phraseTranslations['Search & media'] = 'البحث والوسائط';
phraseTranslations['SEARCH & MEDIA'] = 'البحث والوسائط';
phraseTranslations['PUBLIC WEBSITE CONTENT'] = 'محتوى الموقع العام';
phraseTranslations['Enabled upload formats'] = 'صيغ الملفات المسموح برفعها';
phraseTranslations['Choose from the studio’s supported safe formats. Keep at least one image type enabled.'] = 'اختر من صيغ الملفات الآمنة التي يدعمها الاستوديو. أبقِ صيغة صور واحدة مفعّلة على الأقل.';
phraseTranslations['At least one image format must stay enabled for project covers and the studio logo.'] = 'يجب إبقاء صيغة صور واحدة مفعّلة على الأقل لأغلفة المشاريع وشعار الاستوديو.';
phraseTranslations['Saved content is visible to the public site.'] = 'يظهر المحتوى المحفوظ على الموقع العام.';
phraseTranslations['ACCOUNT SECURITY'] = 'أمان الحساب';
phraseTranslations['Change password'] = 'تغيير كلمة المرور';
phraseTranslations['Update administrator password'] = 'تحديث كلمة مرور المدير';
phraseTranslations['Updating…'] = 'جارٍ التحديث…';
phraseTranslations['Passwords are stored as PBKDF2 hashes. No password is saved in this browser.'] = 'تُخزّن كلمات المرور بصيغة تجزئة PBKDF2، ولا تُحفظ أي كلمة مرور في هذا المتصفح.';
phraseTranslations.ACCOUNTABILITY = 'سجل المساءلة';
phraseTranslations['Audit trail'] = 'سجل النشاط';
phraseTranslations['Administrative changes are recorded here.'] = 'تُسجّل التغييرات الإدارية هنا.';
phraseTranslations['Admin access is private'] = 'الوصول إلى لوحة الإدارة خاص';
phraseTranslations['API changes require a valid server-side session. This account has no public registration route.'] = 'تتطلب تغييرات الواجهة البرمجية جلسة صالحة على الخادم. لا يوجد تسجيل عام لهذا الحساب.';
phraseTranslations['Current theme'] = 'المظهر الحالي';
phraseTranslations['Choose theme'] = 'اختيار المظهر';
phraseTranslations['Choose language'] = 'اختيار اللغة';
phraseTranslations['Arabic navigation label'] = 'عنوان التنقل بالعربية';
phraseTranslations['Verifying…'] = 'جارٍ التحقق…';
phraseTranslations['Refreshing dashboard data…'] = 'جارٍ تحديث بيانات لوحة التحكم…';
phraseTranslations['Dashboard sections'] = 'أقسام لوحة التحكم';
phraseTranslations.Dismiss = 'إغلاق التنبيه';
phraseTranslations['CONTROL ROOM'] = 'غرفة التحكم';
phraseTranslations['CAMPAIGNS'] = 'حملات';
phraseTranslations['Campaign manager'] = 'إدارة الحملات';
phraseTranslations['Create studio offers or partner announcements, then set placement and schedule.'] = 'أنشئ عروض الاستوديو أو إعلانات الشركاء، ثم حدّد موضع العرض وموعده.';
phraseTranslations['Close campaign editor'] = 'إغلاق محرر الحملة';
phraseTranslations['Campaign preview'] = 'معاينة الحملة';
phraseTranslations['Campaign artwork'] = 'صورة الحملة';
phraseTranslations['Enabled image or video formats'] = 'صيغ الصور أو الفيديو المفعّلة';
phraseTranslations['Replace artwork'] = 'استبدال الصورة';
phraseTranslations['Upload artwork'] = 'رفع صورة';
phraseTranslations['Or use an existing HTTPS URL'] = 'أو استخدم رابط HTTPS موجوداً';
phraseTranslations['Campaign details'] = 'تفاصيل الحملة';
phraseTranslations['UPDATE CAMPAIGN'] = 'تحديث الحملة';
phraseTranslations['CAMPAIGN SETUP'] = 'إعداد الحملة';
phraseTranslations['CAMPAIGNS'] = 'الحملات';
phraseTranslations['Campaigns'] = 'الحملات';
phraseTranslations['Create campaign'] = 'إنشاء الحملة';
phraseTranslations['Third-party partner announcement'] = 'إعلان شريك خارجي';
phraseTranslations['Partner announcement'] = 'إعلان شريك';
phraseTranslations['homepage hero'] = 'واجهة الصفحة الرئيسية';
phraseTranslations['homepage banner'] = 'شريط الصفحة الرئيسية';
phraseTranslations.announcements = 'الإعلانات';
phraseTranslations['per hour'] = 'للساعة';
phraseTranslations['per track'] = 'للمقطع';
phraseTranslations['per project'] = 'للمشروع';
phraseTranslations['per package'] = 'للباقة';
phraseTranslations['per session'] = 'للجلسة';
phraseTranslations.hour = 'ساعة';
phraseTranslations.hours = 'ساعات';
phraseTranslations['Request another session'] = 'طلب جلسة أخرى';
phraseTranslations['Sending request…'] = 'جارٍ إرسال الطلب…';
phraseTranslations['Session length'] = 'مدة الجلسة';
phraseTranslations['SESSION REQUEST'] = 'طلب جلسة';
phraseTranslations['A few details about the session…'] = 'شاركنا بعض التفاصيل عن الجلسة…';
phraseTranslations['Enter a name with at least 2 characters.'] = 'أدخل اسماً يتكوّن من حرفين على الأقل.';
phraseTranslations['Enter a valid phone number with at least 7 digits.'] = 'أدخل رقم هاتف صحيحاً يتكوّن من 7 أرقام على الأقل.';
phraseTranslations['Enter a valid email address or leave it blank.'] = 'أدخل بريداً إلكترونياً صحيحاً أو اترك الحقل فارغاً.';
phraseTranslations['Choose an appointment time at least one hour from now.'] = 'اختر موعداً بعد ساعة من الآن على الأقل.';
phraseTranslations['The booking could not be saved. Try again.'] = 'تعذّر حفظ طلب الحجز. حاول مرة أخرى.';
phraseTranslations['CAIRO · EGYPT'] = 'القاهرة · مصر';
phraseTranslations['Hi, I submitted booking request {reference} for {service}.'] = 'مرحباً، أرسلت طلب الحجز {reference} لخدمة {service}.';
phraseTranslations['Hi, I would like to ask about a session at {studio}.'] = 'مرحباً، أود الاستفسار عن جلسة في {studio}.';
phraseTranslations['This file is larger than the {limit} MB upload limit.'] = 'يتجاوز حجم الملف الحد المسموح للرفع، وهو {limit} ميجابايت.';
phraseTranslations['The file is larger than the {limit} MB upload limit.'] = 'يتجاوز حجم الملف الحد المسموح للرفع، وهو {limit} ميجابايت.';
phraseTranslations['{filename} ({size}) uploaded to studio media storage.'] = 'تم رفع {filename} ({size}) إلى مساحة تخزين وسائط الاستوديو.';
phraseTranslations['{filename} uploaded.'] = 'تم رفع {filename}.';
phraseTranslations['Booking {reference} updated.'] = 'تم تحديث الحجز {reference}.';
phraseTranslations['This file format is disabled in studio upload settings.'] = 'صيغة الملف هذه غير مفعّلة في إعدادات رفع الملفات بالاستوديو.';
phraseTranslations['This image format is disabled in studio upload settings.'] = 'صيغة الصورة هذه غير مفعّلة في إعدادات رفع الملفات بالاستوديو.';
phraseTranslations['Project deleted.'] = 'تم حذف المشروع.';
phraseTranslations['Service deleted.'] = 'تم حذف الخدمة.';
phraseTranslations['Campaign deleted.'] = 'تم حذف الحملة.';
phraseTranslations['Administrator password updated. Other active sessions have not been signed out.'] = 'تم تحديث كلمة مرور المدير. لم يتم تسجيل الخروج من الجلسات الأخرى.';
phraseTranslations['Promotional price'] = 'سعر العرض';
phraseTranslations['Optional · automatically applies in the chosen dates'] = 'اختياري · يُطبّق تلقائياً خلال التواريخ المحددة';
phraseTranslations['Available to book'] = 'متاح للحجز';
phraseTranslations['Visible to public visitors'] = 'ظاهر لزوار الموقع';
phraseTranslations['Show pending booking alerts in the dashboard'] = 'إظهار تنبيهات الحجوزات المعلّقة في لوحة التحكم';
phraseTranslations['In-dashboard only. No email or WhatsApp message is sent.'] = 'تظهر التنبيهات داخل لوحة التحكم فقط. لا تُرسل رسائل بريد أو واتساب.';
phraseTranslations['JPEG images'] = 'صور JPEG';
phraseTranslations['PNG images'] = 'صور PNG';
phraseTranslations['WebP images'] = 'صور WebP';
phraseTranslations['MP3 audio'] = 'صوت MP3';
phraseTranslations['MP3 audio (alternate MIME)'] = 'صوت MP3 (نوع MIME بديل)';
phraseTranslations['WAV audio'] = 'صوت WAV';
phraseTranslations['WAV audio (alternate MIME)'] = 'صوت WAV (نوع MIME بديل)';
phraseTranslations['OGG audio'] = 'صوت OGG';
phraseTranslations['M4A audio'] = 'صوت M4A';
phraseTranslations['MP4 video'] = 'فيديو MP4';
phraseTranslations['WebM video'] = 'فيديو WebM';
phraseTranslations.image = 'صورة';
phraseTranslations.audio = 'صوت';
phraseTranslations.video = 'فيديو';
phraseTranslations['YouTube video'] = 'فيديو YouTube';
phraseTranslations['Studio settings saved. Public pages now use the updated copy.'] = 'تم حفظ إعدادات الاستوديو. سيظهر المحتوى المحدّث على صفحات الموقع.';
phraseTranslations['Campaign changes saved.'] = 'تم حفظ تغييرات الحملة.';
phraseTranslations['Campaign created.'] = 'تم إنشاء الحملة.';
phraseTranslations['Campaign deleted.'] = 'تم حذف الحملة.';
phraseTranslations['Service pricing saved and is live.'] = 'تم حفظ أسعار الخدمة ونشرها.';
phraseTranslations['Service added to the price list.'] = 'تمت إضافة الخدمة إلى قائمة الأسعار.';
phraseTranslations['Project changes saved.'] = 'تم حفظ تغييرات المشروع.';
phraseTranslations['Project created.'] = 'تم إنشاء المشروع.';
phraseTranslations['This campaign format is disabled in studio upload settings.'] = 'صيغة الحملة هذه غير مفعّلة في إعدادات رفع الملفات بالاستوديو.';
phraseTranslations['New studio logo uploaded. Save settings to publish it.'] = 'تم رفع شعار الاستوديو الجديد. احفظ الإعدادات لنشره.';
phraseTranslations['Logo upload failed.'] = 'تعذّر رفع الشعار.';
phraseTranslations['Could not update password.'] = 'تعذّر تحديث كلمة المرور.';
phraseTranslations['Could not delete campaign.'] = 'تعذّر حذف الحملة.';
phraseTranslations['Could not delete project.'] = 'تعذّر حذف المشروع.';
phraseTranslations['Could not delete service.'] = 'تعذّر حذف الخدمة.';
phraseTranslations['Could not save campaign.'] = 'تعذّر حفظ الحملة.';
phraseTranslations['Campaign deleted.'] = 'تم حذف الحملة.';
phraseTranslations['Dismiss'] = 'إغلاق';
phraseTranslations['Request body must be valid JSON.'] = 'يجب أن يكون محتوى الطلب بصيغة JSON صالحة.';
phraseTranslations['That service is no longer available. Refresh the page and choose another service.'] = 'لم تعد هذه الخدمة متاحة. حدّث الصفحة واختر خدمة أخرى.';
phraseTranslations['Choose a valid appointment date and time.'] = 'اختر تاريخاً ووقتاً صالحين للموعد.';
phraseTranslations['Enter your username and password.'] = 'أدخل اسم المستخدم وكلمة المرور.';
phraseTranslations['Use uploaded media or secure HTTPS links and enter a valid release date.'] = 'استخدم وسائط مرفوعة أو روابط HTTPS آمنة، وأدخل تاريخ إصدار صالحاً.';
phraseTranslations['Enter valid discount start and end dates.'] = 'أدخل تاريخي بداية ونهاية صالحين للخصم.';
phraseTranslations['Campaign media, dates, or destination are invalid. Use uploaded files, secure HTTPS links, or a site path.'] = 'وسائط الحملة أو تواريخها أو وجهتها غير صالحة. استخدم ملفات مرفوعة أو روابط HTTPS آمنة أو مساراً داخل الموقع.';
phraseTranslations['Invalid booking update.'] = 'تحديث الحجز غير صالح.';
phraseTranslations['Settings must be valid JSON.'] = 'يجب أن تكون الإعدادات بصيغة JSON صالحة.';
phraseTranslations['Provide a settings object.'] = 'أدخل كائن الإعدادات.';
phraseTranslations['Too many settings were sent.'] = 'تم إرسال عدد كبير من الإعدادات.';
phraseTranslations['Brand and social images must be uploaded files or secure HTTPS links.'] = 'يجب أن تكون صور العلامة التجارية والتواصل الاجتماعي ملفات مرفوعة أو روابط HTTPS آمنة.';
phraseTranslations['Social links must use HTTPS.'] = 'يجب أن تستخدم روابط التواصل الاجتماعي HTTPS.';
phraseTranslations['Upload size must be between 1 and 80 MB.'] = 'يجب أن يكون حجم الرفع بين 1 و80 ميجابايت.';
phraseTranslations['One or more public section names are invalid.'] = 'اسم قسم عام واحد أو أكثر غير صالح.';
phraseTranslations['Choose supported formats, including at least one image format.'] = 'اختر صيغاً مدعومة، مع تضمين صيغة صور واحدة على الأقل.';
phraseTranslations['Enter your current and new passwords.'] = 'أدخل كلمة المرور الحالية والجديدة.';
phraseTranslations['Use a new password with at least 12 characters.'] = 'استخدم كلمة مرور جديدة لا يقل طولها عن 12 حرفاً.';
phraseTranslations['Current password is incorrect.'] = 'كلمة المرور الحالية غير صحيحة.';
phraseTranslations['Choose a media file to upload.'] = 'اختر ملف وسائط لرفعه.';
phraseTranslations['Supported formats: JPG, PNG, WebP, MP3, WAV, OGG, M4A, MP4 and WebM.'] = 'الصيغ المدعومة: JPG وPNG وWebP وMP3 وWAV وOGG وM4A وMP4 وWebM.';
phraseTranslations['Not found.'] = 'المحتوى المطلوب غير موجود.';
phraseTranslations['Invalid value for {key}.'] = 'القيمة المدخلة غير صالحة للحقل {key}.';
phraseTranslations['This file is larger than the {limit} MB upload limit.'] = 'يتجاوز حجم الملف الحد المسموح للرفع، وهو {limit} ميجابايت.';
phraseTranslations['Choose from the studio\'s supported safe formats. Keep at least one image type enabled.'] = 'اختر من صيغ الملفات الآمنة التي يدعمها الاستوديو، مع إبقاء صيغة صور واحدة مفعّلة على الأقل.';
phraseTranslations['YJ Studio administration'] = 'إدارة YJ Studio';
phraseTranslations['Private dashboard for managing YJ Studio projects, services and bookings.'] = 'لوحة خاصة لإدارة مشاريع وخدمات وحجوزات YJ Studio.';
phraseTranslations["Choose from the studio's supported safe formats. Keep at least one image type enabled."] = 'اختر من صيغ الملفات الآمنة التي يدعمها الاستوديو، مع إبقاء صيغة صور واحدة مفعّلة على الأقل.';

export function tx(language: Language, source: string): string {
  if (language !== 'ar') return source;
  const exact = phraseTranslations[source];
  if (exact) return exact;
  const invalidSetting = source.match(/^Invalid value for (.+)\.$/);
  if (invalidSetting) return `القيمة المدخلة غير صالحة للحقل ${invalidSetting[1]}.`;
  const uploadLimit = source.match(/^(?:This|The) file is larger than (?:the )?(\d+) MB upload limit\.$/);
  if (uploadLimit) return `يتجاوز حجم الملف الحد المسموح للرفع، وهو ${uploadLimit[1]} ميجابايت.`;
  const failedRequest = source.match(/^Request failed \((\d+)\)\.$/);
  if (failedRequest) return `تعذّر إكمال الطلب (رمز ${failedRequest[1]}).`;
  const failedUpload = source.match(/^Upload failed \((\d+)\)\.$/);
  if (failedUpload) return `تعذّر رفع الملف (رمز ${failedUpload[1]}).`;
  if (['Failed to fetch', 'NetworkError', 'Network request failed', 'Load failed'].includes(source)) return 'تعذّر الاتصال بالاستوديو. تحقّق من اتصالك وحاول مجدداً.';
  return source;
}

export function txf(language: Language, source: string, values: Record<string, string | number>): string {
  return Object.entries(values).reduce((message, [key, value]) => message.replaceAll(`{${key}}`, String(value)), tx(language, source));
}

export function bookingReviewCount(language: Language, count: number): string {
  if (language === 'en') return `${count} booking request${count === 1 ? '' : 's'} need${count === 1 ? 's' : ''} a review`;
  const number = new Intl.NumberFormat('ar-EG').format(count);
  const form = new Intl.PluralRules('ar').select(count);
  if (form === 'zero') return 'لا توجد طلبات حجز بانتظار المراجعة';
  if (form === 'one') return 'طلب حجز واحد بانتظار المراجعة';
  if (form === 'two') return 'طلبا حجز بانتظار المراجعة';
  if (form === 'few') return `${number} طلبات حجز بانتظار المراجعة`;
  if (form === 'many') return `${number} طلب حجز بانتظار المراجعة`;
  return `${number} طلب حجز بانتظار المراجعة`;
}

export function localize(en: string | null | undefined, ar: string | null | undefined, language: Language, fallback = ''): string {
  if (language === 'ar') return ar?.trim() || en?.trim() || fallback;
  return en?.trim() || ar?.trim() || fallback;
}

export function themeLabel(language: Language, mode: ThemeMode): string {
  const labels: Record<ThemeMode, string> = {
    dark: language === 'ar' ? 'الوضع الداكن' : 'Dark mode',
    light: language === 'ar' ? 'الوضع الفاتح' : 'Light mode',
    system: language === 'ar' ? 'حسب الجهاز' : 'System mode',
  };
  return labels[mode];
}
