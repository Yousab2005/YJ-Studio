(() => {
  const root = document.documentElement;
  const media = window.matchMedia('(prefers-color-scheme: light)');
  let language = 'ar';
  let mode = 'system';
  try {
    language = localStorage.getItem('yj-language') === 'en' ? 'en' : 'ar';
    const savedMode = localStorage.getItem('yj-theme-mode');
    if (savedMode === 'dark' || savedMode === 'light' || savedMode === 'system') mode = savedMode;
  } catch {
    // Storage can be unavailable in restricted browser contexts.
  }
  const resolvedTheme = mode === 'system' ? (media.matches ? 'light' : 'dark') : mode;
  root.lang = language;
  root.dir = language === 'ar' ? 'rtl' : 'ltr';
  root.dataset.themeMode = mode;
  root.dataset.theme = resolvedTheme;
  document.querySelector('meta[name="theme-color"]')?.setAttribute('content', resolvedTheme === 'light' ? '#f4f8fa' : '#071119');
  const manifest = document.querySelector('link[rel="manifest"]');
  if (manifest) manifest.setAttribute('href', resolvedTheme === 'light' ? '/manifest-light.webmanifest' : '/manifest.webmanifest');
})();
